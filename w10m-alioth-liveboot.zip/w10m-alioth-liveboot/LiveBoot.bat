@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\liveboot.ps1" %*
pause
