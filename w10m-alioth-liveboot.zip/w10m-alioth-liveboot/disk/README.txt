﻿BuildDisk.bat puts w10m.qcow2 here (made from your own FFU).
