<#
.SYNOPSIS
  Windows 10 Mobile on the Poco F3 (alioth), from RAM. Nothing is flashed, nothing on the phone's storage is
  written: the phone's own recovery, boot and system stay as they are; a reboot brings Android back.
  1. A recovery with root adb runs the phone: your installed TWRP/OrangeFox (adb reboot recovery), or a
     TWRP image given with -Twrp, started with `fastboot boot` (RAM only, the recovery partition is not touched).
  2. QEMU, the Windows disk (disk\w10m.qcow2, made by BuildDisk.bat) and the display agent go into RAM.
  3. Windows runs: picture on the panel, Back / Start / Search and the keyboard button under it, the touch
     screen and the side keys drive it; the internet comes over the USB cable from this PC.
.PARAMETER Twrp       a TWRP image for alioth to boot from RAM (when the installed recovery has no root adb)
.PARAMETER Emulation  run all of Windows in emulation (slower, the fallback if the fast mode misbehaves)
.PARAMETER NoNet      no internet for Windows
.EXAMPLE  LiveBoot.bat
.EXAMPLE  LiveBoot.bat -Twrp D:\twrp-3.7.0_12-alioth.img
#>
#requires -Version 5.1
param(
    [string]$Twrp = "",
    [switch]$Emulation,
    [switch]$NoNet,
    [int]$NetPort = 10555
)
$ErrorActionPreference = "Stop"
$Pkg = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Phone = Join-Path $Pkg "phone"
$Disk = Join-Path $Pkg "disk\w10m.qcow2"
$Log = Join-Path $Pkg "liveboot-log.txt"
Set-Content -Encoding utf8 $Log "liveboot $(Get-Date -Format s)"

function Say([string]$t) { Write-Host "== $t" -ForegroundColor Cyan; Add-Content -Encoding utf8 $Log "`n== $t" }
function Note([string]$t) { Write-Host $t; Add-Content -Encoding utf8 $Log $t }
function Find([string]$name) {
    $c = Get-Command $name -ErrorAction SilentlyContinue
    if ($c) { return $c.Source }
    $p = Join-Path $Pkg "platform-tools\$name.exe"
    if (Test-Path $p) { return $p }
    throw "$name not found: put Google's platform-tools in $Pkg\platform-tools (or on PATH)"
}
# run with a timeout so a missing device never hangs the script
function Tool([string]$exe, [string[]]$a, [int]$sec = 30) {
    $psi = New-Object Diagnostics.ProcessStartInfo $exe, ($a -join ' ')
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($psi)
    $o = $p.StandardOutput.ReadToEndAsync(); $e = $p.StandardError.ReadToEndAsync()
    if (-not $p.WaitForExit($sec * 1000)) { try { $p.Kill() } catch { }; return "" }
    return "$($o.Result)$($e.Result)"
}
function WaitFor([scriptblock]$cond, [int]$sec, [string]$what) {
    for ($i = 0; $i -lt $sec; $i++) { if (& $cond) { return }; Start-Sleep 1 }
    throw "timeout waiting for $what"
}
$adb = Find adb
$fastboot = Find fastboot
function Sh([string]$cmd, [int]$sec = 60) { return (Tool $adb @("shell", "`"$cmd`"") $sec).Trim() }

if (-not (Test-Path $Disk)) { throw "no ${Disk}: make it first with BuildDisk.bat -Ffu <your HP Elite x3 FFU>" }
$diskGB = (Get-Item $Disk).Length / 1GB

Say "the phone into a recovery with root adb (nothing is flashed)"
$devs = Tool $adb @("devices")
if ($Twrp) {
    if (-not (Test-Path $Twrp)) { throw "no TWRP image at $Twrp" }
    if ($devs -match "`t(device|recovery)") { Tool $adb @("reboot", "bootloader") | Out-Null }
    WaitFor { (Tool $fastboot @("devices") 10) -match "fastboot" } 90 "fastboot (USB debugging on, or the phone in bootloader mode)"
    $prod = (Tool $fastboot @("getvar", "product")).Trim()
    Note $prod
    if ($prod -notmatch "alioth") { throw "this is not a Poco F3 / Redmi K40 (alioth)" }
    Note (Tool $fastboot @("boot", "`"$Twrp`"") 120).Trim()       # RAM only: the recovery partition stays as it is
} elseif ($devs -notmatch "`trecovery") {
    if ($devs -notmatch "`tdevice") { throw "no phone over adb: enable USB debugging, or give -Twrp <image>" }
    Tool $adb @("reboot", "recovery") | Out-Null                    # the recovery installed on the phone
}
WaitFor { (Tool $adb @("devices") 10) -match "`trecovery" } 180 "the recovery's adb"
Start-Sleep 3
$id = Sh "id; getprop ro.product.device; ls /dev/dri/card0"
Note $id
if ($id -notmatch "uid=0") { throw "this recovery gives no root adb: use TWRP/OrangeFox, or -Twrp <image> (booted from RAM)" }
if ($id -notmatch "card0") { throw "this recovery has no display device (/dev/dri/card0)" }

Say "RAM for Windows"
$tmpMB = [int]($diskGB * 1024) + 1200
Note (Sh "mkdir -p /tmp/w10m; mountpoint -q /tmp/w10m || mount -t tmpfs -o size=${tmpMB}m tmpfs /tmp/w10m; df -h /tmp/w10m | tail -1")

Say ("copy to the phone ({0:N1} GB, about 2 minutes)" -f ($diskGB + 0.2))
foreach ($f in "qemu-system-arm", "lib", "w10m-phone", "helper32", "liveboot.sh", "edk2-arm-code.fd", "shimfs") {
    Note (Tool $adb @("push", "`"$(Join-Path $Phone $f)`"", "/tmp/w10m/$f") 300).Trim().Split("`n")[-1]
}
Note (Tool $adb @("push", "`"$(Join-Path $Phone 'edk2-arm-vars.fd')`"", "/tmp/w10m/vars.fd") 120).Trim().Split("`n")[-1]
Note (Tool $adb @("push", "`"$Disk`"", "/tmp/w10m/w10m.qcow2") 900).Trim().Split("`n")[-1]
Note (Sh "cd /tmp/w10m && chmod 755 qemu-system-arm w10m-phone helper32 liveboot.sh lib/*")

$net = ""
if (-not $NoNet) {
    Say "internet over the USB cable (this PC shares its connection)"
    # a QEMU without a machine: its user-mode network (NAT through this PC) on a TCP port the phone reaches
    # through adb reverse; Windows gets the cable once its screen is up
    if (-not (Get-NetTCPConnection -LocalPort $NetPort -State Listen -ErrorAction SilentlyContinue)) {
        Start-Process -WindowStyle Hidden (Join-Path $Pkg "pc\qemu-system-arm.exe") -ArgumentList @(
            "-M", "none", "-nodefaults", "-display", "none", "-netdev", "user,id=u",
            "-netdev", "stream,id=s,server=on,addr.type=inet,addr.host=127.0.0.1,addr.port=$NetPort",
            "-netdev", "hubport,id=h1,hubid=0,netdev=u", "-netdev", "hubport,id=h2,hubid=0,netdev=s") | Out-Null
        Start-Sleep 2
    }
    Note (Tool $adb @("reverse", "tcp:$NetPort", "tcp:$NetPort")).Trim()
    $net = "NET_PORT=$NetPort"
}

Say "start Windows"
$native = if ($Emulation) { 0 } else { 1 }
Note (Sh "cd /tmp/w10m && NATIVE=$native $net nohup sh ./liveboot.sh >/dev/null 2>&1 & sleep 6; tail -3 /tmp/w10m/run.log")
Write-Host ""
Write-Host "Windows starts on the phone: the Start screen in about 1-3 minutes ($(if ($Emulation) { 'emulation: 10+ minutes' } else { 'fast mode' }))." -ForegroundColor Green
Write-Host "Do not press anything until it is up. Short press of power: screen off / on. Keep the USB cable in for the internet."
Write-Host "Back to Android: hold the power button (or adb reboot). Nothing on the phone was changed."
