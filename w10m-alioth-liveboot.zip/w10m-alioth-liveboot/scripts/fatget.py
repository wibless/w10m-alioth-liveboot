"""Copy one file out of a FAT12/16/32 partition image (long names understood, case ignored).

Usage: python -I fatget.py <partition.img> <path\\in\\the\\partition> <out file>
Used by build-disk.ps1 to take EFI\\Microsoft\\boot\\BCD out of the FFU's EFIESP.
"""
import struct
import sys


def main():
    img, path, out = sys.argv[1], sys.argv[2], sys.argv[3]
    d = open(img, "rb").read()
    bps, spc, rsv, nfat = struct.unpack_from("<HBHB", d, 11)
    nroot, tot16, _, fatsz16 = struct.unpack_from("<HHBH", d, 17)
    tot32, fatsz32, _, _, root_clus = struct.unpack_from("<IIHHI", d, 32)
    fatsz = fatsz16 or fatsz32
    total = tot16 or tot32
    root_secs = (nroot * 32 + bps - 1) // bps
    first_data = rsv + nfat * fatsz + root_secs
    clusters = (total - first_data) // spc
    kind = 12 if clusters < 4085 else 16 if clusters < 65525 else 32
    fat = d[rsv * bps:(rsv + fatsz) * bps]
    csize = spc * bps

    def next_clus(c):
        if kind == 32:
            return struct.unpack_from("<I", fat, c * 4)[0] & 0x0FFFFFFF
        if kind == 16:
            return struct.unpack_from("<H", fat, c * 2)[0]
        v = struct.unpack_from("<H", fat, c * 3 // 2)[0]
        return v >> 4 if c & 1 else v & 0xFFF

    def chain(c):
        end = {12: 0xFF8, 16: 0xFFF8, 32: 0x0FFFFFF8}[kind]
        data = b""
        while 2 <= c < end:
            off = (first_data + (c - 2) * spc) * bps
            data += d[off:off + csize]
            c = next_clus(c)
        return data

    def entries(raw):
        lfn = []
        for i in range(0, len(raw), 32):
            e = raw[i:i + 32]
            if e[0] == 0:
                break
            if e[0] == 0xE5:
                lfn = []
                continue
            if e[11] == 0x0F:
                part = e[1:11] + e[14:26] + e[28:32]
                lfn.insert(0, part.decode("utf-16-le", "ignore").split("\0")[0].replace("￿", ""))
                continue
            short = e[0:8].decode("latin-1").rstrip() + ("." + e[8:11].decode("latin-1").rstrip() if e[8:11].strip() else "")
            name = "".join(lfn) or short
            lfn = []
            hi, lo = struct.unpack_from("<H", e, 20)[0], struct.unpack_from("<H", e, 26)[0]
            yield name, e[11], (hi << 16) | lo, struct.unpack_from("<I", e, 28)[0]

    if kind == 32:
        cur = chain(root_clus)
    else:
        off = (rsv + nfat * fatsz) * bps
        cur = d[off:off + root_secs * bps]
    parts = [p for p in path.replace("/", "\\").split("\\") if p]
    for i, p in enumerate(parts):
        hit = next((x for x in entries(cur) if x[0].lower() == p.lower()), None)
        if not hit:
            sys.exit("%s: not in the partition" % "\\".join(parts[:i + 1]))
        name, attr, clus, size = hit
        if i < len(parts) - 1:
            cur = chain(clus)
        else:
            open(out, "wb").write(chain(clus)[:size])
            print("%s: %d bytes" % (path, size))


if __name__ == "__main__":
    main()
