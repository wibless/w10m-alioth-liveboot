<#
.SYNOPSIS
  Builds the Windows 10 Mobile disk for the LiveBoot (disk\w10m.qcow2) from your own HP Elite x3 FFU.
  Nothing of Windows ships with this package: everything comes from the FFU you give, and the FFU is only read.
  Steps: FFU -> disk image; boot entry straight to the Windows Loader; registry for the display, touch and
  USB of the LiveBoot; three small fixes in CoreUIComponents.dll / InputHost.dll (apps closing on a tap);
  the first start of Windows (setup) in QEMU on this PC; one compressed file at the end.
  Needs: Python 3, 7-Zip, ~15 GB free. Takes 40-70 minutes (most of it the first start of Windows).
.PARAMETER Ffu  the FFU: MR5_Elite_x3-retail-0002.0000.0037.0001-signed_0002.0000.0037.0001.ffu (Windows 10 Mobile 14393.953)
.EXAMPLE  .\BuildDisk.bat -Ffu D:\fw\MR5_Elite_x3-retail-0002.0000.0037.0001-signed_0002.0000.0037.0001.ffu
#>
#requires -Version 5.1
param(
    [Parameter(Mandatory)][string]$Ffu,
    [int]$SetupMinutes = 45            # how long the first start of Windows (setup, app installs) is given
)
$ErrorActionPreference = "Stop"
$Pkg = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Tools = Join-Path $Pkg "tools"
$Pc = Join-Path $Pkg "pc"
$Phone = Join-Path $Pkg "phone"
$Out = Join-Path $Pkg "disk"
$B = Join-Path $Out "build"
New-Item -ItemType Directory -Force $B | Out-Null
$env:W10M_QEMU_DIR = $Pc
$qimg = Join-Path $Pc "qemu-img.exe"
$py = (Get-Command python -ErrorAction SilentlyContinue).Source
if (-not $py) { throw "Python 3 is needed (python.org; tick 'Add python.exe to PATH')" }
$7z = @("C:\Program Files\7-Zip\7z.exe", "C:\Program Files (x86)\7-Zip\7z.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $7z) { throw "7-Zip is needed (7-zip.org)" }
$env:W10M_7Z = $7z
function Say([string]$t) { Write-Host "== $t" -ForegroundColor Cyan }
function Py { & $py -I @args; if ($LASTEXITCODE) { throw "python $($args[0]) failed" } }

# the FFU this package was made for: other builds have the fixes at other addresses
$known = "MR5_Elite_x3-retail-0002.0000.0037.0001-signed_0002.0000.0037.0001.ffu"
if (-not (Test-Path $Ffu)) { throw "no FFU at $Ffu" }
if ((Split-Path -Leaf $Ffu) -ne $known) { Write-Host "warning: this is not $known; the build may fail" -ForegroundColor Yellow }

Say "1/8 the FFU's partitions (read only)"
Py "$Tools\ffu.py" gpt $Ffu | Select-String "EFIESP|MainOS" | ForEach-Object Line
$raw = Join-Path $B "base.img"
if (-not (Test-Path (Join-Path $B "base.qcow2"))) {
    Py "$Tools\ffu.py" disk $Ffu $raw
    & $qimg convert -O qcow2 $raw (Join-Path $B "base.qcow2"); if ($LASTEXITCODE) { throw "qemu-img convert failed" }
    Remove-Item $raw
}
if (-not (Test-Path (Join-Path $B "MainOS.img"))) { Py "$Tools\ffu.py" extract $Ffu MainOS (Join-Path $B "MainOS.img") }
if (-not (Test-Path (Join-Path $B "EFIESP.img"))) { Py "$Tools\ffu.py" extract $Ffu EFIESP (Join-Path $B "EFIESP.img") }
$main = Join-Path $B "MainOS.img"
$disk = Join-Path $B "disk.qcow2"
Remove-Item $disk -ErrorAction SilentlyContinue
& $qimg create -q -f qcow2 -b base.qcow2 -F qcow2 $disk

Say "2/8 boot entry: the Windows Loader directly"
$bcd = Join-Path $B "BCD"
Py "$Pkg\scripts\fatget.py" (Join-Path $B "EFIESP.img") "EFI\Microsoft\boot\BCD" $bcd
Py "$Tools\bcdpatch.py" $disk 237568 65536 $bcd "guid:{9dea862c-5cdd-4e70-acc1-f32b344d4795}:24000002:{01de5a27-8705-40db-bad6-96fa5187d4a6}:{7619dcc9-fafe-11d9-b411-000476eba25f}"

Say "3/8 registry: display, touch and buttons controller"
$sys = Join-Path $B "SYSTEM"
Py "$Tools\ntfs-read-file.py" $disk 327680 $main "Windows\System32\config\SYSTEM" $sys
Copy-Item $sys "$sys.orig" -Force
Py "$Tools\hivedit.py" $sys "ControlSet001\Enum\Root\BASICDISPLAY\0000" "HardwareID=multi:ROOT\BasicDisplay" "ConfigFlags=dword:0" "Service=sz:BasicDisplay" "ClassGUID=sz:{4d36e968-e325-11ce-bfc1-08002be10318}"
Py "$Tools\hivedit.py" $sys "ControlSet001\Control\GraphicsDrivers\BasicDisplay" "EnableBasicDisplayFallback=dword:1"
Py "$Tools\hivedit.py" $sys "ControlSet001\Enum\ACPI\QEMU0D10\0" "HardwareID=multi:ACPI\VEN_QEMU&DEV_0D10|ACPI\QEMU0D10|*QEMU0D10" "CompatibleIDs=multi:ACPI\PNP0D10|*PNP0D10" "ConfigFlags=dword:0" "Service=sz:USBXHCI" "ClassGUID=sz:{36fc9e60-c465-11cf-8056-444553540000}"
Py "$Tools\hivedit.py" $sys "ControlSet001\Services\TSDDD\DEVICE0"
Py "$Tools\ntfs-patch-file.py" $disk 327680 $main "Windows\System32\config\SYSTEM" $sys "$sys.orig"

Say "4/8 registry: the shell's resolution, setup without questions"
$sw = Join-Path $B "SOFTWARE"
Py "$Tools\ntfs-read-file.py" $disk 327680 $main "Windows\System32\config\SOFTWARE" $sw
Copy-Item $sw "$sw.orig" -Force
Py "$Tools\hivedit.py" $sw "Microsoft\UIX" "ResolutionOverrideWidth=dword:1440" "ResolutionOverrideHeight=dword:2560" "ScreenResolution=sz:1440x2560"
Py "$Tools\hivedit.py" $sw "Microsoft\Shell\OOBE" "OobeHeadless=dword:1"
Py "$Tools\hivedit.py" $sw "Microsoft\Shell\LogicalResolution" "Width=dword:720" "Height=dword:1280"
Py "$Tools\ntfs-patch-file.py" $disk 327680 $main "Windows\System32\config\SOFTWARE" $sw "$sw.orig"

Say "5/8 apps closing on a tap: CoreUIComponents.dll, InputHost.dll"
Py "$Tools\wof-patch.py" $disk $main "Windows\System32\CoreUIComponents.dll" bb64e 13dc 00bf bb65a 0ddc 00bf
Py "$Tools\wof-patch.py" $disk $main "Windows\System32\InputHost.dll" c04a b44c 0024

Say "6/8 first start of Windows (setup, ~$SetupMinutes min): QEMU on this PC, no window"
# the same machine as on the phone; UEFI and the Windows Loader read the USB copy, Windows the UFS one
$env:W10M_ID_PFR1 = "10011"
$vars = Join-Path $B "vars.fd"
for ($round = 1; $round -le 3; $round++) {
    Copy-Item (Join-Path $Phone "edk2-arm-vars.fd") $vars -Force
    foreach ($o in "usb", "ufs") { Remove-Item (Join-Path $B "$o.qcow2") -ErrorAction SilentlyContinue; & $qimg create -q -f qcow2 -b disk.qcow2 -F qcow2 (Join-Path $B "$o.qcow2") }
    $qargs = @("-M", "virt,highmem=off,gic-version=2", "-cpu", "cortex-a15", "-smp", "4", "-m", "2048",
        "-drive", "if=pflash,format=raw,readonly=on,file=$(Join-Path $Phone 'edk2-arm-code.fd')", "-drive", "if=pflash,format=raw,file=$vars",
        "-device", "ramfb", "-device", "qemu-xhci,id=xhci,bus=pcie.0,addr=0x2", "-device", "usb-kbd,bus=xhci.0",
        "-display", "none", "-nic", "none", "-action", "reboot=shutdown", "-qmp", "tcp:127.0.0.1:4459,server=on,wait=off",
        "-drive", "if=none,id=d0,format=qcow2,file=$(Join-Path $B 'usb.qcow2')", "-device", "usb-storage,bus=xhci.0,drive=d0,removable=on,bootindex=1",
        "-device", "ufs,id=ufs0,serial=w10m,bus=pcie.0,addr=0x3", "-drive", "if=none,id=ufsd,format=qcow2,file=$(Join-Path $B 'ufs.qcow2')",
        "-device", "ufs-lu,drive=ufsd,lun=0,block-size=512", "-device", "qemu-xhci,id=inxhci,bus=pcie.0,addr=0x8",
        "-device", "usb-touchscreen,bus=inxhci.0", "-device", "usb-phone-buttons,bus=inxhci.0,id=btn",
        "-drive", "if=none,id=shim,format=raw,file=fat:16:shimfs,readonly=on", "-device", "usb-storage,bus=xhci.0,drive=shim,bootindex=0")
    # fat:16: wants a path without a drive letter: QEMU runs in phone\ (shimfs\EFI\BOOT\BOOTARM.EFI)
    $err = Join-Path $B "qemu-stderr.txt"
    $t0 = Get-Date
    $q = Start-Process (Join-Path $Pc "qemu-system-arm.exe") -ArgumentList $qargs -WorkingDirectory $Phone -WindowStyle Hidden -PassThru -RedirectStandardError $err
    $done = $q.WaitForExit($SetupMinutes * 60 * 1000)
    if ($done -and ((Get-Date) - $t0).TotalSeconds -lt 60) {
        throw "QEMU stopped at once: $((Get-Content $err -ErrorAction SilentlyContinue) -join ' ')"
    }
    if (-not $done) { Stop-Process -Id $q.Id -Force; Start-Sleep 2 }
    # what Windows wrote stays: the UFS copy goes into the disk
    & $qimg commit -q (Join-Path $B "ufs.qcow2"); if ($LASTEXITCODE) { throw "qemu-img commit failed" }
    if (-not $done) { break }                      # still running at the end: setup is over
    Write-Host "Windows restarted during setup: going on ($round)"
}

Say "7/8 background services off: search indexing, updates, diagnostics (in RAM they start over at every boot)"
# what setup left in the hive is read from the disk as it is now (NTFS_LIVE_RECORD: the MFT as Windows wrote it)
$env:NTFS_LIVE_RECORD = "1"
$sys2 = Join-Path $B "SYSTEM.after-setup"
Py "$Tools\ntfs-read-file.py" $disk 327680 $main "Windows\System32\config\SYSTEM" $sys2
Copy-Item $sys2 "$sys2.orig" -Force
foreach ($svc in "WSearch", "BITS", "MapsBroker", "wuauserv", "UsoSvc", "FlightingService", "DiagnosticSvc") {
    Py "$Tools\hivedit.py" $sys2 "ControlSet001\Services\$svc" "Start=dword:4"
}
Py "$Tools\ntfs-patch-file.py" $disk 327680 $main "Windows\System32\config\SYSTEM" $sys2 "$sys2.orig"
Remove-Item Env:\NTFS_LIVE_RECORD

Say "8/8 disk\w10m.qcow2"
$final = Join-Path $Out "w10m.qcow2"
& $qimg convert -c -O qcow2 $disk $final; if ($LASTEXITCODE) { throw "qemu-img convert failed" }
Write-Host ("done: {0} ({1:N1} GB). The build folder ({2}) can be deleted." -f $final, ((Get-Item $final).Length / 1GB), $B) -ForegroundColor Green
