"""Patch bytes of a WOF-compressed (XPRESS Huffman) file on MainOS inside a persistent disk (qcow2), in place.

The 4K chunk holding the bytes is decompressed, patched, compressed again (ntdll RtlCompressBuffer,
XPRESS_HUFF | maximum) and written over the old chunk inside the file's WofCompressedData stream, padded
with zeros: the chunk table, the stream size and the MFT stay as they are, so this only works when the
new chunk is not longer than the old one (checked; the padded chunk is test-decompressed first). Only the
changed sectors are written (tools/qcowpoke.py), after checking that the disk still holds the image's bytes there.
QEMU must not be running on the disk.

Usage: python -I tools/wof-patch.py <disk.qcow2> <MainOS.img> <path\\in\\MainOS> <rva> <oldhex> <newhex> [<rva> <oldhex> <newhex> ...]
"""
import ctypes
import importlib.util
import os
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def load(name, file):
    spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, file))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


wof = load("wof", "wof.py")
npf = load("npf", "ntfs-patch-file.py")
qcowpoke = load("qcowpoke", "qcowpoke.py")
MAINOS_LBA = 327680


def compress(data):
    nt = ctypes.WinDLL("ntdll")
    fmt = wof.COMPRESSION_FORMAT_XPRESS_HUFF | 0x100          # COMPRESSION_ENGINE_MAXIMUM
    ws, fr = ctypes.c_ulong(), ctypes.c_ulong()
    nt.RtlGetCompressionWorkSpaceSize(fmt, ctypes.byref(ws), ctypes.byref(fr))
    work = ctypes.create_string_buffer(ws.value)
    out, fin = ctypes.create_string_buffer(2 * len(data)), ctypes.c_ulong()
    st = nt.RtlCompressBuffer(fmt, data, len(data), out, len(out), 4096, ctypes.byref(fin), work)
    if st != 0:
        raise RuntimeError("RtlCompressBuffer NTSTATUS %#x" % (st & 0xFFFFFFFF))
    return out.raw[:fin.value]


def main():
    disk, img_path, vpath = sys.argv[1], sys.argv[2], sys.argv[3]
    edits = [(int(sys.argv[i], 16), bytes.fromhex(sys.argv[i + 1]), bytes.fromhex(sys.argv[i + 2]))
             for i in range(4, len(sys.argv) - 2, 3)]
    if not edits or (len(sys.argv) - 4) % 3:
        sys.exit("give <rva> <oldhex> <newhex> once or more")
    stream = subprocess.run([wof.SEVENZIP, "e", "-so", img_path, vpath + ":WofCompressedData"],
                            capture_output=True, check=True).stdout
    size, _, cs, recno = npf.locate(img_path, vpath)           # the main stream: the real size
    data, chunk = wof.unwof(stream, size)
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    ns = struct.unpack_from("<H", data, pe + 6)[0]
    so = pe + 24 + struct.unpack_from("<H", data, pe + 20)[0]
    plain_all = bytearray(data)
    touched = set()
    for rva, old, new in edits:
        fo = next(ro + rva - va for vs, va, rs, ro in (struct.unpack_from("<IIII", data, so + 40 * i + 8) for i in range(ns))
                  if va <= rva < va + rs)
        if data[fo:fo + len(old)] != old:
            sys.exit("bytes at %#x are %s, not %s" % (rva, data[fo:fo + len(old)].hex(), old.hex()))
        plain_all[fo:fo + len(new)] = new
        touched.update(range(fo // chunk, (fo + len(new) - 1) // chunk + 1))
    tbl, offs = wof.chunk_table(stream, size, chunk)
    newstream = bytearray(stream)
    report = []
    # every chunk an edit touches (several edits may share one) is compressed again in its old place
    for ci in sorted(touched):
        plain = bytes(plain_all[ci * chunk:(ci + 1) * chunk])
        comp, room = compress(plain), offs[ci + 1] - offs[ci]
        if len(comp) > room:
            sys.exit("chunk %d compresses to %d bytes, only %d available" % (ci, len(comp), room))
        used = len(comp)
        comp += bytes(room - len(comp))
        if wof.xpress_decompress(comp, len(plain)) != plain:
            sys.exit("the padded chunk does not decompress back")
        newstream[tbl + offs[ci]:tbl + offs[ci + 1]] = comp
        report.append("chunk %d %d -> %d bytes (+%d zero)" % (ci, room, used, room - used))
    # where the WofCompressedData stream lives: its runs in the file's MFT record (raw image)
    img = open(img_path, "rb")
    bs = img.read(512)
    bps = struct.unpack_from("<H", bs, 11)[0]
    c = struct.unpack_from("<b", bs, 0x40)[0]
    rs = c * cs if c > 0 else 1 << -c
    img.seek(struct.unpack_from("<Q", bs, 0x30)[0] * cs)
    rec0 = npf.fixup(bytearray(img.read(rs)), bps)
    off, vcn = recno * rs, 0
    for lcn, n in next(npf.runlist(rec0, o) for t, o in npf.attrs(rec0) if t == 0x80):
        if off < (vcn + n) * cs:
            break
        vcn += n
    img.seek(lcn * cs + off - vcn * cs)
    rec = npf.fixup(bytearray(img.read(rs)), bps)
    runs = None
    for t, o in npf.attrs(rec):
        nl, no = rec[o + 9], struct.unpack_from("<H", rec, o + 0x0A)[0]
        if t == 0x80 and rec[o + no:o + no + 2 * nl].decode("utf-16le") == "WofCompressedData" and rec[o + 8]:
            runs = npf.runlist(rec, o)
    if runs is None:
        sys.exit("no non-resident WofCompressedData stream in record %d" % recno)

    def disk_off(x):
        v, rem = divmod(x, cs)
        for lcn_, n in runs:
            if v < n:
                return MAINOS_LBA * 512 + (lcn_ + v) * cs + rem
            v -= n

    padded_old = stream + bytes(-len(stream) % 512)
    padded_new = bytes(newstream) + bytes(-len(newstream) % 512)
    secs = [s for s in range(0, len(padded_old), 512) if padded_old[s:s + 512] != padded_new[s:s + 512]]
    tmp = os.path.join(os.environ.get("TEMP", "."), "wof-patch-sector.bin")
    for s in secs:
        opts = "driver=raw,offset=%d,size=512,file.driver=qcow2,file.file.filename=%s" % (disk_off(s), disk)
        subprocess.run([os.path.join(os.environ.get("W10M_QEMU_DIR", r"C:\Program Files\qemu"), "qemu-img.exe"), "convert", "--image-opts", opts, "-O", "raw", tmp], check=True)
        if open(tmp, "rb").read() != padded_old[s:s + 512]:
            sys.exit("sector at stream offset %#x differs on the disk: not the image's file (already patched?)" % s)
    n = sum(qcowpoke.poke(disk, disk_off(s), padded_old[s:s + 512], padded_new[s:s + 512]) for s in secs)
    print("%s: %s; %s; %d sectors written (%d qemu-io writes)"
          % (vpath, ", ".join("+%#x %s -> %s" % (r, o.hex(), w.hex()) for r, o, w in edits), "; ".join(report), len(secs), n))


if __name__ == "__main__":
    main()
