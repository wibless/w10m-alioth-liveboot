"""Read a file out of an NTFS partition inside a qcow2 image/overlay (e.g. a hive after a guest run).

Clusters come from the file's MFT record in a raw image of the same partition (the file must not
have been moved or resized by the guest; checked loosely by size); the data is read from the qcow2
with qemu-img (read-only).

Set NTFS_LIVE_RECORD=1 to take the file's MFT record from the qcow2 (file grown by the guest).

Usage: python -I tools/ntfs-read-file.py <disk.qcow2> <part_first_lba> <ntfs_partition.img> <path\\in\\volume> <out_file>
"""
import os
import struct
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import importlib.util  # noqa: E402

spec = importlib.util.spec_from_file_location("npf", os.path.join(os.path.dirname(os.path.abspath(__file__)), "ntfs-patch-file.py"))
npf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(npf)

QEMU_IMG = os.path.join(os.environ.get("W10M_QEMU_DIR", r"C:\Program Files\qemu"), "qemu-img.exe")


def live_record(disk, first, img_path, recno, cs, tmp):
    bs = open(img_path, "rb").read(512)
    bps = struct.unpack_from("<H", bs, 11)[0]
    mft_lcn = struct.unpack_from("<Q", bs, 0x30)[0]
    c = struct.unpack_from("<b", bs, 0x40)[0]
    rs = c * cs if c > 0 else 1 << -c
    img = open(img_path, "rb")
    img.seek(mft_lcn * cs)
    r0 = npf.fixup(bytearray(img.read(rs)), bps)
    mft_runs = next(npf.runlist(r0, o) for t, o in npf.attrs(r0) if t == 0x80)
    off = recno * rs
    for lcn, n in mft_runs:
        if off < n * cs:
            break
        off -= n * cs
    part = os.path.join(tmp, "rec.bin")
    opts = "driver=raw,offset=%d,size=%d,file.driver=qcow2,file.file.filename=%s" % (
        first * 512 + lcn * cs + off, rs, disk)
    subprocess.run([QEMU_IMG, "convert", "--image-opts", opts, "-O", "raw", part], check=True)
    rec = npf.fixup(bytearray(open(part, "rb").read()), bps)
    t, o = [(t, o) for t, o in npf.attrs(rec) if t == 0x80 and rec[o + 9] == 0][0]
    return struct.unpack_from("<Q", rec, o + 0x30)[0], npf.runlist(rec, o)


def main():
    disk, first, img_path, vpath, out = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5]
    size, runs, cs, recno = npf.locate(img_path, vpath)
    tmp = tempfile.mkdtemp()
    if os.environ.get("NTFS_LIVE_RECORD"):
        # the guest may have grown/moved the file: take its MFT record from the qcow2 itself
        # (the MFT's own runs still come from the raw image)
        size, runs = live_record(disk, first, img_path, recno, cs, tmp)
    data = bytearray()
    for i, (lcn, n) in enumerate(runs):
        if lcn is None:
            data += bytes(n * cs)
            continue
        part = os.path.join(tmp, "r%d.bin" % i)
        opts = "driver=raw,offset=%d,size=%d,file.driver=qcow2,file.file.filename=%s" % (
            first * 512 + lcn * cs, n * cs, disk)
        subprocess.run([QEMU_IMG, "convert", "--image-opts", opts, "-O", "raw", part], check=True)
        data += open(part, "rb").read()
    open(out, "wb").write(data[:size])
    print("%s: %d bytes from %d runs" % (vpath, size, len(runs)))


if __name__ == "__main__":
    main()
