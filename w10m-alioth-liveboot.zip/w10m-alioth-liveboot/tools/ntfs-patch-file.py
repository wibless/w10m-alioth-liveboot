"""Overwrite a file inside an NTFS partition of a QEMU qcow2 overlay with a same-size new version.

The file's clusters are found from its MFT record in a raw image of the same partition (e.g.
work\\MainOS.img, identical to the base disk's partition); only 512-byte sectors that differ are
written, with qemu-io, into the overlay (never the base disk). The size must not change (no MFT edit).

Usage: python -I tools/ntfs-patch-file.py <overlay.qcow2> <part_first_lba> <ntfs_partition.img> <path\\in\\volume> <new_file>
       NTFS_LIVE_RECORD=1 ... <new_file> <current_copy>   (file grown by the guest: runs from the qcow2's MFT,
                                                         current content as read by ntfs-read-file.py)
  e.g. ... work\\run-x-ufs.qcow2 327680 work\\MainOS.img Windows\\System32\\config\\SYSTEM <scratch>\\SYSTEM
"""
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import qcowpoke  # noqa: E402


def fixup(rec, sector=512):
    uo, un = struct.unpack_from("<HH", rec, 4)
    usn = rec[uo:uo + 2]
    for i in range(1, un):
        e = i * sector - 2
        if rec[e:e + 2] != usn:
            return None
        rec[e:e + 2] = rec[uo + 2 * i:uo + 2 * i + 2]
    return rec


def runlist(rec, ao):
    o = ao + struct.unpack_from("<H", rec, ao + 0x20)[0]
    runs, lcn = [], 0
    while rec[o]:
        h = rec[o]
        ln, lo = h & 0xF, h >> 4
        n = int.from_bytes(rec[o + 1:o + 1 + ln], "little")
        d = int.from_bytes(rec[o + 1 + ln:o + 1 + ln + lo], "little", signed=True) if lo else None
        if d is None:
            runs.append((None, n))             # sparse
        else:
            lcn += d
            runs.append((lcn, n))
        o += 1 + ln + lo
    return runs


def attrs(rec):
    o = struct.unpack_from("<H", rec, 0x14)[0]
    while o + 8 <= len(rec):
        t, ln = struct.unpack_from("<II", rec, o)
        if t == 0xFFFFFFFF or ln == 0:
            break
        yield t, o
        o += ln


def locate(img_path, vpath):
    """(size, runs [(lcn|None, clusters)], cluster size, MFT record number) of a file in a raw NTFS image."""
    img = open(img_path, "rb")
    bs = img.read(512)
    bps, spc = struct.unpack_from("<HB", bs, 11)
    cs = bps * spc
    mft_lcn = struct.unpack_from("<Q", bs, 0x30)[0]
    c = struct.unpack_from("<b", bs, 0x40)[0]
    rs = c * cs if c > 0 else 1 << -c

    def read_rec(runs, i):
        off = i * rs
        for lcn, n in runs:
            if off < n * cs:
                img.seek(lcn * cs + off)
                return fixup(bytearray(img.read(rs)), bps)
            off -= n * cs
        return None

    img.seek(mft_lcn * cs)
    r0 = fixup(bytearray(img.read(rs)), bps)
    mft_runs = next(runlist(r0, o) for t, o in attrs(r0) if t == 0x80)
    total = sum(n for _, n in mft_runs) * cs // rs
    # parent ref + name of every record ($FILE_NAME, Win32/POSIX namespace preferred)
    names = {}
    for i in range(total):
        r = read_rec(mft_runs, i)
        if r is None or r[:4] != b"FILE" or not struct.unpack_from("<H", r, 0x16)[0] & 1:
            continue
        best = None
        for t, o in attrs(r):
            if t == 0x30:
                v = o + struct.unpack_from("<H", r, o + 0x14)[0]
                parent = struct.unpack_from("<Q", r, v)[0] & 0xFFFFFFFFFFFF
                nl, ns = r[v + 0x40], r[v + 0x41]
                nm = r[v + 0x42:v + 0x42 + 2 * nl].decode("utf-16le")
                if best is None or ns != 2:
                    best = (parent, nm)
        if best:
            names[i] = best
    want = [p.upper() for p in vpath.split("\\")]
    cur = 5
    for part in want:
        cur = next((i for i, (p, n) in names.items() if p == cur and n.upper() == part and i != cur), None)
        if cur is None:
            sys.exit("path element %s not found" % part)
    rec = read_rec(mft_runs, cur)
    data = [(t, o) for t, o in attrs(rec) if t == 0x80 and rec[o + 9] == 0]   # unnamed $DATA
    t, o = data[0]
    if not rec[o + 8]:
        sys.exit("resident $DATA: not supported")
    return struct.unpack_from("<Q", rec, o + 0x30)[0], runlist(rec, o), cs, cur


def main():
    overlay, first, img_path, vpath, newf = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5]
    size, runs, cs, cur = locate(img_path, vpath)
    img = open(img_path, "rb")
    new = open(newf, "rb").read()
    if os.environ.get("NTFS_LIVE_RECORD"):
        # the file as the guest left it (grown/moved): runs from its MFT record in the qcow2, original
        # content = argv[6], the copy tools/ntfs-read-file.py read with NTFS_LIVE_RECORD=1
        import importlib.util
        import tempfile
        spec = importlib.util.spec_from_file_location("nrf", os.path.join(os.path.dirname(os.path.abspath(__file__)), "ntfs-read-file.py"))
        nrf = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(nrf)
        size, runs = nrf.live_record(overlay, first, img_path, cur, cs, tempfile.mkdtemp())
        orig = open(sys.argv[6], "rb").read()
        if len(orig) != size:
            sys.exit("the original copy does not match the live record (%d vs %d)" % (len(orig), size))
    else:
        # original content via the runs, then the differing sectors
        orig = bytearray()
        for lcn, n in runs:
            if lcn is None:
                orig += bytes(n * cs)
            else:
                img.seek(lcn * cs)
                orig += img.read(n * cs)
        orig = orig[:size]
    if len(new) != size:
        sys.exit("size differs: file %d, new %d" % (size, len(new)))
    print("MFT record %d, %d bytes, %d runs, cluster %d" % (cur, size, len(runs), cs))

    def disk_off(fo):
        vcn, rem = divmod(fo, cs)
        for lcn, n in runs:
            if vcn < n:
                return first * 512 + (lcn + vcn) * cs + rem
            vcn -= n

    secs = [s for s in range(0, size, 512) if orig[s:s + 512] != new[s:s + 512]]
    if len(secs) > 200:
        sys.exit("%d sectors differ: the new file is not an edit of this one (or the image differs)" % len(secs))
    n = 0
    for s in secs:
        n += qcowpoke.poke(overlay, disk_off(s), orig[s:s + 512], new[s:s + 512])
    print("wrote and verified %d sectors (%d qemu-io writes)" % (len(secs), n))


if __name__ == "__main__":
    main()
