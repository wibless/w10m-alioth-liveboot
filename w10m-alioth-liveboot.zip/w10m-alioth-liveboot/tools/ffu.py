"""Read-only FFU (Full Flash Update) inspector / partition extractor.

Usage:
  python -I tools/ffu.py info  <file.ffu>
  python -I tools/ffu.py gpt   <file.ffu>
  python -I tools/ffu.py extract <file.ffu> <PARTITION_NAME> <out.img>
  python -I tools/ffu.py disk    <file.ffu> <out.img>

The FFU is only ever opened for reading. `extract` writes a sparse raw
image of one GPT partition (blocks absent from the FFU stay zero).
"""
import struct
import subprocess
import sys
import uuid

SECTOR = 512


def align(n, a):
    return (n + a - 1) // a * a


class Ffu:
    def __init__(self, path):
        self.path = path
        self.f = open(path, "rb")
        self.f.seek(0, 2)
        self.size = self.f.tell()
        self._parse()

    def _read(self, off, n):
        self.f.seek(off)
        return self.f.read(n)

    def _parse(self):
        cb, sig, chunk_kb, alg, cat, hashtab = struct.unpack("<I12sIIII", self._read(0, 32))
        if sig != b"SignedImage ":
            raise ValueError("no SignedImage header: %r" % sig)
        self.chunk = chunk_kb * 1024
        self.sec = dict(cbSize=cb, chunk_kb=chunk_kb, alg=hex(alg), catalog=cat, hashtable=hashtab)
        off = align(cb + cat + hashtab, self.chunk)

        cb, sig, mlen, ichunk = struct.unpack("<I12sII", self._read(off, 24))
        if sig != b"ImageFlash  ":
            raise ValueError("no ImageFlash header at %#x: %r" % (off, sig))
        self.manifest = self._read(off + cb, mlen).decode("ascii", "replace")
        off = align(off + cb + mlen, self.chunk)

        self.store_off = off
        h = self._read(off, 248)
        (upd, maj, minr, ffmaj, ffmin) = struct.unpack_from("<IHHHH", h, 0)
        platform = h[12:12 + 192].split(b"\0", 1)[0].decode("ascii", "replace")
        (bs, wcount, wlen, vcount, vlen) = struct.unpack_from("<IIIII", h, 204)
        hdr = 248
        if maj >= 2:  # FFU v2 (multi-store) adds fields after the v1 header
            raise NotImplementedError("FFU store header v2 not handled yet (major=%d)" % maj)
        self.store = dict(update_type=upd, version="%d.%d" % (maj, minr),
                          full_flash="%d.%d" % (ffmaj, ffmin), platform=platform,
                          block_size=bs, write_descriptors=wcount,
                          write_desc_len=wlen, validate_count=vcount, validate_len=vlen)
        self.block = bs
        p = off + hdr + vlen
        raw = self._read(p, wlen)
        self.descs = []  # (data_offset_index, [(method, block_index)], block_count)
        i = 0
        data_blocks = 0
        while i < len(raw):
            lc, bc = struct.unpack_from("<II", raw, i)
            i += 8
            locs = [struct.unpack_from("<II", raw, i + 8 * k) for k in range(lc)]
            i += 8 * lc
            self.descs.append((data_blocks, locs, bc))
            data_blocks += bc
        self.data_off = align(p + wlen, self.chunk)
        self.data_blocks = data_blocks
        self.expected_size = self.data_off + data_blocks * bs

    def disk_blocks(self):
        """Map disk block index -> FFU data block index (method 0 = from start only)."""
        m = {}
        end_relative = []
        for start, locs, bc in self.descs:
            for method, idx in locs:
                for k in range(bc):
                    if method == 0:
                        m[idx + k] = start + k
                    else:
                        end_relative.append((idx + k, start + k))
        return m, end_relative

    def read_data_block(self, n):
        return self._read(self.data_off + n * self.block, self.block)

    def read_disk(self, offset, length, bmap):
        out = bytearray()
        while length > 0:
            b, o = divmod(offset, self.block)
            take = min(length, self.block - o)
            if b in bmap:
                out += self.read_data_block(bmap[b])[o:o + take]
            else:
                out += b"\0" * take
            offset += take
            length -= take
        return bytes(out)

    def gpt(self, bmap):
        hdr = self.read_disk(SECTOR, SECTOR, bmap)
        if hdr[:8] != b"EFI PART":
            raise ValueError("no GPT header at LBA1")
        lba, n, esz = struct.unpack_from("<QII", hdr, 72)
        ents = self.read_disk(lba * SECTOR, n * esz, bmap)
        parts = []
        for k in range(n):
            e = ents[k * esz:(k + 1) * esz]
            if e[:16] == b"\0" * 16:
                continue
            first, last = struct.unpack_from("<QQ", e, 32)
            name = e[56:128].decode("utf-16-le").rstrip("\0")
            parts.append(dict(name=name, type=str(uuid.UUID(bytes_le=e[:16])),
                              first=first, last=last))
        return parts


def cmd_info(ffu):
    print("file:", ffu.path)
    print("size:", ffu.size)
    print("security:", ffu.sec)
    print("store:", ffu.store)
    print("write descriptors:", len(ffu.descs), "data blocks:", ffu.data_blocks)
    print("data offset:", ffu.data_off)
    print("expected size:", ffu.expected_size,
          "->", "COMPLETE" if ffu.expected_size == ffu.size else "MISMATCH (%+d)" % (ffu.size - ffu.expected_size))
    print("--- manifest ---")
    print(ffu.manifest.strip())


def cmd_gpt(ffu):
    bmap, endrel = ffu.disk_blocks()
    print("disk blocks mapped from start:", len(bmap), "end-relative:", len(endrel))
    for p in ffu.gpt(bmap):
        size = (p["last"] - p["first"] + 1) * SECTOR
        present = sum(1 for b in range(p["first"] * SECTOR // ffu.block,
                                       (p["last"] + 1) * SECTOR // ffu.block + 1) if b in bmap)
        print("%-24s first=%-9d last=%-9d size=%8.1f MiB  blocks_in_ffu=%d  type=%s"
              % (p["name"], p["first"], p["last"], size / 2**20, present, p["type"]))


def cmd_extract(ffu, name, out):
    bmap, _ = ffu.disk_blocks()
    part = next((p for p in ffu.gpt(bmap) if p["name"] == name), None)
    if not part:
        sys.exit("partition %s not found" % name)
    start = part["first"] * SECTOR
    size = (part["last"] - part["first"] + 1) * SECTOR
    with open(out, "wb") as o:
        pass
    subprocess.run(["fsutil", "sparse", "setflag", out], check=False, capture_output=True)
    written = 0
    with open(out, "r+b") as o:
        o.truncate(size)
        b0 = start // ffu.block
        b1 = (start + size - 1) // ffu.block
        for b in range(b0, b1 + 1):
            if b not in bmap:
                continue
            data = ffu.read_data_block(bmap[b])
            dstart = b * ffu.block
            lo = max(dstart, start)
            hi = min(dstart + ffu.block, start + size)
            o.seek(lo - start)
            o.write(data[lo - dstart:hi - dstart])
            written += hi - lo
    print("extracted %s: %d bytes logical, %d bytes of data" % (name, size, written))


def cmd_disk(ffu, out):
    """Whole-disk sparse raw image; DISK_END blocks are placed from the GPT backup LBA."""
    bmap, endrel = ffu.disk_blocks()
    hdr = ffu.read_disk(SECTOR, SECTOR, bmap)
    alt_lba = struct.unpack_from("<Q", hdr, 32)[0]
    size = (alt_lba + 1) * SECTOR
    open(out, "wb").close()
    subprocess.run(["fsutil", "sparse", "setflag", out], check=False, capture_output=True)
    total_blocks = size // ffu.block
    with open(out, "r+b") as o:
        o.truncate(size)
        for b, n in sorted(bmap.items()):
            o.seek(b * ffu.block)
            o.write(ffu.read_data_block(n))
        for idx, n in endrel:
            o.seek((total_blocks - 1 - idx) * ffu.block)
            o.write(ffu.read_data_block(n))
    print("disk: %d bytes (%d sectors, backup GPT at LBA %d), %d blocks from start, %d from end"
          % (size, size // SECTOR, alt_lba, len(bmap), len(endrel)))


def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    ffu = Ffu(sys.argv[2])
    {"info": lambda: cmd_info(ffu),
     "gpt": lambda: cmd_gpt(ffu),
     "extract": lambda: cmd_extract(ffu, sys.argv[3], sys.argv[4]),
     "disk": lambda: cmd_disk(ffu, sys.argv[3])}[sys.argv[1]]()


if __name__ == "__main__":
    main()
