"""Extract WOF-compressed (XPRESS) files from an NTFS partition image via 7-Zip.

7-Zip lists WOF files with an empty main stream and the data in the
`:WofCompressedData` alternate stream. This dumps that stream with `7z -so`
and decompresses it with ntdll!RtlDecompressBufferEx (XPRESS Huffman).

Usage:
  python -I tools/wof.py <ntfs.img> <out_dir> <path-in-image> [...]
"""
import ctypes
import os
import re
import subprocess
import sys

SEVENZIP = os.environ.get("W10M_7Z", r"C:\Program Files\7-Zip\7z.exe")
COMPRESSION_FORMAT_XPRESS_HUFF = 4
ntdll = ctypes.WinDLL("ntdll")


def xpress_decompress(data, out_size):
    ws_size = ctypes.c_ulong()
    frag = ctypes.c_ulong()
    ntdll.RtlGetCompressionWorkSpaceSize(COMPRESSION_FORMAT_XPRESS_HUFF,
                                         ctypes.byref(ws_size), ctypes.byref(frag))
    ws = ctypes.create_string_buffer(ws_size.value)
    out = ctypes.create_string_buffer(out_size)
    final = ctypes.c_ulong()
    st = ntdll.RtlDecompressBufferEx(COMPRESSION_FORMAT_XPRESS_HUFF, out, out_size,
                                     data, len(data), ctypes.byref(final), ws)
    if st != 0:
        raise RuntimeError("RtlDecompressBufferEx NTSTATUS %#x" % (st & 0xFFFFFFFF))
    return out.raw[:final.value]


def chunk_table(stream, size, chunk):
    n = (size + chunk - 1) // chunk
    tbl = 4 * (n - 1)
    if tbl > len(stream):
        return None
    ends = [int.from_bytes(stream[4 * i:4 * i + 4], "little") for i in range(n - 1)]
    offs = [0] + ends + [len(stream) - tbl]
    if any(b <= a for a, b in zip(offs, offs[1:])):
        return None
    return tbl, offs


def unwof(stream, size):
    for chunk in (4096, 8192, 16384):  # XPRESS4K / 8K / 16K
        t = chunk_table(stream, size, chunk)
        if not t:
            continue
        tbl, offs = t
        out = bytearray()
        try:
            for i in range(len(offs) - 1):
                c = stream[tbl + offs[i]:tbl + offs[i + 1]]
                want = min(chunk, size - i * chunk)
                out += c if len(c) == want else xpress_decompress(c, want)
        except RuntimeError:
            continue
        if len(out) == size:
            return bytes(out), chunk
    raise RuntimeError("not XPRESS4K/8K/16K (LZX is not supported)")


def listing_size(img, path):
    r = subprocess.run([SEVENZIP, "l", "-slt", img, path], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    m = re.search(r"^Path = %s\s*\nFolder = -\s*\nSize = (\d+)" % re.escape(path),
                  r.stdout, re.M | re.I)
    if not m:
        raise RuntimeError("not found in image: " + path)
    return int(m.group(1))


def main():
    img, out_dir, paths = sys.argv[1], sys.argv[2], sys.argv[3:]
    for p in paths:
        size = listing_size(img, p)
        r = subprocess.run([SEVENZIP, "e", img, "-so", p + ":WofCompressedData"], capture_output=True)
        dst = os.path.join(out_dir, p)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if r.returncode == 0 and r.stdout:
            data, chunk = unwof(r.stdout, size)
            how = "wof xpress%dk" % (chunk // 1024)
        else:
            data = subprocess.run([SEVENZIP, "e", img, "-so", p], capture_output=True, check=True).stdout
            how = "plain"
        with open(dst, "wb") as f:
            f.write(data)
        print("%-60s %10d  %s" % (p, len(data), how))


if __name__ == "__main__":
    main()
