"""Minimal offline registry hive (regf 1.x) editor: add a key path with values, in place.

New cells go into free cells of existing bins (the file never grows, so it can be written back over
the same disk clusters); the parent's subkey list (lf/lh/li/ri) is rebuilt sorted; the parent's
security cell is shared (reference count raised); sequence numbers are bumped equally (clean hive)
and the header checksum recomputed. Existing keys on the path are reused; existing values replaced.

Usage:
  python -I tools/hivedit.py <hive> <key\\path> NAME=TYPE:VALUE [...]
    TYPE: sz | multi (values separated by |) | dword (hex or decimal)
  e.g. python -I tools/hivedit.py SYSTEM "ControlSet001\\Enum\\Root\\BASICDISPLAY\\0000" ^
           "HardwareID=multi:ROOT\\BASICDISPLAY" ConfigFlags=dword:0x20 Service=sz:BasicDisplay
"""
import struct
import sys
import time

BASE = 0x1000
REG_SZ, REG_DWORD, REG_MULTI_SZ = 1, 4, 7


class Hive:
    def __init__(self, path):
        self.path = path
        self.d = bytearray(open(path, "rb").read())
        if self.d[:4] != b"regf":
            raise SystemExit("not a regf hive")
        self.root = struct.unpack_from("<I", self.d, 0x24)[0]
        self.binslen = struct.unpack_from("<I", self.d, 0x28)[0]

    # cells -------------------------------------------------------------------------------------
    def cell(self, off):
        return BASE + off + 4

    def u16(self, off, i): return struct.unpack_from("<H", self.d, self.cell(off) + i)[0]
    def u32(self, off, i): return struct.unpack_from("<I", self.d, self.cell(off) + i)[0]
    def w32(self, off, i, v): struct.pack_into("<I", self.d, self.cell(off) + i, v & 0xFFFFFFFF)

    def free_cells(self):
        o = BASE
        while o < BASE + self.binslen:
            assert self.d[o:o + 4] == b"hbin", hex(o)
            size = struct.unpack_from("<I", self.d, o + 8)[0]
            c = o + 0x20
            while c < o + size:
                sz = struct.unpack_from("<i", self.d, c)[0]
                if sz > 0:
                    yield c - BASE, sz
                c += abs(sz)
            o += size

    def alloc(self, n):
        need = (n + 4 + 7) & ~7
        for off, sz in self.free_cells():
            if sz >= need:
                if sz - need >= 16:
                    struct.pack_into("<i", self.d, BASE + off + need, sz - need)
                else:
                    need = sz
                struct.pack_into("<i", self.d, BASE + off, -need)
                self.d[BASE + off + 4:BASE + off + need] = bytes(need - 4)
                return off
        # no room: add an hbin in the slack the file already has after the last one (the file size stays,
        # so the NTFS allocation does not change)
        size = (need + 0x20 + 0xFFF) & ~0xFFF
        if BASE + self.binslen + size <= len(self.d):
            o = BASE + self.binslen
            self.d[o:o + size] = bytes(size)
            self.d[o:o + 4] = b"hbin"
            struct.pack_into("<II", self.d, o + 4, self.binslen, size)
            struct.pack_into("<i", self.d, o + 0x20, size - 0x20)
            self.binslen += size
            struct.pack_into("<I", self.d, 0x28, self.binslen)
            return self.alloc(n)
        raise SystemExit("no free cell of %d bytes: the hive would have to grow" % need)

    def free(self, off):
        sz = struct.unpack_from("<i", self.d, BASE + off)[0]
        if sz < 0:
            struct.pack_into("<i", self.d, BASE + off, -sz)

    def put(self, data):
        off = self.alloc(len(data))
        self.d[self.cell(off):self.cell(off) + len(data)] = data
        return off

    # keys --------------------------------------------------------------------------------------
    def name(self, nk):
        n, flags = self.u16(nk, 0x48), self.u16(nk, 2)
        raw = bytes(self.d[self.cell(nk) + 0x4C:self.cell(nk) + 0x4C + n])
        return raw.decode("latin-1") if flags & 0x20 else raw.decode("utf-16le")

    def list_entries(self, lst):
        sig = bytes(self.d[self.cell(lst):self.cell(lst) + 2])
        cnt = self.u16(lst, 2)
        if sig in (b"lf", b"lh"):
            return [self.u32(lst, 4 + 8 * i) for i in range(cnt)]
        if sig == b"li":
            return [self.u32(lst, 4 + 4 * i) for i in range(cnt)]
        if sig == b"ri":
            out = []
            for i in range(cnt):
                out += self.list_entries(self.u32(lst, 4 + 4 * i))
            return out
        raise SystemExit("unknown subkey list " + repr(sig))

    def subkeys(self, nk):
        if self.u32(nk, 0x14) == 0:
            return []
        return self.list_entries(self.u32(nk, 0x1C))

    def child(self, nk, name):
        return next((k for k in self.subkeys(nk) if self.name(k).upper() == name.upper()), None)

    @staticmethod
    def lh_hash(name):
        h = 0
        for ch in name.upper():
            h = (h * 37 + ord(ch)) & 0xFFFFFFFF
        return h

    def add_key(self, parent, name):
        sec = self.u32(parent, 0x2C)
        nm = name.encode("latin-1")
        now = int((time.time() + 11644473600) * 1e7)
        nk = struct.pack("<2sHQIIIIIIIIIIIIIIIHH", b"nk", 0x20, now, 0, parent, 0, 0, 0xFFFFFFFF, 0xFFFFFFFF,
                         0, 0xFFFFFFFF, sec, 0xFFFFFFFF, 0, 0, 0, 0, 0, len(nm), 0) + nm
        off = self.put(nk)
        # share the parent's security descriptor
        self.w32(sec, 0x0C, self.u32(sec, 0x0C) + 1)
        # rebuild the parent's subkey list sorted case-insensitively: a flat lh list, or, for a big key
        # whose list is an ri index, only the leaf the new name falls into
        old = self.u32(parent, 0x1C) if self.u32(parent, 0x14) else None
        key = lambda k: self.name(k).upper()
        if old is not None and bytes(self.d[self.cell(old):self.cell(old) + 2]) == b"ri":
            leaves = [self.u32(old, 4 + 4 * i) for i in range(self.u16(old, 2))]
            firsts = [key(self.list_entries(lf)[0]) for lf in leaves]
            i = max([j for j, f in enumerate(firsts) if f <= name.upper()] or [0])
            kids = sorted(self.list_entries(leaves[i]) + [off], key=key)
            leaf = self.put(struct.pack("<2sH", b"lh", len(kids)) + b"".join(
                struct.pack("<II", k, self.lh_hash(self.name(k))) for k in kids))
            self.free(leaves[i])
            self.w32(old, 4 + 4 * i, leaf)
            lst = old
        else:
            kids = sorted(self.subkeys(parent) + [off], key=key)

            def lh(ks):
                return struct.pack("<2sH", b"lh", len(ks)) + b"".join(
                    struct.pack("<II", k, self.lh_hash(self.name(k))) for k in ks)
            body = lh(kids)
            if old is not None and -struct.unpack_from("<i", self.d, BASE + old)[0] - 4 >= len(body):
                lst = old                           # the old cell has room: rewrite in place
                self.d[self.cell(old):self.cell(old) + len(body)] = body
            else:
                if old is not None:
                    self.free(old)                  # its space is reused below
                try:
                    lst = self.put(body)
                except SystemExit:
                    # no free cell that big (e.g. Services): lh leaves packed into the largest free cells,
                    # under an ri index
                    leaves, rest = [], kids
                    while rest:
                        biggest = max(sz for _, sz in self.free_cells())
                        take = min(len(rest), (biggest - 8) // 8)
                        if take <= 0:
                            raise SystemExit("no free cell for a subkey leaf: the hive would have to grow")
                        leaves.append(self.put(lh(rest[:take])))
                        rest = rest[take:]
                    lst = self.put(struct.pack("<2sH", b"ri", len(leaves)) + b"".join(struct.pack("<I", x) for x in leaves))
        self.w32(parent, 0x14, self.u32(parent, 0x14) + 1)
        self.w32(parent, 0x1C, lst)
        if self.u32(parent, 0x34) < 2 * len(nm):
            self.w32(parent, 0x34, 2 * len(nm))
        return off

    def set_value(self, nk, name, typ, data):
        nm = name.encode("latin-1")
        if len(data) <= 4 and self.u32(nk, 0x24):
            # an existing value with inline data (DWORD): overwrite it in place, no new cells
            lst = self.u32(nk, 0x28)
            for i in range(self.u32(nk, 0x24)):
                v = self.u32(lst, 4 * i)
                c = self.cell(v)
                if (bytes(self.d[c + 0x14:c + 0x14 + self.u16(v, 2)]).decode("latin-1").upper() == name.upper()
                        and self.u32(v, 4) & 0x80000000 and self.u32(v, 0xC) == typ):
                    self.w32(v, 4, 0x80000000 | len(data))
                    self.w32(v, 8, struct.unpack("<I", data.ljust(4, b"\0"))[0])
                    return
        if len(data) <= 4:
            size, doff = 0x80000000 | len(data), struct.unpack("<I", data.ljust(4, b"\0"))[0]
        else:
            size, doff = len(data), self.put(data)
        vk = self.put(struct.pack("<2sHIIIHH", b"vk", len(nm), size, doff, typ, 1, 0) + nm)
        vals = []
        if self.u32(nk, 0x24):
            lst = self.u32(nk, 0x28)
            vals = [self.u32(lst, 4 * i) for i in range(self.u32(nk, 0x24))]
            vals = [v for v in vals if bytes(self.d[self.cell(v) + 0x14:self.cell(v) + 0x14 + self.u16(v, 2)])
                    .decode("latin-1").upper() != name.upper()]
            self.free(lst)
        vals.append(vk)
        self.w32(nk, 0x24, len(vals))
        self.w32(nk, 0x28, self.put(b"".join(struct.pack("<I", v) for v in vals)))
        if self.u32(nk, 0x3C) < 2 * len(nm):        # MaxValueNameLen
            self.w32(nk, 0x3C, 2 * len(nm))
        if self.u32(nk, 0x40) < len(data):           # MaxValueDataLen
            self.w32(nk, 0x40, len(data))

    def finish(self):
        s1, s2 = struct.unpack_from("<II", self.d, 4)
        seq = max(s1, s2) + 1
        struct.pack_into("<II", self.d, 4, seq, seq)
        struct.pack_into("<Q", self.d, 12, int((time.time() + 11644473600) * 1e7))
        x = 0
        for i in range(0, 0x1FC, 4):
            x ^= struct.unpack_from("<I", self.d, i)[0]
        struct.pack_into("<I", self.d, 0x1FC, x)
        open(self.path, "wb").write(self.d)


def encode(spec):
    name, rest = spec.split("=", 1)
    typ, val = rest.split(":", 1)
    if typ == "sz":
        return name, REG_SZ, (val + "\0").encode("utf-16le")
    if typ == "multi":
        return name, REG_MULTI_SZ, ("\0".join(val.split("|")) + "\0\0").encode("utf-16le")
    if typ == "dword":
        return name, REG_DWORD, struct.pack("<I", int(val, 0))
    raise SystemExit("unknown type " + typ)


def main():
    h = Hive(sys.argv[1])
    nk = h.root
    for part in sys.argv[2].split("\\"):
        c = h.child(nk, part)
        nk = c if c is not None else h.add_key(nk, part)
        print("%s %s @0x%x" % ("key" if c is not None else "added", part, nk))
    for spec in sys.argv[3:]:
        name, typ, data = encode(spec)
        h.set_value(nk, name, typ, data)
        print("value %s type %d (%d bytes)" % (name, typ, len(data)))
    h.finish()


if __name__ == "__main__":
    main()
