"""Patch BCD elements in place inside a QEMU overlay (never the base disk).

Only same-size edits: a boolean/integer element's bytes, or a GUID inside a
GUID list replaced by another GUID. The BCD file must be stored contiguously
in the FAT partition (checked).

Usage:
  python -I tools/bcdpatch.py <overlay.qcow2> <part_first_lba> <part_sectors> <bcd_original> EDIT [EDIT...]
  EDIT = set:{object}:ELEMENTHEX:HEXBYTES      e.g. set:{01de5a27-...}:2600014d:00
       = guid:{object}:ELEMENTHEX:{old}:{new}  e.g. guid:{9dea862c-...}:24000002:{01de...}:{7619...}
"""
import os
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hive import Hive  # noqa: E402
import qcowpoke  # noqa: E402

QEMU = os.environ.get("W10M_QEMU_DIR", r"C:\Program Files\qemu")


def main():
    overlay, first, count, bcd_path = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
    edits = sys.argv[5:]
    bcd = open(bcd_path, "rb").read()
    h = Hive(bcd_path)
    new = bytearray(bcd)
    for e in edits:
        kind, rest = e.split(":", 1)
        obj, rest = rest[:38], rest[39:]
        elem, rest = rest[:8], rest[9:]
        key = h.find("Objects\\%s\\Elements\\%s" % (obj, elem))
        off, length, typ = h.value_location(key, "Element")
        if kind == "set":
            val = bytes.fromhex(rest)
            if len(val) != length:
                sys.exit("%s: length %d, element holds %d" % (e, len(val), length))
            new[off:off + length] = val
        elif kind == "guid":
            old_g, new_g = rest[:38].encode("utf-16-le"), rest[39:].encode("utf-16-le")
            seg = bytes(new[off:off + length])
            i = seg.lower().find(old_g.lower())
            if i < 0 or len(old_g) != len(new_g):
                sys.exit("%s: old GUID not in element" % e)
            new[off + i:off + i + len(new_g)] = new_g
        else:
            sys.exit("unknown edit " + e)
        print("edit %s -> file offset %#x" % (e, off))

    tmp = tempfile.mkdtemp()
    part = os.path.join(tmp, "part.img")
    opts = "driver=raw,offset=%d,size=%d,file.driver=qcow2,file.file.filename=%s" % (first * 512, count * 512, overlay)
    subprocess.run([QEMU + r"\qemu-img.exe", "convert", "--image-opts", opts, "-O", "raw", part], check=True)
    img = open(part, "rb").read()
    changed = [i for i in range(len(bcd)) if bcd[i] != new[i]]
    # FAT may fragment the file: locate each touched 4 KiB chunk on its own
    where = {}
    for c in sorted({i // 4096 for i in changed}):
        chunk = bcd[c * 4096:(c + 1) * 4096]
        p = img.find(chunk)
        if p < 0 or img.find(chunk, p + 1) >= 0:
            sys.exit("BCD chunk %d not found exactly once in the partition" % c)
        where[c] = p
    loc = {i: where[i // 4096] + i % 4096 for i in changed}
    pos = where[min(where)]
    sectors = sorted({loc[i] // 512 for i in changed})
    for s in sectors:
        buf = bytearray(img[s * 512:(s + 1) * 512])
        for i in changed:
            if loc[i] // 512 == s:
                buf[loc[i] % 512] = new[i]
        disk_off = first * 512 + s * 512
        qcowpoke.poke(overlay, disk_off, img[s * 512:(s + 1) * 512], buf)
        print("wrote sector at disk offset %#x (BCD at partition offset %#x)" % (disk_off, pos))

if __name__ == "__main__":
    main()
