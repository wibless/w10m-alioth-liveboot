"""Minimal read-only parser for Windows registry hives (regf), e.g. BCD, SYSTEM.

Usage:
  python -I tools/hive.py dump <hive> [key\\path]      all keys/values below a key
  python -I tools/hive.py bcd  <BCD>                   BCD objects with decoded element names
"""
import struct
import sys

REG_TYPES = {0: "NONE", 1: "SZ", 2: "EXPAND_SZ", 3: "BINARY", 4: "DWORD", 7: "MULTI_SZ", 11: "QWORD"}


class Hive:
    def __init__(self, path):
        self.d = open(path, "rb").read()
        if self.d[:4] != b"regf":
            raise ValueError("not a regf hive")
        self.root = struct.unpack_from("<I", self.d, 0x24)[0]

    def cell(self, off):
        p = 0x1000 + off
        size = -struct.unpack_from("<i", self.d, p)[0]
        return p + 4, size - 4

    def nk(self, off):
        p, _ = self.cell(off)
        if self.d[p:p + 2] != b"nk":
            raise ValueError("bad nk at %#x" % off)
        flags = struct.unpack_from("<H", self.d, p + 2)[0]
        nsub, subl = struct.unpack_from("<II", self.d, p + 0x14)[0], struct.unpack_from("<I", self.d, p + 0x1c)[0]
        nval, vall = struct.unpack_from("<II", self.d, p + 0x24)
        nlen = struct.unpack_from("<H", self.d, p + 0x48)[0]
        raw = self.d[p + 0x4c:p + 0x4c + nlen]
        name = raw.decode("latin1") if flags & 0x20 else raw.decode("utf-16-le")
        return dict(name=name, nsub=nsub, subl=subl, nval=nval, vall=vall)

    def subkeys(self, key):
        out = []

        def walk(lst):
            p, _ = self.cell(lst)
            sig, n = self.d[p:p + 2], struct.unpack_from("<H", self.d, p + 2)[0]
            step = 4 if sig in (b"li", b"ri") else 8
            for i in range(n):
                o = struct.unpack_from("<I", self.d, p + 4 + i * step)[0]
                if sig == b"ri":
                    walk(o)
                else:
                    out.append(o)
        if key["nsub"]:
            walk(key["subl"])
        return [self.nk(o) for o in out]

    def values(self, key):
        res = []
        if not key["nval"]:
            return res
        p, _ = self.cell(key["vall"])
        for i in range(key["nval"]):
            vo = struct.unpack_from("<I", self.d, p + i * 4)[0]
            q, _ = self.cell(vo)
            nlen, dlen, doff, typ, flags = struct.unpack_from("<HIIIH", self.d, q + 2)
            name = self.d[q + 0x14:q + 0x14 + nlen]
            name = name.decode("latin1") if flags & 1 else name.decode("utf-16-le")
            if dlen & 0x80000000:
                data = struct.pack("<I", doff)[:dlen & 0x7fffffff]
            else:
                dp, dsz = self.cell(doff)
                data = self.d[dp:dp + dlen] if dlen <= dsz else self.big(doff, dlen)
            res.append((name or "(default)", typ, data))
        return res

    def big(self, off, length):
        p, _ = self.cell(off)
        if self.d[p:p + 2] != b"db":
            return b""
        n, lst = struct.unpack_from("<HI", self.d, p + 2)
        lp, _ = self.cell(lst)
        out = b""
        for i in range(n):
            sp, ssz = self.cell(struct.unpack_from("<I", self.d, lp + i * 4)[0])
            out += self.d[sp:sp + min(ssz, 16344)]
        return out[:length]

    def value_location(self, key, value_name):
        """(file offset of the value's data, length, type) for in-place patching."""
        p, _ = self.cell(key["vall"])
        for i in range(key["nval"]):
            vo = struct.unpack_from("<I", self.d, p + i * 4)[0]
            q, _ = self.cell(vo)
            nlen, dlen, doff, typ, flags = struct.unpack_from("<HIIIH", self.d, q + 2)
            name = self.d[q + 0x14:q + 0x14 + nlen]
            name = name.decode("latin1") if flags & 1 else name.decode("utf-16-le")
            if name.lower() != value_name.lower():
                continue
            if dlen & 0x80000000:
                return q + 8, dlen & 0x7fffffff, typ
            dp, dsz = self.cell(doff)
            if dlen > dsz:
                raise ValueError("big data value: not patchable in place")
            return dp, dlen, typ
        raise KeyError(value_name)

    def find(self, path):
        key = self.nk(self.root)
        for part in [x for x in path.split("\\") if x]:
            key = next(k for k in self.subkeys(key) if k["name"].lower() == part.lower())
        return key


def fmt(typ, data):
    if typ in (1, 2):
        return data.decode("utf-16-le", "replace").rstrip("\0")
    if typ == 7:
        return " | ".join(x for x in data.decode("utf-16-le", "replace").split("\0") if x)
    if typ == 4 and len(data) >= 4:
        return "%#x" % struct.unpack_from("<I", data)[0]
    if typ == 11 and len(data) >= 8:
        return "%#x" % struct.unpack_from("<Q", data)[0]
    return data.hex()


def dump(h, key, path, depth=0):
    print("  " * depth + "[" + path + "]")
    for name, typ, data in h.values(key):
        print("  " * depth + "  %s (%s) = %s" % (name, REG_TYPES.get(typ, typ), fmt(typ, data)[:400]))
    for sk in h.subkeys(key):
        dump(h, sk, path + "\\" + sk["name"], depth + 1)


# BCD element ids (BcdLibraryElementTypes / BcdBootMgr / BcdOSLoader / BcdApplication) seen on phones
BCD_NAMES = {
    0x11000001: "device", 0x12000002: "path", 0x12000004: "description", 0x12000005: "locale",
    0x14000006: "inherit", 0x15000007: "truncatememory", 0x14000008: "recoverysequence",
    0x16000009: "recoveryenabled", 0x16000010: "debug", 0x16000020: "bootems",
    0x16000040: "advancedoptions", 0x16000041: "optionsedit", 0x15000042: "keyringaddress",
    0x16000046: "graphicsmodedisabled", 0x16000048: "nointegritychecks", 0x16000049: "testsigning",
    0x1600004e: "bootuxdisabled", 0x16000060: "isolatedcontext", 0x16000069: "bootstatuspolicy",
    0x15000065: "displaymessage", 0x16000067: "nodefaulttimeout?",
    0x24000001: "displayorder", 0x24000002: "bootsequence", 0x23000003: "default",
    0x25000004: "timeout", 0x26000005: "resume", 0x23000006: "resumeobject", 0x24000010: "toolsdisplayorder",
    0x26000020: "displaybootmenu", 0x26000022: "noerrordisplay", 0x26000024: "processcustomactionsfirst",
    0x21000001: "osdevice", 0x22000002: "systemroot", 0x23000003: "associatedresumeobject",
    0x26000010: "detecthal", 0x22000011: "kernel", 0x22000012: "hal", 0x26000025: "bootlog?",
    0x26000090: "bootdebug?", 0x250000c2: "bootmenupolicy", 0x26000081: "sos?", 0x26000040: "vga?",
    0x25000020: "nx", 0x25000021: "pae", 0x26000022: "winpe", 0x26000024: "nocrashautoreboot",
}


def bcd(h):
    objs = h.find("Objects")
    for o in h.subkeys(objs):
        desc = h.find("Objects\\" + o["name"] + "\\Description")
        typ = dict((n, d) for n, t, d in h.values(desc)).get("Type", b"\0\0\0\0")
        print("\n%s  type=%#010x" % (o["name"], struct.unpack_from("<I", typ)[0]))
        try:
            els = h.find("Objects\\" + o["name"] + "\\Elements")
        except StopIteration:
            continue
        for e in h.subkeys(els):
            eid = int(e["name"], 16)
            for n, t, d in h.values(e):
                if n == "Element":
                    print("  %s %-22s %s" % (e["name"], BCD_NAMES.get(eid, "?"), fmt(t, d)[:300]))


def main():
    cmd, path = sys.argv[1], sys.argv[2]
    h = Hive(path)
    if cmd == "dump":
        sub = sys.argv[3] if len(sys.argv) > 3 else ""
        dump(h, h.find(sub) if sub else h.nk(h.root), sub or "ROOT")
    elif cmd == "bcd":
        bcd(h)


if __name__ == "__main__":
    main()
