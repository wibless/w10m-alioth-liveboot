"""Write changed bytes into a qcow2 overlay with qemu-io, and verify by reading back.

qemu-io's `write -s <file>` reads the pattern file in text mode on Windows (stops at 0x1A), so it is
not used: each run of equal changed bytes becomes one `write -P <byte> <offset> <len>`.
"""
import os
import subprocess

QEMU_IO = os.path.join(os.environ.get("W10M_QEMU_DIR", r"C:\Program Files\qemu"), "qemu-io.exe")


def read(overlay, off, n):
    out = subprocess.run([QEMU_IO, "-f", "qcow2", "-r", "-c", "read -v %d %d" % (off, n), overlay],
                         check=True, capture_output=True, text=True).stdout
    rows = [l for l in out.splitlines()
            if ":" in l and l.split(":")[0].strip() and all(c in "0123456789abcdef" for c in l.split(":")[0].strip())]
    return bytes.fromhex("".join("".join(l.split(":", 1)[1].split()[:16]) for l in rows))[:n]


def poke(overlay, disk_off, old, new):
    """Make bytes [disk_off, disk_off+len(new)) equal `new`, writing only where they differ from `old`."""
    cmds, i = [], 0
    while i < len(new):
        if old[i] == new[i]:
            i += 1
            continue
        j = i
        while j < len(new) and old[j] != new[j] and new[j] == new[i]:
            j += 1
        cmds += ["-c", "write -P 0x%02x %d %d" % (new[i], disk_off + i, j - i)]
        i = j
    for k in range(0, len(cmds), 400):            # stay well below the Windows command line limit
        subprocess.run([QEMU_IO, "-f", "qcow2"] + cmds[k:k + 400] + [overlay], check=True, capture_output=True)
    got = read(overlay, disk_off, len(new))
    if got != bytes(new):
        raise SystemExit("read-back mismatch at disk offset %#x" % disk_off)
    return len(cmds) // 2
