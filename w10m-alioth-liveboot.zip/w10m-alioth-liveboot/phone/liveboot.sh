#!/system/bin/sh
# W10M LiveBoot, the phone side: runs under TWRP (booted with `fastboot boot`, RAM only) from /tmp/w10m.
# Everything lives in tmpfs: nothing on the phone's storage is touched; a reboot leaves no trace.
# QEMU (aarch64 build of the simulator's patched QEMU) runs W10M; w10m-phone shows it on the panel and
# feeds the touch screen and the keys into it.
D=/tmp/w10m
R=/tmp/w10m-ram                   # the guest's RAM as a file: w10m-phone reads the framebuffer from it
cd $D || exit 1
exec >>$D/run.log 2>&1
echo "== $(date) liveboot.sh"
cat /proc/meminfo | head -3
SMP=${SMP:-4}
MEM=${MEM:-2048}
mkdir -p $R
mountpoint -q $R || mount -t tmpfs -o size=$((MEM + 16))m tmpfs $R

# QEMU with the bundled glibc (TWRP has bionic only)
export W10M_ID_PFR1=10011         # the ID_PFR1 value the W10M kernel wants (src/qemu/arm-id-pfr1-override.patch)
export TMPDIR=$D                  # snapshot=on overlays: in this tmpfs
# NATIVE=1: the guest's user mode runs natively on the phone's cores (docs/NATIVE_EL0.md)
if [ "$NATIVE" = 1 ]; then
    export NATRUN=1 NATRUN_HELPER=$D/helper32 NATRUN_RAM=$R/ram NATRUN_STATS=1
    export NATRUN_WINDOW=${WINDOW:-1}   # 1: no pages mapped ahead (faster and stable so far)
    [ -n "$ONE" ] && export NATRUN_ONE=1
    # the guest's timer counts with the phone's counter (19.2 MHz): ntdll reads it natively (QueryPerformanceCounter)
    export NATRUN_COUNTER=1
    CPUOPT=",cntfrq=19200000"
    ACTION="-action reboot=shutdown,shutdown=pause"   # a crash stays in RAM for the analysis
fi
# BasicDisplay's frames copied by QEMU and signalled to w10m-phone (natrun.c, NATRUN_PRESENT). The shim always
# puts the 720x1280 framebuffer at 0xbc419000 (checked below against the serial log)
FIFO=$R/frame.fifo
rm -f $FIFO; mkfifo $FIFO
[ "$PRESENT" = 0 ] || export NATRUN_PRESENT=bc419000:720x1280:$FIFO   # PRESENT=0: the driver copies (diagnosis)
# NET_PORT: the network cable goes over USB to the PC (adb reverse tcp:NET_PORT; liveboot.ps1 runs the NAT there)
NETDEV="user,id=n0"
NETCARD="-device usb-ax88772,bus=inxhci.0,netdev=n0"
if [ -n "$NET_PORT" ]; then
    NETDEV="stream,id=n0,server=off,addr.type=inet,addr.host=127.0.0.1,addr.port=$NET_PORT,reconnect-ms=2000"
    # with the internet there during the boot the shell hangs on "Loading...": w10m-phone plugs the card in
    # once Windows has drawn its UI
    NETCARD=""
    export W10M_NET_LATE=1
fi
rm -f qmp.sock serial.txt
./lib/ld-linux-aarch64.so.1 --library-path ./lib ./qemu-system-arm \
    -M virt,highmem=off,gic-version=2,memory-backend=ram0 -cpu cortex-a15$CPUOPT -smp $SMP -m $MEM \
    -object memory-backend-file,id=ram0,size=${MEM}M,mem-path=$R/ram,share=on \
    -drive if=pflash,format=raw,readonly=on,file=edk2-arm-code.fd \
    -drive if=pflash,format=raw,file=vars.fd \
    -device ramfb -device qemu-xhci,id=xhci,bus=pcie.0,addr=0x2 -device usb-kbd,bus=xhci.0 \
    $ACTION -serial file:$D/serial.txt -qmp unix:$D/qmp.sock,server=on,wait=off -display none \
    -drive if=none,id=d0,format=qcow2,file=${DISK:-w10m.qcow2},snapshot=on,file.locking=off \
    -device usb-storage,bus=xhci.0,drive=d0,removable=on,bootindex=1 \
    -device ufs,id=ufs0,serial=w10m,bus=pcie.0,addr=0x3 \
    -drive if=none,id=ufsd,format=qcow2,file=${DISK:-w10m.qcow2},snapshot=on,file.locking=off \
    -device ufs-lu,drive=ufsd,lun=0,block-size=512 \
    -device qemu-xhci,id=inxhci,bus=pcie.0,addr=0x8 -device usb-touchscreen,bus=inxhci.0 \
    -device usb-phone-buttons,bus=inxhci.0,id=btn \
    -netdev $NETDEV $NETCARD \
    -drive if=none,id=shim,format=raw,file=fat:16:$D/shimfs,readonly=on \
    -device usb-storage,bus=xhci.0,drive=shim,bootindex=0 \
    >$D/qemu.log 2>&1 &
QPID=$!
echo "qemu pid $QPID"
echo $QPID > qemu.pid

# the emulated CPUs on the big cores (4-6 Cortex-A77, 7 the fastest), the rest of QEMU on the little ones
sleep 3
for t in /proc/$QPID/task/*; do
    case "$(cat $t/comm)" in
        "CPU "*) n=$(cat $t/comm | sed 's/CPU \([0-9]*\).*/\1/'); taskset -p $(printf %x $((0x80 >> (n % 4)))) ${t##*/} ;;
        *) taskset -p 0f ${t##*/} ;;
    esac
done >/dev/null
echo "QEMU threads pinned"

# the framebuffer address the shim programmed into ramfb
FB=""
for i in $(seq 1 120); do
    FB=$(sed -n 's/.*GOP: portrait 0x0*\([0-9a-f]*\)x0x0*\([0-9a-f]*\) framebuffer 0x0*\([0-9a-f]*\).*/\1 \2 \3/p' serial.txt | tail -1)
    [ -n "$FB" ] && break
    sleep 1
done
set -- $FB
if [ -n "$FB" ]; then
    FBARGS="$R/ram $3 $((0x$1))x$((0x$2))"
    echo "framebuffer: $FBARGS"
    if [ -n "$NATRUN_PRESENT" ] && [ "$3" = bc419000 ] && [ "$((0x$1))x$((0x$2))" = 720x1280 ]; then
        FBARGS="$FBARGS $FIFO"
    else
        echo "the framebuffer is not where NATRUN_PRESENT copies to: frames polled"
    fi
else
    echo "no framebuffer line in serial.txt: frames through QMP screendump"
    FBARGS=""
fi

# the panel: TWRP draws on it and holds DRM; stop TWRP's UI (adbd stays)
stop recovery 2>/dev/null || setprop ctl.stop recovery
sleep 2
# its own session: the adb shell that started us must not take it down when it ends
setsid ./w10m-phone $D/qmp.sock $D $FBARGS >>$D/phone.log 2>&1 &
sleep 1
PPID_=$(pidof w10m-phone)
echo $PPID_ > phone.pid
wait $QPID
echo "== $(date) QEMU exited ($?)"
kill $PPID_ 2>/dev/null
