@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\build-disk.ps1" %*
pause
