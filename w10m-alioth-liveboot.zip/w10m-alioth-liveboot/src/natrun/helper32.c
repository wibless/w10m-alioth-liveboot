/*
 * helper32: the 32-bit ARM process whose user mode runs W10M's user code natively (AArch32 EL0 on the
 * Snapdragon 865). Freestanding, linked above 0x80000000 so the guest's user half (0..0x7FFFFFFF) is free.
 * It only installs a seccomp filter and stops: every system call made from below 0x80000000 (a guest SVC)
 * becomes SIGSYS, which the tracer (QEMU side) turns into a guest SVC exception; its own calls (the tracer
 * injects mmap/munmap through the gadget) go through.
 * Build: arm-linux-gnueabihf-gcc -marm -O2 -static -nostdlib -ffreestanding -Wl,-Ttext-segment=0xA0000000
 */
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <stddef.h>

#define SYS_prctl 172
#define SYS_seccomp 383
#define SYS_exit 1
#define PR_SET_NO_NEW_PRIVS 38

static long sys3(long n, long a, long b, long c)
{
    /* r3, r4 zero: prctl(PR_SET_NO_NEW_PRIVS) wants its unused arguments to be 0 */
    register long r0 asm("r0") = a, r1 asm("r1") = b, r2 asm("r2") = c, r3 asm("r3") = 0, r4 asm("r4") = 0,
                  r7 asm("r7") = n;
    asm volatile("svc #0" : "+r"(r0) : "r"(r1), "r"(r2), "r"(r3), "r"(r4), "r"(r7) : "memory");
    return r0;
}

static long sys6(long n, long a, long b, long c, long d, long e, long f)
{
    register long r0 asm("r0") = a, r1 asm("r1") = b, r2 asm("r2") = c, r3 asm("r3") = d, r4 asm("r4") = e,
                  r5 asm("r5") = f, r7 asm("r7") = n;
    asm volatile("svc #0" : "+r"(r0) : "r"(r1), "r"(r2), "r"(r3), "r"(r4), "r"(r5), "r"(r7) : "memory");
    return r0;
}

/*
 * A batch of mappings in one stop (the tracer fills the control page, shared with it through fd 4):
 * op 0 mmap2(va, len, prot, MAP_SHARED | MAP_FIXED, fd 3, pgoff), op 1 munmap(va, len).
 */
struct req { unsigned va, len, prot, pgoff, op; };
struct ctl { unsigned n, failed, first_bad, pad; struct req r[]; };

void batch(struct ctl *c)
{
    c->failed = 0;
    for (unsigned i = 0; i < c->n; i++) {
        struct req *q = &c->r[i];
        long r = q->op ? sys6(91, q->va, q->len, 0, 0, 0, 0) : sys6(192, q->va, q->len, q->prot, 0x11, 3, q->pgoff);
        if (q->op ? r != 0 : r != (long)q->va) {
            if (!c->failed++)
                c->first_bad = i;
        }
    }
}

/* the tracer runs injected system calls from here: svc, then a stop */
/* gadget + 12: TPIDRURW := r0 (only user code can write the helper's, the tracer cannot) */
/* gadget + 24: batch(r0), sp set by the tracer */
asm(".arm\n.global gadget\ngadget:\n svc #0\n.inst 0xe7f000f0\n b gadget\n"
    " mcr p15, 0, r0, c13, c0, 2\n.inst 0xe7f000f0\n b gadget\n"
    " bl batch\n.inst 0xe7f000f0\n b gadget\n");
extern void gadget(void);

void _start(void)
{
    struct sock_filter f[] = {
        /* seccomp_data.instruction_pointer (low word) */
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, instruction_pointer)),
        BPF_JUMP(BPF_JMP | BPF_JGE | BPF_K, 0x80000000u, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_TRAP),
    };
    struct sock_fprog prog = { sizeof f / sizeof f[0], f };
    long e = sys3(SYS_prctl, PR_SET_NO_NEW_PRIVS, 1, 0);
    if (e)
        sys3(SYS_exit, 100 - e, 0, 0);          /* exit status 100 + errno: prctl failed */
    e = sys3(SYS_seccomp, SECCOMP_SET_MODE_FILTER, 0, (long)&prog);
    if (e)
        sys3(SYS_exit, 200 - e, 0, 0);          /* 200 + errno: seccomp failed */
    /* stop at the gadget's breakpoint: the tracer takes over */
    asm volatile("b gadget + 4");
    for (;;)
        ;
}
