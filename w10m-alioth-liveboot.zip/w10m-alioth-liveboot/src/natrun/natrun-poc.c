/*
 * natrun-poc: can the phone run 32-bit guest user code natively, under the control of an emulator?
 * The guest's RAM is a shared file; pages of it are mapped into helper32 (an AArch32 Linux process) at
 * the guest's virtual addresses, the guest's registers are loaded with ptrace and the code runs on the
 * real CPU until it makes a system call (SIGSYS from helper32's seccomp filter), faults (SIGSEGV) or is
 * interrupted. Measured here: the cost of one native <-> emulator round trip, native speed, faults, TLS.
 * Build: aarch64-linux-gnu-gcc -O2 -static -o natrun-poc natrun-poc.c; run as root next to helper32.
 */
#define _GNU_SOURCE
#include <elf.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef NT_ARM_TLS
#define NT_ARM_TLS 0x401
#endif
#define RAM_SIZE (16 << 20)
#define GVA 0x10000u                     /* guest code / data at this guest virtual address */

struct regs32 { uint32_t r[18]; };        /* r0..r15, cpsr, orig_r0 (compat_user_regs) */
static pid_t pid;
static uint32_t gadget;

static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

static void getregs(struct regs32 *r)
{
    struct iovec io = { r, sizeof *r };
    if (ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &io))
        perror("GETREGSET"), exit(1);
}

static void setregs(struct regs32 *r)
{
    struct iovec io = { r, sizeof *r };
    if (ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &io))
        perror("SETREGSET"), exit(1);
}

/* continue until the next stop; returns the signal, fills si */
static int run(siginfo_t *si)
{
    int st;
    if (ptrace(PTRACE_CONT, pid, 0, 0)) {
        fprintf(stderr, "CONT pid %d: %s\n", pid, strerror(errno));
        exit(1);
    }
    if (waitpid(pid, &st, 0) < 0 || !WIFSTOPPED(st)) {
        fprintf(stderr, "helper32 ended (status %#x)\n", st);
        exit(1);
    }
    if (si)
        ptrace(PTRACE_GETSIGINFO, pid, 0, si);
    return WSTOPSIG(st);
}

/* a system call made by helper32 itself (through the gadget) */
static uint32_t inject(uint32_t nr, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3, uint32_t a4, uint32_t a5)
{
    struct regs32 save, r;
    getregs(&save);
    r = save;
    r.r[0] = a0, r.r[1] = a1, r.r[2] = a2, r.r[3] = a3, r.r[4] = a4, r.r[5] = a5, r.r[7] = nr;
    r.r[15] = gadget;
    r.r[16] = 0x10;                       /* USR, ARM state */
    setregs(&r);
    int sig = run(NULL);
    getregs(&r);
    if (sig != SIGILL && sig != SIGTRAP)
        fprintf(stderr, "inject: stop with signal %d at %#x\n", sig, r.r[15]);
    setregs(&save);
    return r.r[0];
}

/* put the guest at pc (Thumb) with r0 and run it until it stops */
static int guest(uint32_t pc, uint32_t r0, struct regs32 *out, siginfo_t *si)
{
    struct regs32 r;
    getregs(&r);
    r.r[0] = r0;
    r.r[12] = 0xc0de0000 | r0;
    r.r[3] = 0x3333;
    r.r[14] = 0xeeee;
    r.r[15] = pc;
    r.r[16] = 0x10 | 0x20;                /* USR, Thumb */
    setregs(&r);
    int sig = run(si);
    getregs(out);
    return sig;
}

int main(int argc, char **argv)
{
    const char *helper = argc > 1 ? argv[1] : "./helper32";
    int fd = memfd_create("guest-ram", 0);
    if (fd < 0 || ftruncate(fd, RAM_SIZE))
        perror("guest RAM"), exit(1);
    uint16_t *ram = mmap(0, RAM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);

    /* guest code (Thumb) at GVA: the first page of the RAM file */
    uint16_t code[] = {
        /* +0x00 round trip */   0xdf01, 0xe7fd,                       /* svc #1; b . -2 */
        0, 0, 0, 0, 0, 0,
        /* +0x10 compute */      0x3801, 0xd1fd, 0xdf02, 0xe7fe,       /* 1: subs r0,#1; bne 1b; svc #2 */
        0, 0, 0, 0,
        /* +0x20 fault */        0x6801, 0xdf03, 0xe7fe, 0,            /* ldr r1,[r0]; svc #3 */
        0, 0, 0, 0,
        /* +0x30 TLS */          0xee1d, 0x0f70, 0xee1d, 0x1f50, 0xdf04, 0xe7fe, /* mrc p15,0,r0,c13,c0,3; mrc ..,r1,c13,c0,2; svc #4 */
    };
    memcpy(ram, code, sizeof code);

    pid = fork();
    if (!pid) {
        dup2(fd, 3);
        ptrace(PTRACE_TRACEME, 0, 0, 0);
        execl(helper, "helper32", (char *)0);
        _exit(127);
    }
    int st;
    waitpid(pid, &st, 0);                 /* the exec stop */
    if (!WIFSTOPPED(st)) {
        fprintf(stderr, "no exec stop: status %#x\n", st);
        return 1;
    }
    ptrace(PTRACE_SETOPTIONS, pid, 0, PTRACE_O_EXITKILL);
    struct regs32 r;
    siginfo_t si;
    int sig = run(NULL);                  /* helper32 installs its filter and stops in the gadget */
    getregs(&r);
    gadget = r.r[15] - 4;
    printf("helper32 stopped (signal %d) at %#x, cpsr %#x: gadget %#x\n", sig, r.r[15], r.r[16], gadget);

    /* map the guest page(s): mmap2(GVA, 1 MB, rwx, MAP_SHARED|MAP_FIXED, fd 3, 0) */
    uint32_t m = inject(192, GVA, 1 << 20, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_SHARED | MAP_FIXED, 3, 0);
    printf("mmap2 in helper32 -> %#x\n", m);
    if (m != GVA)
        return 1;

    /* 1. round trip: native -> SIGSYS -> back */
    int n = 20000;
    double t = now();
    for (int i = 0; i < n; i++) {
        sig = guest(GVA, i, &r, &si);
        if (i < 2 || r.r[0] != (uint32_t)i || r.r[12] != (0xc0de0000 | i) || r.r[3] != 0x3333 || r.r[14] != 0xeeee)
            printf("svc %d: r0 %#x (was %#x), r1 %#x r12 %#x pc %#x\n", i, r.r[0], i, r.r[1], r.r[12], r.r[15]);
        if (i > 4 && r.r[0] != (uint32_t)i)
            return 1;
        if (sig != SIGSYS) {
            printf("round trip: signal %d at %#x\n", sig, r.r[15]);
            return 1;
        }
    }
    t = now() - t;
    printf("round trip (guest svc -> emulator -> guest): %.1f us each (%d), last stop pc %#x, svc syscall %d, r7 %#x\n",
           t / n * 1e6, n, r.r[15], si.si_syscall, r.r[7]);

    /* 2. native speed: 200M iterations of subs/bne */
    t = now();
    sig = guest(GVA + 0x10 + 1, 200000000, &r, &si);
    t = now() - t;
    printf("compute: signal %d, r0 %u, 200M loop iterations in %.3f s (%.0f M/s)\n", sig, r.r[0], t, 200 / t);

    /* 3. a fault on an address the guest has not got mapped here */
    sig = guest(GVA + 0x20 + 1, 0x5000000, &r, &si);
    printf("fault: signal %d (SIGSEGV %d), si_addr %p, si_code %d, pc %#x\n", sig, SIGSEGV, si.si_addr, si.si_code, r.r[15]);

    /* 4. TLS registers: TPIDRURO (the TEB on Windows) set by the emulator */
    uint64_t tls = 0x7ffdf000;
    struct iovec io = { &tls, sizeof tls };
    printf("NT_ARM_TLS set: %s\n", ptrace(PTRACE_SETREGSET, pid, NT_ARM_TLS, &io) ? strerror(errno) : "ok");
    sig = guest(GVA + 0x30 + 1, 0, &r, &si);
    printf("TLS: signal %d, TPIDRURO %#x, TPIDRURW %#x\n", sig, r.r[0], r.r[1]);

    /* 5. which core: helper32 can run on the big cores too */
    kill(pid, SIGKILL);
    return 0;
}
