#!/usr/bin/env bash
# Builds qemu-system-arm 11.1.0 with the project patches for an aarch64 Linux host (the phone, under the
# TWRP kernel). Cross-built in WSL Ubuntu (26.04) and linked dynamically against glibc; the binary is run
# through the bundled loader:  ./lib/ld-linux-aarch64.so.1 --library-path ./lib ./qemu-system-arm ...
# Run:  wsl -e bash /mnt/c/win10mobile/src/qemu/build-qemu-aarch64.sh
# Needs (apt, with arm64 multiarch from ports.ubuntu.com): gcc-aarch64-linux-gnu meson ninja-build pkg-config
#   python3-venv flex bison libglib2.0-dev:arm64 libpixman-1-dev:arm64 zlib1g-dev:arm64 libslirp-dev:arm64
#   libfdt-dev:arm64 libpcre2-dev:arm64 libffi-dev:arm64
# Output: work/qemu-a64/ (qemu-system-arm, lib/, share/qemu/, w10m-phone, helper32)
set -e
ROOT=/mnt/c/win10mobile
W=$HOME/qemu-a64
OUT=$ROOT/work/qemu-a64
mkdir -p "$W" && cd "$W"
if [ ! -d qemu-v11.1.0 ]; then
    tar xzf "$ROOT/work/qemu-build/qemu-v11.1.0.tar.gz"
    for p in ufs-lu-block-size ufs-windows-descriptors usb-ax88772 usb-touchscreen arm-id-pfr1-override natrun; do
        patch -d qemu-v11.1.0 -p1 < "$ROOT/src/qemu/$p.patch"
    done
fi
mkdir -p build && cd build
export PKG_CONFIG_LIBDIR=/usr/lib/aarch64-linux-gnu/pkgconfig:/usr/share/pkgconfig
[ -f build.ninja ] || ../qemu-v11.1.0/configure --cross-prefix=aarch64-linux-gnu- --target-list=arm-softmmu \
    --disable-docs --disable-werror --disable-rust --enable-slirp --enable-vnc --enable-fdt=system \
    --disable-sdl --disable-gtk --disable-opengl --disable-tools --disable-guest-agent \
    --prefix=/ > configure.log 2>&1 || { tail -30 configure.log; exit 1; }
ninja > make.log 2>&1 || { grep -m20 -i -B2 -A5 'error' make.log; exit 1; }
rm -rf "$OUT" && mkdir -p "$OUT/lib" "$OUT/share"
aarch64-linux-gnu-strip -o "$OUT/qemu-system-arm" qemu-system-arm
cp -r ../qemu-v11.1.0/pc-bios/keymaps "$OUT/share/" 2>/dev/null || true
cp pc-bios/edk2-arm-code.fd "$OUT/share/" 2>/dev/null || true
# the shared libraries it links against, and the glibc loader
L=/usr/lib/aarch64-linux-gnu
need() { aarch64-linux-gnu-readelf -d "$1" | sed -n 's/.*NEEDED.*\[\(.*\)\]/\1/p'; }
todo=$(need qemu-system-arm); done_=" "
while [ -n "$todo" ]; do
    set -- $todo; todo=""
    for n in "$@"; do
        case "$done_" in *" $n "*) continue;; esac
        done_="$done_$n "
        cp -L "$L/$n" "$OUT/lib/"
        todo="$todo $(need "$L/$n")"
    done
done
cp -L $L/ld-linux-aarch64.so.1 "$OUT/lib/"
ls -la "$OUT" "$OUT/lib"
# the phone agent and the native user-mode helper (docs/NATIVE_EL0.md)
aarch64-linux-gnu-gcc -O2 -Wall -static -s -o "$OUT/w10m-phone" "$ROOT/src/liveboot/w10m-phone.c"
arm-linux-gnueabihf-gcc -marm -O2 -static -nostdlib -ffreestanding -fno-stack-protector \
    -Wl,-Ttext-segment=0xA0000000 -Wl,--build-id=none -o "$OUT/helper32" "$ROOT/src/natrun/helper32.c"
