#!/usr/bin/env bash
# Builds qemu-system-arm 11.1.0 with the ufs-lu block-size patch (src/qemu/ufs-lu-block-size.patch) and
# Windows-friendly UFS descriptor defaults (src/qemu/ufs-windows-descriptors.patch: replaces tools/desc-patch.ps1)
# and an ASIX AX88772 USB Ethernet device, usb-ax88772 (src/qemu/usb-ax88772.patch; W10M has its driver).
# Run in an MSYS2 UCRT64 shell:  MSYSTEM=UCRT64 /c/msys64/usr/bin/bash.exe -lc 'bash /c/win10mobile/src/qemu/build-qemu.sh'
# Needs (pacman): make tar git diffutils patch mingw-w64-ucrt-x86_64-{gcc,pkgconf,glib2,pixman,zlib,dtc,meson,ninja,python,libslirp,SDL2}
# Source: https://gitlab.com/qemu-project/qemu/-/archive/v11.1.0/qemu-v11.1.0.tar.gz
#   sha256 a13a38a1b9f5a76d6f84a90345bc33c4788a53878230df53599e65a965b8cb86 (put it in work/qemu-build/)
# Output: work/qemu-build/install/qemu-system-arm.exe with the UCRT64 DLLs it needs next to it.
set -e
ROOT=/c/win10mobile
W=$ROOT/work/qemu-build
cd "$W"
if [ ! -d qemu-v11.1.0 ]; then
    tar xzf qemu-v11.1.0.tar.gz
    patch -d qemu-v11.1.0 -p1 < "$ROOT/src/qemu/ufs-lu-block-size.patch"
    patch -d qemu-v11.1.0 -p1 < "$ROOT/src/qemu/ufs-windows-descriptors.patch"
    patch -d qemu-v11.1.0 -p1 < "$ROOT/src/qemu/usb-ax88772.patch"
    patch -d qemu-v11.1.0 -p1 < "$ROOT/src/qemu/usb-touchscreen.patch"
    patch -d qemu-v11.1.0 -p1 < "$ROOT/src/qemu/arm-id-pfr1-override.patch"
fi
mkdir -p build && cd build
[ -f build.ninja ] || ../qemu-v11.1.0/configure --target-list=arm-softmmu --disable-docs --disable-werror \
    --disable-rust --enable-slirp --enable-sdl --prefix="$W/install" > configure.log 2>&1 || { tail -30 configure.log; exit 1; }
make -j"$(nproc)" > make.log 2>&1 || { grep -m20 -i -B2 -A5 'error' make.log; exit 1; }
make install > install.log 2>&1 || { tail -20 install.log; exit 1; }
# self-contained: copy the UCRT64 DLLs the binary links against
ldd "$W/install/qemu-system-arm.exe" | awk '/ucrt64/ {print $3}' | sort -u | xargs -r cp -u -t "$W/install/"
"$W/install/qemu-system-arm.exe" --version | head -1
"$W/install/qemu-system-arm.exe" -device ufs-lu,help
