#!/usr/bin/env bash
# Regenerates src/qemu/natrun.patch from the working tree work/qemu-build/qemu-v11.1.0 (the files patched by
# natrun keep their pristine copy as <file>.natrun-orig; natrun.c / natrun.h are new). LF line endings.
set -e
T=/mnt/c/win10mobile/work/qemu-build/qemu-v11.1.0
OUT=/mnt/c/win10mobile/src/qemu/natrun.patch
tmp=$(mktemp -d)
: > "$OUT.new"
for f in target/arm/tcg/tlb-insns.c accel/tcg/cpu-exec.c system/cpus.c include/hw/core/cpu.h target/arm/cpu.c \
         target/arm/helper.c target/arm/tcg/helper-defs.h target/arm/tcg/translate.c target/arm/tcg/meson.build \
         accel/tcg/cputlb.c cpu-common.c include/exec/cputlb.h target/arm/ptw.c; do
    tr -d '\r' < "$T/$f.natrun-orig" > "$tmp/a"
    tr -d '\r' < "$T/$f" > "$tmp/b"
    diff -u --label "a/$f" --label "b/$f" "$tmp/a" "$tmp/b" >> "$OUT.new" || true
done
for f in target/arm/tcg/natrun.c target/arm/tcg/natrun.h; do
    tr -d '\r' < "$T/$f" > "$tmp/b"
    diff -u --label /dev/null --label "b/$f" /dev/null "$tmp/b" >> "$OUT.new" || true
done
mv "$OUT.new" "$OUT"
rm -rf "$tmp"
grep -c '^+++ ' "$OUT"
