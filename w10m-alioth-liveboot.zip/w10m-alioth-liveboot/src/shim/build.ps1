<#
.SYNOPSIS
  Builds w10mshim.efi (ARM32 UEFI application) into work\shimfs\EFI\BOOT\BOOTARM.EFI,
  the folder QEMU exposes as a small FAT disk (vvfat) in run-qemu.ps1 -Shim.
#>
#requires -Version 5.1
param(
    [int]$FbWidth = 1080,      # portrait framebuffer the shim programs into ramfb (1080x2400 = Poco F3,
    [int]$FbHeight = 2400      # 1440x2560 = HP Elite x3)
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Split-Path -Parent (Split-Path -Parent $Here)
$Llvm = "C:\Program Files\LLVM\bin"
$Out = Join-Path $Here "out"
New-Item -ItemType Directory -Force $Out | Out-Null
$obj = Join-Path $Out "w10mshim.obj"
$efi = Join-Path $Out "w10mshim.efi"

& "$Llvm\clang.exe" --target=armv7-pc-windows-msvc -O2 -ffreestanding -fno-builtin -mno-stack-arg-probe -mfpu=none -fno-vectorize -fno-slp-vectorize `
    -fno-stack-protector -Wall -Werror "-DW10M_FB_W=$FbWidth" "-DW10M_FB_H=$FbHeight" -c (Join-Path $Here "w10mshim.c") -o $obj
if ($LASTEXITCODE -ne 0) { throw "clang failed" }
& "$Llvm\lld-link.exe" /nologo /subsystem:efi_application /entry:efi_main /nodefaultlib /machine:arm `
    /dynamicbase /out:$efi $obj
if ($LASTEXITCODE -ne 0) { throw "lld-link failed" }

# edk2 for 32-bit ARM loads IMAGE_FILE_MACHINE_ARMTHUMB_MIXED (0x1c2) images, as bootarm.efi is
$b = [IO.File]::ReadAllBytes($efi)
$pe = [BitConverter]::ToInt32($b, 0x3c)
$b[$pe + 4] = 0xc2; $b[$pe + 5] = 0x01
[IO.File]::WriteAllBytes($efi, $b)

$dst = Join-Path $Root "work\shimfs\EFI\BOOT"
New-Item -ItemType Directory -Force $dst | Out-Null
Copy-Item $efi (Join-Path $dst "BOOTARM.EFI") -Force
python -I (Join-Path $Root "tools\pe.py") $efi
