/*
 * w10mshim.efi - ARM32 UEFI application that makes a QEMU/edk2 platform look
 * like the phone firmware W10M expects, then chain-loads the original
 * \EFI\BOOT\bootarm.efi from the W10M EFIESP.
 *
 * 1. System memory gets UC/WC/WT/WB capabilities (gDS->SetMemorySpaceCapabilities):
 *    W10M winload allocates "uncached" pages and fails with STATUS_NO_MEMORY on a
 *    WriteBack-only memory map (see W10M_ALIOTH_RESEARCH.md, QEMU section).
 * 2. Finds the partition holding \EFI\Microsoft\boot\BCD and
 *    \Windows\System32\boot\mobilestartup.efi and starts bootarm.efi from it.
 *
 * No Windows file is modified. Built with clang/lld-link, no EDK2 headers.
 */
#include <stdint.h>

typedef uint8_t  UINT8;
typedef uint16_t UINT16;
typedef uint16_t CHAR16;
typedef uint32_t UINT32;
typedef uint64_t UINT64;
typedef uintptr_t UINTN;
typedef UINTN EFI_STATUS;
typedef void *EFI_HANDLE;
typedef UINT8 BOOLEAN;

#define EFI_ERROR(s) ((intptr_t)(s) < 0)
#define EFI_BUFFER_TOO_SMALL ((EFI_STATUS)0x80000005)

typedef struct { UINT32 d1; UINT16 d2, d3; UINT8 d4[8]; } EFI_GUID;
typedef struct { UINT64 Signature; UINT32 Revision, HeaderSize, CRC32, Reserved; } EFI_TABLE_HEADER;

typedef struct SIMPLE_TEXT_OUT {
    void *Reset;
    EFI_STATUS (*OutputString)(struct SIMPLE_TEXT_OUT *, const CHAR16 *);
} SIMPLE_TEXT_OUT;

typedef struct {
    UINT32 Type;
    UINT32 Pad;
    UINT64 PhysicalStart, VirtualStart, NumberOfPages, Attribute;
} EFI_MEMORY_DESCRIPTOR;

typedef struct { UINT8 Type, SubType, Length[2]; } EFI_DEVICE_PATH;

typedef struct {
    EFI_TABLE_HEADER Hdr;
    void *RaiseTPL, *RestoreTPL, *AllocatePages, *FreePages;
    EFI_STATUS (*GetMemoryMap)(UINTN *, EFI_MEMORY_DESCRIPTOR *, UINTN *, UINTN *, UINT32 *);
    EFI_STATUS (*AllocatePool)(UINT32, UINTN, void **);
    EFI_STATUS (*FreePool)(void *);
    void *CreateEvent, *SetTimer, *WaitForEvent, *SignalEvent, *CloseEvent, *CheckEvent;
    void *InstallProtocolInterface, *ReinstallProtocolInterface, *UninstallProtocolInterface;
    EFI_STATUS (*HandleProtocol)(EFI_HANDLE, const EFI_GUID *, void **);
    void *Reserved, *RegisterProtocolNotify, *LocateHandle, *LocateDevicePath, *InstallConfigurationTable;
    EFI_STATUS (*LoadImage)(BOOLEAN, EFI_HANDLE, EFI_DEVICE_PATH *, void *, UINTN, EFI_HANDLE *);
    EFI_STATUS (*StartImage)(EFI_HANDLE, UINTN *, CHAR16 **);
    void *Exit, *UnloadImage, *ExitBootServices, *GetNextMonotonicCount;
    EFI_STATUS (*Stall)(UINTN);
    void *SetWatchdogTimer, *ConnectController;
    EFI_STATUS (*DisconnectController)(EFI_HANDLE, EFI_HANDLE, EFI_HANDLE);
    void *OpenProtocol, *CloseProtocol;
    void *OpenProtocolInformation, *ProtocolsPerHandle;
    EFI_STATUS (*LocateHandleBuffer)(UINT32, const EFI_GUID *, void *, UINTN *, EFI_HANDLE **);
} EFI_BOOT_SERVICES;

typedef struct { EFI_GUID Guid; void *Table; } EFI_CONFIGURATION_TABLE;

typedef struct {
    EFI_TABLE_HEADER Hdr;
    CHAR16 *FirmwareVendor;
    UINT32 FirmwareRevision;
    EFI_HANDLE ConsoleInHandle;
    void *ConIn;
    EFI_HANDLE ConsoleOutHandle;
    SIMPLE_TEXT_OUT *ConOut;
    EFI_HANDLE StandardErrorHandle;
    void *StdErr;
    void *RuntimeServices;
    EFI_BOOT_SERVICES *BootServices;
    UINTN NumberOfTableEntries;
    EFI_CONFIGURATION_TABLE *ConfigurationTable;
} EFI_SYSTEM_TABLE;

typedef struct {
    UINT64 BaseAddress, Length, Capabilities, Attributes;
    UINT32 GcdMemoryType;
    EFI_HANDLE ImageHandle, DeviceHandle;
} EFI_GCD_MEMORY_SPACE_DESCRIPTOR;

#define GCD_SYSTEM_MEMORY 2

typedef struct {
    EFI_TABLE_HEADER Hdr;
    void *AddMemorySpace, *AllocateMemorySpace, *FreeMemorySpace, *RemoveMemorySpace;
    void *GetMemorySpaceDescriptor, *SetMemorySpaceAttributes;
    EFI_STATUS (*GetMemorySpaceMap)(UINTN *, EFI_GCD_MEMORY_SPACE_DESCRIPTOR **);
    void *AddIoSpace, *AllocateIoSpace, *FreeIoSpace, *RemoveIoSpace, *GetIoSpaceDescriptor, *GetIoSpaceMap;
    void *Dispatch, *Schedule, *Trust, *ProcessFirmwareVolume;
    EFI_STATUS (*SetMemorySpaceCapabilities)(UINT64, UINT64, UINT64);
} EFI_DXE_SERVICES;

typedef struct EFI_FILE {
    UINT64 Revision;
    EFI_STATUS (*Open)(struct EFI_FILE *, struct EFI_FILE **, const CHAR16 *, UINT64, UINT64);
    EFI_STATUS (*Close)(struct EFI_FILE *);
} EFI_FILE;

typedef struct {
    UINT64 Revision;
    EFI_STATUS (*OpenVolume)(void *, EFI_FILE **);
} EFI_SIMPLE_FS;

static const EFI_GUID DxeServicesGuid = { 0x05ad34ba, 0x6f02, 0x4214, { 0x95, 0x2e, 0x4d, 0xa0, 0x39, 0x8e, 0x2b, 0xb9 } };
static const EFI_GUID SimpleFsGuid    = { 0x964e5b22, 0x6459, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };
static const EFI_GUID DevicePathGuid  = { 0x09576e91, 0x6d3f, 0x11d2, { 0x8e, 0x39, 0x00, 0xa0, 0xc9, 0x69, 0x72, 0x3b } };

#define EFI_MEMORY_UC 0x1ULL
#define EFI_MEMORY_WC 0x2ULL
#define EFI_MEMORY_WT 0x4ULL
#define EFI_MEMORY_WB 0x8ULL
#define CACHE_CAPS (EFI_MEMORY_UC | EFI_MEMORY_WC | EFI_MEMORY_WT | EFI_MEMORY_WB)

static EFI_SYSTEM_TABLE *ST;
static EFI_BOOT_SERVICES *BS;

static void out(const CHAR16 *s) { ST->ConOut->OutputString(ST->ConOut, s); }

static void outa(const char *s)
{
    CHAR16 buf[128];
    unsigned n = 0;
    while (*s && n < 127) {
        if (*s == '\n') { buf[n++] = '\r'; if (n >= 127) break; }
        buf[n++] = (CHAR16)*s++;
    }
    buf[n] = 0;
    out(buf);
}

static void outx(UINT64 v)
{
    CHAR16 buf[19];
    buf[0] = '0'; buf[1] = 'x';
    for (int i = 0; i < 16; i++)
        buf[2 + i] = "0123456789abcdef"[(v >> ((15 - i) * 4)) & 0xf];
    buf[18] = 0;
    out(buf);
}

static int guid_eq(const EFI_GUID *a, const EFI_GUID *b)
{
    const UINT8 *x = (const UINT8 *)a, *y = (const UINT8 *)b;
    for (int i = 0; i < 16; i++)
        if (x[i] != y[i]) return 0;
    return 1;
}

static unsigned wlen(const CHAR16 *s) { unsigned n = 0; while (s[n]) n++; return n; }

static void count_uc(const char *when)
{
    UINTN size = 0, key, dsize;
    UINT32 dver;
    EFI_MEMORY_DESCRIPTOR *map = 0;
    BS->GetMemoryMap(&size, 0, &key, &dsize, &dver);
    size += 8 * dsize;
    if (EFI_ERROR(BS->AllocatePool(2 /* EfiLoaderData */, size, (void **)&map)))
        return;
    if (!EFI_ERROR(BS->GetMemoryMap(&size, map, &key, &dsize, &dver))) {
        unsigned total = 0, uc = 0;
        for (UINTN off = 0; off + dsize <= size; off += dsize) {
            EFI_MEMORY_DESCRIPTOR *d = (EFI_MEMORY_DESCRIPTOR *)((UINT8 *)map + off);
            if (d->Type == 7 /* EfiConventionalMemory */) {
                total++;
                if (d->Attribute & EFI_MEMORY_UC) uc++;
            }
        }
        outa("shim: memory map "); outa(when); outa(": conventional ranges ");
        outx(total); outa(", with UC "); outx(uc); outa("\n");
    }
    BS->FreePool(map);
}

static void add_cache_caps(void)
{
    EFI_DXE_SERVICES *ds = 0;
    for (UINTN i = 0; i < ST->NumberOfTableEntries; i++)
        if (guid_eq(&ST->ConfigurationTable[i].Guid, &DxeServicesGuid))
            ds = ST->ConfigurationTable[i].Table;
    if (!ds) { outa("shim: no DXE services table\n"); return; }

    UINTN n = 0;
    EFI_GCD_MEMORY_SPACE_DESCRIPTOR *map = 0;
    if (EFI_ERROR(ds->GetMemorySpaceMap(&n, &map))) { outa("shim: GetMemorySpaceMap failed\n"); return; }
    for (UINTN i = 0; i < n; i++) {
        EFI_GCD_MEMORY_SPACE_DESCRIPTOR *d = &map[i];
        if (d->GcdMemoryType != GCD_SYSTEM_MEMORY)
            continue;
        UINT64 caps = d->Capabilities | CACHE_CAPS;
        EFI_STATUS st = ds->SetMemorySpaceCapabilities(d->BaseAddress, d->Length, caps);
        outa("shim: RAM "); outx(d->BaseAddress); outa(" len "); outx(d->Length);
        outa(" caps "); outx(d->Capabilities); outa(" -> "); outx(caps);
        outa(" status "); outx(st); outa("\n");
    }
    BS->FreePool(map);
}

static const EFI_GUID Acpi20Guid = { 0x8868e871, 0xe4f1, 0x11d3, { 0xbc, 0x22, 0x00, 0x80, 0xc7, 0x3c, 0x88, 0x81 } };

static UINT32 rd32(const UINT8 *p) { return p[0] | p[1] << 8 | p[2] << 16 | (UINT32)p[3] << 24; }

static void outsig(const UINT8 *p)
{
    CHAR16 s[5] = { p[0], p[1], p[2], p[3], 0 };
    out(s);
}

/* Read-only report of the ACPI tables the firmware hands to Windows. */
static void report_acpi(void)
{
    const UINT8 *rsdp = 0;
    for (UINTN i = 0; i < ST->NumberOfTableEntries; i++)
        if (guid_eq(&ST->ConfigurationTable[i].Guid, &Acpi20Guid))
            rsdp = ST->ConfigurationTable[i].Table;
    if (!rsdp) { outa("shim: ACPI: no ACPI 2.0 RSDP in the configuration table\n"); return; }
    UINT32 xsdt_lo = rd32(rsdp + 24), xsdt_hi = rd32(rsdp + 28);
    outa("shim: ACPI: RSDP rev "); outx(rsdp[15]); outa(" XSDT "); outx(((UINT64)xsdt_hi << 32) | xsdt_lo); outa("\n");
    if (xsdt_hi || !xsdt_lo) return;
    const UINT8 *xsdt = (const UINT8 *)(UINTN)xsdt_lo;
    UINT32 n = (rd32(xsdt + 4) - 36) / 8;
    for (UINT32 i = 0; i < n; i++) {
        const UINT8 *t = (const UINT8 *)(UINTN)rd32(xsdt + 36 + i * 8);
        outa("shim: ACPI table "); outsig(t); outa(" len "); outx(rd32(t + 4)); outa(" rev "); outx(t[8]); outa("\n");
        if (t[0] == 'A' && t[1] == 'P' && t[2] == 'I' && t[3] == 'C') {
            UINT32 len = rd32(t + 4), gicc = 0, gicc_en = 0, gicd = 0, other = 0;
            for (UINT32 o = 44; o + 2 <= len && t[o + 1]; o += t[o + 1]) {
                if (t[o] == 0x0b) { gicc++; if (rd32(t + o + 12) & 1) gicc_en++; }
                else if (t[o] == 0x0c) gicd++;
                else other++;
            }
            outa("shim:   MADT: GICC "); outx(gicc); outa(" enabled "); outx(gicc_en);
            outa(" GICD "); outx(gicd); outa(" other "); outx(other); outa("\n");
        }
        if (t[0] == 'F' && t[1] == 'A' && t[2] == 'C' && t[3] == 'P' && rd32(t + 4) >= 131) {
            outa("shim:   FADT: flags "); outx(rd32(t + 112)); outa(" ARM_BOOT_ARCH "); outx(t[129] | t[130] << 8); outa("\n");
        }
    }
}

/* ---- ACPI tables for QEMU virt (GICv2, PSCI over HVC, architected timer) ---- */

#include "dsdt_aml.h"             /* tools/gen-dsdt.py: CPUs + PCIe host bridge */

#define QEMU_GICD   0x08000000u
#define QEMU_GICC   0x08010000u
#define QEMU_ECAM   0x3f000000u       /* 16 buses, highmem=off layout */
#define W10M_CPUS   W10M_DSDT_CPUS    /* matches run-qemu.ps1 -Smp */
#define EFI_ACPI_RECLAIM 9

static UINT8 *acpi_pool;
static UINTN acpi_used;

static UINT8 *acpi_alloc(UINTN n)
{
    UINT8 *p = acpi_pool + acpi_used;
    acpi_used += (n + 15) & ~15u;
    for (UINTN i = 0; i < n; i++) p[i] = 0;
    return p;
}

static void wr16(UINT8 *p, UINT32 v) { p[0] = (UINT8)v; p[1] = (UINT8)(v >> 8); }
static void wr32(UINT8 *p, UINT32 v) { wr16(p, v); wr16(p + 2, v >> 16); }
static void wr64(UINT8 *p, UINT64 v) { wr32(p, (UINT32)v); wr32(p + 4, (UINT32)(v >> 32)); }

static void fix_checksum(UINT8 *t, UINTN len, UINTN at)
{
    UINT8 s = 0;
    t[at] = 0;
    for (UINTN i = 0; i < len; i++) s += t[i];
    t[at] = (UINT8)(0x100 - s);
}

static UINT8 *acpi_header(const char *sig, UINT32 len, UINT8 rev)
{
    UINT8 *t = acpi_alloc(len);
    for (int i = 0; i < 4; i++) t[i] = sig[i];
    wr32(t + 4, len);
    t[8] = rev;
    const char *oem = "W10MQE", *tid = "QEMUVIRT";
    for (int i = 0; i < 6; i++) t[10 + i] = oem[i];
    for (int i = 0; i < 8; i++) t[16 + i] = tid[i];
    wr32(t + 24, 1);              /* OEM revision */
    wr32(t + 28, 0x4d303157);     /* creator "W10M" */
    wr32(t + 32, 1);
    return t;
}

static UINT32 xhci_input_base(void);

static UINT8 *build_dsdt(void)
{
    UINT8 *t = acpi_alloc(sizeof(w10m_dsdt));
    for (UINTN i = 0; i < sizeof(w10m_dsdt); i++) t[i] = w10m_dsdt[i];
#if W10M_XHCI_BASE_OFF >= 0
    UINT32 xb = xhci_input_base();                     /* XHC0: _STA OperationRegion + _CRS base */
    for (UINTN i = 0; i + 4 <= sizeof(w10m_dsdt); i++)  /* marker + register offset (gen-dsdt variants) */
        if (rd32(t + i) - 0x4B484358u < 0x10) wr32(t + i, xb + (rd32(t + i) - 0x4B484358u));
#endif
    fix_checksum(t, sizeof(w10m_dsdt), 9);
    return t;
}

static UINT8 *build_mcfg(void)
{
    UINT8 *t = acpi_header("MCFG", 60, 1);
    wr64(t + 44, QEMU_ECAM);                      /* ECAM base, segment 0 */
    t[54] = 0;                                    /* start bus */
    t[55] = 15;                                   /* end bus */
    fix_checksum(t, 60, 9);
    return t;
}

static UINT8 *build_fadt(UINT8 *dsdt)
{
    UINT8 *t = acpi_header("FACP", 276, 6);
    wr32(t + 40, (UINT32)(UINTN)dsdt);
    wr32(t + 112, (1u << 20) | (1u << 21));      /* HW_REDUCED_ACPI | LOW_POWER_S0_IDLE_CAPABLE */
    wr16(t + 129, 0x3);                           /* ARM_BOOT_ARCH: PSCI_COMPLIANT | PSCI_USE_HVC */
    t[131] = 0;                                   /* FADT minor version (ACPI 6.0) */
    wr64(t + 140, (UINT64)(UINTN)dsdt);           /* X_DSDT */
    fix_checksum(t, 276, 9);
    return t;
}

static UINT8 *build_madt(void)
{
    UINT32 len = 44 + 80 * W10M_CPUS + 24;
    UINT8 *t = acpi_header("APIC", len, 4);
    UINT8 *e = t + 44;
    for (int c = 0; c < W10M_CPUS; c++, e += 80) {
        e[0] = 0x0b; e[1] = 80;
        wr32(e + 4, (UINT32)c);                   /* CPU interface number */
        wr32(e + 8, (UINT32)c);                   /* ACPI processor UID (= _UID) */
        wr32(e + 12, 1);                          /* enabled */
        wr32(e + 20, 23);                         /* performance interrupt GSIV (PMU PPI 7) */
        wr64(e + 32, QEMU_GICC);                  /* GICC physical base */
        wr64(e + 68, (UINT64)c);                  /* MPIDR (Aff0) */
    }
    e[0] = 0x0c; e[1] = 24;
    wr64(e + 8, QEMU_GICD);
    e[20] = 2;                                    /* GIC version 2 */
    fix_checksum(t, len, 9);
    return t;
}

static UINT8 *build_gtdt(void)
{
    UINT8 *t = acpi_header("GTDT", 96, 2);
    wr64(t + 36, ~0ULL);                          /* CntControlBase: none */
    wr32(t + 48, 29);                             /* secure EL1 timer (PPI 13), level, active high */
    wr32(t + 56, 30);                             /* non-secure EL1 timer (PPI 14) */
    wr32(t + 64, 27);                             /* virtual timer (PPI 11) */
    wr32(t + 72, 26);                             /* EL2 timer (PPI 10) */
    wr64(t + 80, ~0ULL);                          /* CntReadBase: none */
    fix_checksum(t, 96, 9);
    return t;
}

#define UFS_ACPI_BASE 0x10100000u     /* = tools/gen-dsdt.py ufs-acpi */

static volatile UINT32 *ecam(UINT32 dev, UINT32 reg)
{
    return (volatile UINT32 *)(UINTN)(QEMU_ECAM + (dev << 15) + reg);
}

/* Give the QEMU UFS PCI function (1b36:0013) a fixed BAR and enable it, so the
 * controller can be described to Windows as a plain ACPI MMIO device. */
static void setup_ufs_mmio(void)
{
    for (UINT32 dev = 0; dev < 32; dev++) {
        if (*ecam(dev, 0) != 0x00131b36)
            continue;
        *ecam(dev, 0x04) = 0;                     /* decode off while moving the BAR */
        *ecam(dev, 0x10) = UFS_ACPI_BASE;
        *ecam(dev, 0x04) = 0x0006;                /* memory decode + bus master, INTx on */
        outa("shim: UFS PCI function at slot "); outx(dev); outa(" BAR0 "); outx(*ecam(dev, 0x10));
        outa(" cmd "); outx(*ecam(dev, 0x04) & 0xffff); outa(" UFSHCI CAP "); outx(*(volatile UINT32 *)(UINTN)UFS_ACPI_BASE);
        outa("\n");
        if (dev != 3)
            outa("shim: WARNING: DSDT assumes slot 3 (INTA -> GSIV 38)\n");
        /* UFSHCI register file as Windows will first see it (UFSHCI spec offsets) */
        static const struct { UINT32 off; const char *name; } regs[] = {
            { 0x00, "CAP" }, { 0x08, "VER" }, { 0x10, "HCPID" }, { 0x14, "HCMID" }, { 0x18, "AHIT" },
            { 0x20, "IS" }, { 0x24, "IE" }, { 0x30, "HCS" }, { 0x34, "HCE" }, { 0x38, "UECPA" },
            { 0x3c, "UECDL" }, { 0x40, "UECN" }, { 0x44, "UECT" }, { 0x48, "UECDME" }, { 0x4c, "UTRIACR" },
            { 0x50, "UTRLBA" }, { 0x54, "UTRLBAU" }, { 0x58, "UTRLDBR" }, { 0x5c, "UTRLCLR" }, { 0x60, "UTRLRSR" },
            { 0x70, "UTMRLBA" }, { 0x78, "UTMRLDBR" }, { 0x80, "UTMRLRSR" }, { 0x90, "UICCMD" },
        };
        for (unsigned i = 0; i < sizeof(regs) / sizeof(regs[0]); i++) {
            outa("shim:   UFSHCI "); outa(regs[i].name); outa(" ");
            outx(*(volatile UINT32 *)(UINTN)(UFS_ACPI_BASE + regs[i].off)); outa("\n");
        }
        /* storufs (Qualcomm configuration) also touches vendor registers past the 8 KiB UFSHCI BAR
         * (e.g. +0x3744); check what QEMU does with the unclaimed part of the PCI MMIO window */
        outa("shim: probe BAR0+0x3744 read ... ");
        outx(*(volatile UINT32 *)(UINTN)(UFS_ACPI_BASE + 0x3744));
        *(volatile UINT32 *)(UINTN)(UFS_ACPI_BASE + 0x3744) = 0;
        outa(" write ok\n");
        return;
    }
    outa("shim: no UFS PCI function found\n");
}

/* The input xHCI (qemu-xhci at PCI slot 8, run-qemu.ps1 -UsbInput) keeps the BAR the firmware gave it
 * (its UEFI driver may still be using the controller); described to Windows as ACPI PNP0D10. */
/* edk2's XhciDxe binds the input xHCI too and, at ExitBootServices, puts back the PCI attributes it found
 * (memory decode off): Windows would then see an xHCI with no registers (reads 0xffffffff), so acpi.sys
 * fails XHC0's _HID/_STA and USBXHCI never loads. Disconnect every driver from it before the chainload
 * and enable decode again; nothing in the firmware touches it afterwards. */
static const EFI_GUID PciIoGuid = { 0x4cf5b200, 0x68b8, 0x4ca5, { 0x9e, 0xec, 0xb2, 0x3e, 0x3f, 0x50, 0x02, 0x9a } };
typedef EFI_STATUS (*PCI_GET_LOCATION)(void *, UINTN *, UINTN *, UINTN *, UINTN *);

static void release_input_xhci(void)
{
    UINTN n = 0;
    EFI_HANDLE *hs = 0;
    if (*ecam(8, 0) != 0x000d1b36 || EFI_ERROR(BS->LocateHandleBuffer(2 /* ByProtocol */, &PciIoGuid, 0, &n, &hs)))
        return;
    for (UINTN i = 0; i < n; i++) {
        void **pciio;
        UINTN seg, bus, dev, fn;
        if (EFI_ERROR(BS->HandleProtocol(hs[i], &PciIoGuid, (void **)&pciio)) ||
            EFI_ERROR(((PCI_GET_LOCATION)pciio[14])(pciio, &seg, &bus, &dev, &fn)) || bus || dev != 8 || fn)
            continue;
        EFI_STATUS r = BS->DisconnectController(hs[i], 0, 0);
        *ecam(8, 0x04) |= 0x0006;                 /* memory decode + bus master */
        outa("shim: input xHCI released from firmware drivers, status "); outx(r);
        outa(" cmd "); outx(*ecam(8, 0x04) & 0xffff); outa(" CAPLENGTH/HCIVERSION ");
        outx(*(volatile UINT32 *)(UINTN)(*ecam(8, 0x10) & ~0xfu)); outa("\n");
    }
    BS->FreePool(hs);
}

static UINT32 xhci_input_base(void)
{
    const UINT32 dev = 8;
    if (*ecam(dev, 0) != 0x000d1b36) {
        outa("shim: no input xHCI (1b36:000d) at slot 8\n");
        return 0;
    }
    UINT32 bar = *ecam(dev, 0x10) & ~0xfu;
    *ecam(dev, 0x04) |= 0x0006;                   /* memory decode + bus master */
    outa("shim: input xHCI at slot 8 BAR0 "); outx(bar); outa(" BAR1 "); outx(*ecam(dev, 0x14));
    outa(" CAPLENGTH/HCIVERSION "); outx(bar ? *(volatile UINT32 *)(UINTN)bar : 0); outa("\n");
    return bar;
}

static void install_acpi(void)
{
    if (EFI_ERROR(BS->AllocatePool(EFI_ACPI_RECLAIM, 8192, (void **)&acpi_pool))) {
        outa("shim: ACPI: allocation failed\n");
        return;
    }
    acpi_used = 0;
    UINT8 *dsdt = build_dsdt();
    UINT8 *tables[4] = { build_fadt(dsdt), build_madt(), build_gtdt(), W10M_DSDT_PCI ? build_mcfg() : 0 };
    int nt = W10M_DSDT_PCI ? 4 : 3;
    UINT32 xlen = 36 + 8 * nt;
    UINT8 *xsdt = acpi_header("XSDT", xlen, 1);
    for (int i = 0; i < nt; i++) wr64(xsdt + 36 + 8 * i, (UINT64)(UINTN)tables[i]);
    if (W10M_UFS_ACPI)
        setup_ufs_mmio();
    fix_checksum(xsdt, xlen, 9);

    UINT8 *rsdp = acpi_alloc(36);
    const char *sig = "RSD PTR ", *oem = "W10MQE";
    for (int i = 0; i < 8; i++) rsdp[i] = sig[i];
    for (int i = 0; i < 6; i++) rsdp[9 + i] = oem[i];
    rsdp[15] = 2;
    wr32(rsdp + 20, 36);
    wr64(rsdp + 24, (UINT64)(UINTN)xsdt);
    fix_checksum(rsdp, 20, 8);
    fix_checksum(rsdp, 36, 32);

    typedef EFI_STATUS (*INSTALL_CFG)(const EFI_GUID *, void *);
    EFI_STATUS st = ((INSTALL_CFG)BS->InstallConfigurationTable)(&Acpi20Guid, rsdp);
    outa("shim: ACPI: installed RSDP "); outx((UINTN)rsdp); outa(" ("); outx(acpi_used);
    outa(" bytes) status "); outx(st); outa("\n");
}

/* ---- portrait display: own GOP mode on QEMU's ramfb ----------------------------------------------
 * The firmware's ramfb driver only offers landscape modes. Program ramfb (fw_cfg file "etc/ramfb")
 * with a framebuffer of our own size and take over the firmware's GOP so that Windows Boot Manager /
 * winload (and through them the kernel's boot framebuffer and BasicDisplay) see one portrait mode. */
#ifndef W10M_FB_W
#define W10M_FB_W 1080                /* Xiaomi Poco F3 panel; 1440x2560 = HP Elite x3 */
#endif
#ifndef W10M_FB_H
#define W10M_FB_H 2400
#endif
#define FWCFG_DATA   0x09020000u
#define FWCFG_SEL    0x09020008u
#define FWCFG_DMA    0x09020010u
#define FWCFG_FILE_DIR 0x19

typedef struct { UINT8 Blue, Green, Red, Reserved; } GOP_PIXEL;
typedef struct {
    UINT32 Version, HorizontalResolution, VerticalResolution, PixelFormat;
    UINT32 RedMask, GreenMask, BlueMask, ReservedMask, PixelsPerScanLine;
} GOP_MODE_INFO;
typedef struct {
    UINT32 MaxMode, Mode;
    GOP_MODE_INFO *Info;
    UINTN SizeOfInfo;
    UINT64 FrameBufferBase;
    UINTN FrameBufferSize;
} GOP_MODE;
typedef struct GOP {
    EFI_STATUS (*QueryMode)(struct GOP *, UINT32, UINTN *, GOP_MODE_INFO **);
    EFI_STATUS (*SetMode)(struct GOP *, UINT32);
    EFI_STATUS (*Blt)(struct GOP *, GOP_PIXEL *, UINT32, UINTN, UINTN, UINTN, UINTN, UINTN, UINTN, UINTN);
    GOP_MODE *Mode;
} GOP;

static const EFI_GUID GopGuid = { 0x9042a9de, 0x23dc, 0x4a38, { 0x96, 0xfb, 0x7a, 0xde, 0xd0, 0x80, 0x51, 0x6a } };
static GOP_MODE_INFO fb_info;
static UINT32 *fb;

static UINT16 bswap16(UINT16 v) { return (UINT16)(v << 8 | v >> 8); }
static UINT32 bswap32(UINT32 v) { return v << 24 | (v & 0xff00) << 8 | (v >> 8 & 0xff00) | v >> 24; }
static void be32(UINT8 *p, UINT32 v) { p[0] = (UINT8)(v >> 24); p[1] = (UINT8)(v >> 16); p[2] = (UINT8)(v >> 8); p[3] = (UINT8)v; }

static void fwcfg_select(UINT16 key) { *(volatile UINT16 *)(UINTN)FWCFG_SEL = bswap16(key); }
static UINT8 fwcfg_byte(void) { return *(volatile UINT8 *)(UINTN)FWCFG_DATA; }

/* fw_cfg selector of a named file, 0 if absent */
static UINT16 fwcfg_find(const char *name)
{
    fwcfg_select(FWCFG_FILE_DIR);
    UINT32 n = 0;
    for (int i = 0; i < 4; i++) n = n << 8 | fwcfg_byte();
    for (UINT32 e = 0; e < n; e++) {
        UINT8 ent[64];
        for (int i = 0; i < 64; i++) ent[i] = fwcfg_byte();
        int same = 1;
        for (int i = 0; ; i++) {
            if (ent[8 + i] != (UINT8)name[i]) { same = 0; break; }
            if (!name[i]) break;
        }
        if (same) return (UINT16)(ent[4] << 8 | ent[5]);   /* entry: size[4] select[2] reserved[2] name[56] */
    }
    return 0;
}

/* write a buffer to an fw_cfg file with the DMA interface (data-port writes are not supported) */
static int fwcfg_dma_write(UINT16 key, const void *buf, UINT32 len)
{
    static UINT8 acc[16] __attribute__((aligned(16)));
    be32(acc, (UINT32)key << 16 | 0x08 /* select */ | 0x10 /* write */);
    be32(acc + 4, len);
    be32(acc + 8, 0);
    be32(acc + 12, (UINT32)(UINTN)buf);
    __asm__ volatile("dsb sy" ::: "memory");
    *(volatile UINT32 *)(UINTN)FWCFG_DMA = bswap32(0);
    *(volatile UINT32 *)(UINTN)(FWCFG_DMA + 4) = bswap32((UINT32)(UINTN)acc);   /* starts the transfer */
    for (int i = 0; i < 1000000; i++) {
        __asm__ volatile("dsb sy" ::: "memory");
        UINT32 c = (UINT32)acc[0] << 24 | acc[1] << 16 | acc[2] << 8 | acc[3];
        if (!(c & ~1u)) return !(c & 1);                  /* done; bit 0 = error */
    }
    return 0;
}

static EFI_STATUS gop_query(GOP *g, UINT32 mode, UINTN *size, GOP_MODE_INFO **info)
{
    (void)g;
    if (mode != 0 || !size || !info) return 0x80000002;  /* EFI_INVALID_PARAMETER */
    *size = sizeof(GOP_MODE_INFO);
    EFI_STATUS st = BS->AllocatePool(4 /* EfiBootServicesData */, sizeof(GOP_MODE_INFO), (void **)info);
    if (!EFI_ERROR(st))
        **info = fb_info;
    return st;
}

static EFI_STATUS gop_set(GOP *g, UINT32 mode)
{
    (void)g;
    if (mode != 0) return 0x80000003;                     /* EFI_UNSUPPORTED */
    for (UINTN i = 0; i < (UINTN)W10M_FB_W * W10M_FB_H; i++) fb[i] = 0;
    return 0;
}

/* EfiBltVideoFill 0, VideoToBltBuffer 1, BufferToVideo 2, VideoToVideo 3; 32-bit BGRX both sides */
static EFI_STATUS gop_blt(GOP *g, GOP_PIXEL *buf, UINT32 op, UINTN sx, UINTN sy, UINTN dx, UINTN dy,
                          UINTN w, UINTN h, UINTN delta)
{
    (void)g;
    if (!delta) delta = w * 4;
    UINT32 *p = (UINT32 *)buf;
    for (UINTN y = 0; y < h; y++) {
        for (UINTN x = 0; x < w; x++) {
            switch (op) {
            case 0:
                if (dx + x < W10M_FB_W && dy + y < W10M_FB_H) fb[(dy + y) * W10M_FB_W + dx + x] = p[0];
                break;
            case 1:
                if (sx + x < W10M_FB_W && sy + y < W10M_FB_H)
                    p[((dy + y) * delta) / 4 + dx + x] = fb[(sy + y) * W10M_FB_W + sx + x];
                break;
            case 2:
                if (dx + x < W10M_FB_W && dy + y < W10M_FB_H)
                    fb[(dy + y) * W10M_FB_W + dx + x] = p[((sy + y) * delta) / 4 + sx + x];
                break;
            case 3:
                if (sx + x < W10M_FB_W && sy + y < W10M_FB_H && dx + x < W10M_FB_W && dy + y < W10M_FB_H)
                    fb[(dy + y) * W10M_FB_W + dx + x] = fb[(sy + y) * W10M_FB_W + sx + x];
                break;
            default:
                return 0x80000002;
            }
        }
    }
    return 0;
}

static void setup_portrait_gop(void)
{
    UINTN n = 0;
    EFI_HANDLE *hs = 0;
    GOP *gop = 0;
    if (EFI_ERROR(BS->LocateHandleBuffer(2, &GopGuid, 0, &n, &hs)) || !n ||
        EFI_ERROR(BS->HandleProtocol(hs[0], &GopGuid, (void **)&gop))) {
        outa("shim: GOP: none\n");
        return;
    }
    UINT16 key = fwcfg_find("etc/ramfb");
    UINTN bytes = (UINTN)W10M_FB_W * W10M_FB_H * 4;
    UINT64 addr = 0xffffffffu;                            /* below 4 GiB */
    typedef EFI_STATUS (*ALLOC_PAGES)(UINT32, UINT32, UINTN, UINT64 *);
    if (!key) {
        outa("shim: GOP: fw_cfg file etc/ramfb not found\n");
        return;
    }
    EFI_STATUS ast = ((ALLOC_PAGES)BS->AllocatePages)(1 /* AllocateMaxAddress */, 0 /* EfiReservedMemoryType */,
                                                      (bytes + 4095) / 4096, &addr);
    if (EFI_ERROR(ast)) {
        outa("shim: GOP: AllocatePages failed "); outx(ast); outa("\n");
        return;
    }
    fb = (UINT32 *)(UINTN)addr;
    for (UINTN i = 0; i < bytes / 4; i++) fb[i] = 0;
    UINT8 cfg[28];
    be32(cfg, 0); be32(cfg + 4, (UINT32)addr);           /* addr (64-bit BE) */
    be32(cfg + 8, 0x34325258);                            /* DRM_FORMAT_XRGB8888 'XR24' */
    be32(cfg + 12, 0);
    be32(cfg + 16, W10M_FB_W); be32(cfg + 20, W10M_FB_H); be32(cfg + 24, W10M_FB_W * 4);
    if (!fwcfg_dma_write(key, cfg, sizeof(cfg))) {
        outa("shim: GOP: ramfb fw_cfg DMA write failed\n");
        return;
    }
    fb_info.Version = 0;
    fb_info.HorizontalResolution = W10M_FB_W;
    fb_info.VerticalResolution = W10M_FB_H;
    fb_info.PixelFormat = 1;                              /* PixelBlueGreenRedReserved8BitPerColor */
    fb_info.PixelsPerScanLine = W10M_FB_W;
    gop->QueryMode = gop_query;
    gop->SetMode = gop_set;
    gop->Blt = gop_blt;
    gop->Mode->MaxMode = 1;
    gop->Mode->Mode = 0;
    *gop->Mode->Info = fb_info;
    gop->Mode->SizeOfInfo = sizeof(GOP_MODE_INFO);
    gop->Mode->FrameBufferBase = addr;
    gop->Mode->FrameBufferSize = bytes;
    outa("shim: GOP: portrait "); outx(W10M_FB_W); outa("x"); outx(W10M_FB_H); outa(" framebuffer "); outx(addr); outa("\n");
}

static int has_file(EFI_FILE *root, const CHAR16 *path)
{
    EFI_FILE *f = 0;
    if (EFI_ERROR(root->Open(root, &f, path, 1 /* read */, 0)))
        return 0;
    f->Close(f);
    return 1;
}

static EFI_STATUS chainload(EFI_HANDLE self)
{
    static const CHAR16 target[] = u"\\EFI\\BOOT\\bootarm.efi";
    UINTN n = 0;
    EFI_HANDLE *hs = 0;
    if (EFI_ERROR(BS->LocateHandleBuffer(2 /* ByProtocol */, &SimpleFsGuid, 0, &n, &hs)))
        return 1;
    for (UINTN i = 0; i < n; i++) {
        EFI_SIMPLE_FS *fs = 0;
        EFI_FILE *root = 0;
        if (EFI_ERROR(BS->HandleProtocol(hs[i], &SimpleFsGuid, (void **)&fs)) || EFI_ERROR(fs->OpenVolume(fs, &root)))
            continue;
        int ok = has_file(root, u"\\EFI\\Microsoft\\boot\\BCD") &&
                 has_file(root, u"\\Windows\\System32\\boot\\mobilestartup.efi") &&
                 has_file(root, target);
        root->Close(root);
        if (!ok)
            continue;

        EFI_DEVICE_PATH *dp = 0;
        if (EFI_ERROR(BS->HandleProtocol(hs[i], &DevicePathGuid, (void **)&dp)))
            continue;
        UINTN dplen = 0;
        for (EFI_DEVICE_PATH *p = dp; !(p->Type == 0x7f && p->SubType == 0xff);
             p = (EFI_DEVICE_PATH *)((UINT8 *)p + (p->Length[0] | p->Length[1] << 8)))
            dplen += p->Length[0] | p->Length[1] << 8;
        UINTN flen = 4 + (wlen(target) + 1) * 2;
        UINT8 *full = 0;
        if (EFI_ERROR(BS->AllocatePool(2, dplen + flen + 4, (void **)&full)))
            return 1;
        for (UINTN k = 0; k < dplen; k++) full[k] = ((UINT8 *)dp)[k];
        UINT8 *fp = full + dplen;
        fp[0] = 4; fp[1] = 4; fp[2] = (UINT8)flen; fp[3] = (UINT8)(flen >> 8);
        for (unsigned k = 0; k <= wlen(target); k++) { fp[4 + 2 * k] = (UINT8)target[k]; fp[5 + 2 * k] = (UINT8)(target[k] >> 8); }
        UINT8 *end = fp + flen;
        end[0] = 0x7f; end[1] = 0xff; end[2] = 4; end[3] = 0;

        EFI_HANDLE img = 0;
        EFI_STATUS st = BS->LoadImage(0, self, (EFI_DEVICE_PATH *)full, 0, 0, &img);
        outa("shim: W10M EFIESP found, LoadImage(bootarm.efi) status "); outx(st); outa("\n");
        if (EFI_ERROR(st))
            return st;
        st = BS->StartImage(img, 0, 0);
        outa("shim: bootarm.efi returned "); outx(st); outa("\n");
        return st;
    }
    outa("shim: no W10M EFIESP found\n");
    return 1;
}

EFI_STATUS efi_main(EFI_HANDLE image, EFI_SYSTEM_TABLE *st)
{
    ST = st;
    BS = st->BootServices;
    outa("\nshim: w10mshim for Windows 10 Mobile on QEMU virt\n");
    count_uc("before");
    add_cache_caps();
    count_uc("after");
    report_acpi();
    {
        int have = 0;
        for (UINTN i = 0; i < ST->NumberOfTableEntries; i++)
            if (guid_eq(&ST->ConfigurationTable[i].Guid, &Acpi20Guid)) have = 1;
        if (!have) { install_acpi(); report_acpi(); }
    }
    setup_portrait_gop();
    release_input_xhci();
    EFI_STATUS r = chainload(image);
    BS->Stall(5000000);
    return r;
}
