/*
 * kgsl-probe: does the phone's Adreno 650 run in the recovery?
 *
 * Opens /dev/kgsl-3d0 (the Qualcomm GPU driver of the phone's kernel), reads the device info, makes a draw
 * context, allocates GPU memory, submits a tiny command buffer (PM4 CP_MEM_WRITE of a magic value) and waits
 * for it. If the magic shows up in the memory, the GPU's microcode, GMU and the command path all work and a
 * render backend (Mesa turnip, Vulkan over kgsl) can be built on top of it.
 *
 * The kernel loads a650_sqe.fw / a650_gmu.bin / a650_zap.* on the first open; in the recovery the vendor
 * partition is not mounted, so liveboot points the firmware loader at a read-only mount of it
 * (/sys/module/firmware_class/parameters/path, RAM only).
 *
 * Build: aarch64-linux-gnu-gcc -O2 -Wall -static -s -o kgsl-probe kgsl-probe.c
 */
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

/* --- the kgsl uapi (msm_kgsl.h of the 4.19 Qualcomm kernel), only what is used here --- */
#define KGSL_IOC_TYPE 0x09

struct kgsl_device_getproperty { unsigned int type; void *value; size_t sizebytes; };
#define IOCTL_KGSL_DEVICE_GETPROPERTY _IOWR(KGSL_IOC_TYPE, 0x2, struct kgsl_device_getproperty)
#define KGSL_PROP_DEVICE_INFO 0x1
struct kgsl_devinfo {
    unsigned int device_id, chip_id, mmu_enabled;
    unsigned long gmem_gpubaseaddr;
    unsigned int gpu_id;
    size_t gmem_sizebytes;
};

struct kgsl_drawctxt_create { unsigned int flags; unsigned int drawctxt_id; };
#define IOCTL_KGSL_DRAWCTXT_CREATE _IOWR(KGSL_IOC_TYPE, 0x13, struct kgsl_drawctxt_create)
struct kgsl_drawctxt_destroy { unsigned int drawctxt_id; };
#define IOCTL_KGSL_DRAWCTXT_DESTROY _IOW(KGSL_IOC_TYPE, 0x14, struct kgsl_drawctxt_destroy)
#define KGSL_CONTEXT_NO_GMEM_ALLOC 0x00000002
#define KGSL_CONTEXT_PREAMBLE 0x00000010
#define KGSL_CONTEXT_TYPE_GL (1u << 20)

struct kgsl_gpumem_alloc_id {
    unsigned int id, flags;
    size_t size, mmapsize;
    unsigned long gpuaddr;
    unsigned long __pad[2];
};
#define IOCTL_KGSL_GPUMEM_ALLOC_ID _IOWR(KGSL_IOC_TYPE, 0x34, struct kgsl_gpumem_alloc_id)
struct kgsl_gpumem_free_id { unsigned int id, __pad; };
#define IOCTL_KGSL_GPUMEM_FREE_ID _IOWR(KGSL_IOC_TYPE, 0x35, struct kgsl_gpumem_free_id)

struct kgsl_command_object { uint64_t offset, gpuaddr, size; unsigned int flags, id; };
#define KGSL_CMDLIST_IB 0x00000001U
struct kgsl_gpu_command {
    uint64_t flags;
    uint64_t cmdlist; unsigned int cmdsize, numcmds;
    uint64_t objlist; unsigned int objsize, numobjs;
    uint64_t synclist; unsigned int syncsize, numsyncs;
    unsigned int context_id, timestamp;
};
#define IOCTL_KGSL_GPU_COMMAND _IOWR(KGSL_IOC_TYPE, 0x4A, struct kgsl_gpu_command)

struct kgsl_device_waittimestamp_ctxtid { unsigned int context_id, timestamp, timeout; };
#define IOCTL_KGSL_DEVICE_WAITTIMESTAMP_CTXTID _IOW(KGSL_IOC_TYPE, 0x7, struct kgsl_device_waittimestamp_ctxtid)

/* --- PM4 type-7 packets (a5xx and later) --- */
static unsigned odd_parity(unsigned v)
{
    v ^= v >> 16; v ^= v >> 8; v ^= v >> 4; v &= 0xf;
    return (~0x6996u >> v) & 1;
}
static uint32_t pkt7(unsigned op, unsigned cnt)
{
    return 0x70000000u | (cnt & 0x3fff) | (odd_parity(cnt) << 15) | ((op & 0x7f) << 16) | (odd_parity(op) << 23);
}
#define CP_MEM_WRITE 0x3d
#define CP_NOP 0x10

static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

int main(void)
{
    double t0 = now();
    int fd = open("/dev/kgsl-3d0", O_RDWR);
    if (fd < 0) { printf("FAIL open /dev/kgsl-3d0: %s\n", strerror(errno)); return 1; }
    printf("open: %.0f ms (firmware load and GPU power-up happen here)\n", (now() - t0) * 1000);

    struct kgsl_devinfo di = {0};
    struct kgsl_device_getproperty gp = { KGSL_PROP_DEVICE_INFO, &di, sizeof di };
    if (ioctl(fd, IOCTL_KGSL_DEVICE_GETPROPERTY, &gp)) { printf("FAIL getproperty: %s\n", strerror(errno)); return 1; }
    printf("device_id %u chip_id 0x%08x gpu_id %u mmu %u gmem %zu KB\n", di.device_id, di.chip_id, di.gpu_id,
           di.mmu_enabled, di.gmem_sizebytes / 1024);

    struct kgsl_drawctxt_create cc = { KGSL_CONTEXT_NO_GMEM_ALLOC | KGSL_CONTEXT_PREAMBLE | KGSL_CONTEXT_TYPE_GL, 0 };
    t0 = now();
    if (ioctl(fd, IOCTL_KGSL_DRAWCTXT_CREATE, &cc)) { printf("FAIL drawctxt_create: %s\n", strerror(errno)); return 1; }
    printf("context %u (%.0f ms)\n", cc.drawctxt_id, (now() - t0) * 1000);

    struct kgsl_gpumem_alloc_id ma = { .size = 4096 };
    if (ioctl(fd, IOCTL_KGSL_GPUMEM_ALLOC_ID, &ma)) { printf("FAIL gpumem_alloc: %s\n", strerror(errno)); return 1; }
    volatile uint32_t *m = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, (off_t)ma.id << 12);
    if (m == MAP_FAILED) { printf("FAIL mmap: %s\n", strerror(errno)); return 1; }
    printf("buffer id %u gpuaddr 0x%lx\n", ma.id, ma.gpuaddr);

    /* the command buffer at +0, the target dword at +0x800 */
    uint64_t target = ma.gpuaddr + 0x800;
    m[0x800 / 4] = 0xdeadbeef;
    unsigned n = 0;
    m[n++] = pkt7(CP_NOP, 0);
    m[n++] = pkt7(CP_MEM_WRITE, 3);
    m[n++] = (uint32_t)target;
    m[n++] = (uint32_t)(target >> 32);
    m[n++] = 0x0a650c0d;
    __sync_synchronize();

    struct kgsl_command_object ib = { .gpuaddr = ma.gpuaddr, .size = n * 4, .flags = KGSL_CMDLIST_IB, .id = ma.id };
    struct kgsl_gpu_command gc = {
        .cmdlist = (uintptr_t)&ib, .cmdsize = sizeof ib, .numcmds = 1, .context_id = cc.drawctxt_id,
    };
    t0 = now();
    if (ioctl(fd, IOCTL_KGSL_GPU_COMMAND, &gc)) { printf("FAIL gpu_command: %s\n", strerror(errno)); return 1; }
    struct kgsl_device_waittimestamp_ctxtid w = { cc.drawctxt_id, gc.timestamp, 3000 };
    int r = ioctl(fd, IOCTL_KGSL_DEVICE_WAITTIMESTAMP_CTXTID, &w);
    double ms = (now() - t0) * 1000;
    __sync_synchronize();
    uint32_t got = m[0x800 / 4];
    printf("submit ts %u, wait %s (%.2f ms), value 0x%08x\n", gc.timestamp, r ? strerror(errno) : "ok", ms, got);

    /* round trip latency of an empty submission, what one frame would pay at least */
    double best = 1e9, sum = 0;
    for (int i = 0; i < 100; i++) {
        t0 = now();
        if (ioctl(fd, IOCTL_KGSL_GPU_COMMAND, &gc)) break;
        w.timestamp = gc.timestamp;
        ioctl(fd, IOCTL_KGSL_DEVICE_WAITTIMESTAMP_CTXTID, &w);
        double d = (now() - t0) * 1e6;
        sum += d;
        if (d < best) best = d;
    }
    printf("100 submissions: best %.0f us, mean %.0f us\n", best, sum / 100);

    struct kgsl_gpumem_free_id mf = { ma.id, 0 };
    munmap((void *)m, 4096);
    ioctl(fd, IOCTL_KGSL_GPUMEM_FREE_ID, &mf);
    struct kgsl_drawctxt_destroy cd = { cc.drawctxt_id };
    ioctl(fd, IOCTL_KGSL_DRAWCTXT_DESTROY, &cd);
    close(fd);
    printf(got == 0x0a650c0d ? "OK: the Adreno 650 executes command buffers\n" : "FAIL: the GPU did not write\n");
    return got != 0x0a650c0d;
}
