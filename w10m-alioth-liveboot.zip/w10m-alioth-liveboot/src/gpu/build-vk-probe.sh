#!/usr/bin/env bash
# vk-probe for the phone: SPIR-V headers from tri.vert / tri.frag, Vulkan headers from the Mesa tree.
# Run:  wsl -e bash /mnt/c/win10mobile/src/gpu/build-vk-probe.sh   (after build-turnip-aarch64.sh)
set -e
S=/mnt/c/win10mobile/src/gpu
T=$(mktemp -d)
glslangValidator -V --vn tri_vert -o "$T/tri_vert.h" "$S/tri.vert" >/dev/null
glslangValidator -V --vn tri_frag -o "$T/tri_frag.h" "$S/tri.frag" >/dev/null
aarch64-linux-gnu-gcc -O2 -Wall -s -I "$T" -I ~/mesa/mesa-26.2.7/include -o /mnt/c/win10mobile/work/gpu-a64/vk-probe "$S/vk-probe.c" -ldl
rm -rf "$T"
ls -la /mnt/c/win10mobile/work/gpu-a64/vk-probe
