#!/usr/bin/env bash
# Builds Mesa's turnip (Vulkan for Adreno 6xx) for the phone's recovery: aarch64 glibc, the kgsl kernel
# interface only (/dev/kgsl-3d0, no msm DRM, no window system). Output: work/gpu-a64/ (libvulkan_freedreno.so,
# its icd json, and the extra shared libraries next to the QEMU ones).
# Needs: mesa-26.2.7.tar.xz in ~/mesa (sha256 04294f75d22e9f61cd1e050206bc48b3d39366e788f1803a3368e3d5a872ce18,
#   docs.mesa3d.org/relnotes/26.2.7.html), apt: python3-mako python3-yaml glslang-tools libdrm-dev:arm64
#   libexpat1-dev:arm64 libzstd-dev:arm64 (plus the QEMU cross set, src/qemu/build-qemu-aarch64.sh)
# Run:  wsl -e bash /mnt/c/win10mobile/src/gpu/build-turnip-aarch64.sh
set -e
ROOT=/mnt/c/win10mobile
OUT=$ROOT/work/gpu-a64
cd ~/mesa
[ -d mesa-26.2.7 ] || tar xJf mesa-26.2.7.tar.xz
cat > cross-aarch64.txt <<'X'
[binaries]
c = 'aarch64-linux-gnu-gcc'
cpp = 'aarch64-linux-gnu-g++'
ar = 'aarch64-linux-gnu-ar'
strip = 'aarch64-linux-gnu-strip'
pkg-config = 'pkg-config'
[properties]
pkg_config_libdir = '/usr/lib/aarch64-linux-gnu/pkgconfig:/usr/share/pkgconfig'
[host_machine]
system = 'linux'
cpu_family = 'aarch64'
cpu = 'armv8.2-a'
endian = 'little'
X
if [ ! -f build/build.ninja ]; then
    meson setup build mesa-26.2.7 --cross-file cross-aarch64.txt --buildtype=release -Db_ndebug=true \
        -Dgallium-drivers= -Dvulkan-drivers=freedreno -Dfreedreno-kmds=kgsl -Dplatforms= \
        -Dglx=disabled -Degl=disabled -Dgbm=disabled -Dopengl=false -Dgles1=disabled -Dgles2=disabled \
        -Dllvm=disabled -Dshared-glapi=disabled -Dvalgrind=disabled -Dlibunwind=disabled -Dzstd=enabled \
        -Dvulkan-layers= -Dtools= -Dbuild-tests=false -Dxmlconfig=disabled > setup.log 2>&1 \
        || { tail -40 setup.log; exit 1; }
fi
ninja -C build > build.log 2>&1 || { grep -m20 -B2 -A6 -i 'error' build.log; exit 1; }
rm -rf "$OUT" && mkdir -p "$OUT/lib"
aarch64-linux-gnu-strip -o "$OUT/libvulkan_freedreno.so" build/src/freedreno/vulkan/libvulkan_freedreno.so
L=/usr/lib/aarch64-linux-gnu
for n in $(aarch64-linux-gnu-readelf -d "$OUT/libvulkan_freedreno.so" | sed -n 's/.*NEEDED.*\[\(.*\)\]/\1/p'); do
    [ -f "$ROOT/work/qemu-a64/lib/$n" ] && continue
    for d in $L /usr/aarch64-linux-gnu/lib; do [ -f "$d/$n" ] && { cp -L "$d/$n" "$OUT/lib/"; break; }; done
done
ls -la "$OUT" "$OUT/lib"
