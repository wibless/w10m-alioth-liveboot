/*
 * vk-probe: Vulkan on the phone's Adreno 650 in the recovery, through Mesa turnip (kgsl backend).
 *
 * No Vulkan loader: the ICD (libvulkan_freedreno.so) is opened directly and its vk_icdGetInstanceProcAddr
 * gives every entry point. The test does what the display path needs:
 *   1. renders a red triangle on blue into a 1440x2560 image (Windows' internal size): shaders compile, draw works;
 *   2. scales it down to 720x1280 with a linear blit (what the panel shows);
 *   3. copies the result to host memory and checks the pixels;
 *   4. repeats the whole frame 100 times and reports the time per frame.
 *
 * Build: see build-vk-probe.sh (SPIR-V from glslangValidator, headers from the Mesa tree).
 * Run on the phone: LD_LIBRARY_PATH=. ./vk-probe ./libvulkan_freedreno.so
 */
#include <dlfcn.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <vulkan/vulkan.h>

#include "tri_vert.h"
#include "tri_frag.h"

#define SW 1440
#define SH 2560
#define DW 720
#define DH 1280

static PFN_vkGetInstanceProcAddr gipa;
static VkInstance inst;
static VkDevice dev;

#define CK(x) do { VkResult r_ = (x); if (r_ != VK_SUCCESS) { printf("FAIL %s: %d\n", #x, r_); exit(1); } } while (0)
#define IFN(n) PFN_##n n = (PFN_##n)gipa(inst, #n)

static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}

static VkPhysicalDeviceMemoryProperties mp;
static uint32_t memtype(uint32_t bits, VkMemoryPropertyFlags want)
{
    for (uint32_t i = 0; i < mp.memoryTypeCount; i++)
        if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & want) == want) return i;
    printf("FAIL no memory type 0x%x for bits 0x%x\n", want, bits);
    exit(1);
}

int main(int argc, char **argv)
{
    const char *icd = argc > 1 ? argv[1] : "./libvulkan_freedreno.so";
    void *h = dlopen(icd, RTLD_NOW | RTLD_LOCAL);
    if (!h) { printf("FAIL dlopen: %s\n", dlerror()); return 1; }
    VkResult (*neg)(uint32_t *) = (VkResult (*)(uint32_t *))dlsym(h, "vk_icdNegotiateLoaderICDInterfaceVersion");
    gipa = (PFN_vkGetInstanceProcAddr)dlsym(h, "vk_icdGetInstanceProcAddr");
    if (!gipa) { printf("FAIL no vk_icdGetInstanceProcAddr\n"); return 1; }
    uint32_t ver = 5;
    if (neg) neg(&ver);

    double t0 = now();
    PFN_vkCreateInstance vkCreateInstance = (PFN_vkCreateInstance)gipa(NULL, "vkCreateInstance");
    VkApplicationInfo app = { VK_STRUCTURE_TYPE_APPLICATION_INFO, .pApplicationName = "vk-probe", .apiVersion = VK_API_VERSION_1_1 };
    VkInstanceCreateInfo ici = { VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO, .pApplicationInfo = &app };
    CK(vkCreateInstance(&ici, NULL, &inst));

    IFN(vkEnumeratePhysicalDevices); IFN(vkGetPhysicalDeviceProperties); IFN(vkGetPhysicalDeviceMemoryProperties);
    IFN(vkGetPhysicalDeviceQueueFamilyProperties); IFN(vkCreateDevice); IFN(vkGetDeviceProcAddr);
    uint32_t n = 1;
    VkPhysicalDevice pd;
    CK(vkEnumeratePhysicalDevices(inst, &n, &pd));
    VkPhysicalDeviceProperties pp;
    vkGetPhysicalDeviceProperties(pd, &pp);
    vkGetPhysicalDeviceMemoryProperties(pd, &mp);
    printf("device: %s, Vulkan %u.%u.%u, driver 0x%x (%.0f ms)\n", pp.deviceName, VK_API_VERSION_MAJOR(pp.apiVersion),
           VK_API_VERSION_MINOR(pp.apiVersion), VK_API_VERSION_PATCH(pp.apiVersion), pp.driverVersion, (now() - t0) * 1000);

    VkQueueFamilyProperties qf[8];
    uint32_t nq = 8, qfi = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(pd, &nq, qf);
    while (qfi < nq && !(qf[qfi].queueFlags & VK_QUEUE_GRAPHICS_BIT)) qfi++;
    float prio = 1;
    VkDeviceQueueCreateInfo qci = { VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO, .queueFamilyIndex = qfi, .queueCount = 1, .pQueuePriorities = &prio };
    VkDeviceCreateInfo dci = { VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO, .queueCreateInfoCount = 1, .pQueueCreateInfos = &qci };
    CK(vkCreateDevice(pd, &dci, NULL, &dev));

#define DFN(n) PFN_##n n = (PFN_##n)vkGetDeviceProcAddr(dev, #n)
    DFN(vkGetDeviceQueue); DFN(vkCreateImage); DFN(vkGetImageMemoryRequirements); DFN(vkAllocateMemory);
    DFN(vkBindImageMemory); DFN(vkCreateBuffer); DFN(vkGetBufferMemoryRequirements); DFN(vkBindBufferMemory);
    DFN(vkMapMemory); DFN(vkCreateImageView); DFN(vkCreateRenderPass); DFN(vkCreateFramebuffer);
    DFN(vkCreateShaderModule); DFN(vkCreatePipelineLayout); DFN(vkCreateGraphicsPipelines);
    DFN(vkCreateCommandPool); DFN(vkAllocateCommandBuffers); DFN(vkBeginCommandBuffer); DFN(vkEndCommandBuffer);
    DFN(vkCmdBeginRenderPass); DFN(vkCmdEndRenderPass); DFN(vkCmdBindPipeline); DFN(vkCmdDraw);
    DFN(vkCmdPipelineBarrier); DFN(vkCmdBlitImage); DFN(vkCmdCopyImageToBuffer); DFN(vkCreateFence);
    DFN(vkQueueSubmit); DFN(vkWaitForFences); DFN(vkResetFences); DFN(vkDeviceWaitIdle);
    VkQueue q;
    vkGetDeviceQueue(dev, qfi, 0, &q);

    /* images: the 1440x2560 render target, the 720x1280 panel image; a host-visible buffer for the readback */
    VkImage img[2];
    int w[2] = { SW, DW }, hh[2] = { SH, DH };
    VkImageUsageFlags use[2] = { VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT,
                                 VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT };
    for (int i = 0; i < 2; i++) {
        VkImageCreateInfo ii = { VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO, .imageType = VK_IMAGE_TYPE_2D,
            .format = VK_FORMAT_R8G8B8A8_UNORM, .extent = { w[i], hh[i], 1 }, .mipLevels = 1, .arrayLayers = 1,
            .samples = VK_SAMPLE_COUNT_1_BIT, .tiling = VK_IMAGE_TILING_OPTIMAL, .usage = use[i] };
        CK(vkCreateImage(dev, &ii, NULL, &img[i]));
        VkMemoryRequirements mr;
        vkGetImageMemoryRequirements(dev, img[i], &mr);
        VkMemoryAllocateInfo ai = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO, .allocationSize = mr.size,
            .memoryTypeIndex = memtype(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) };
        VkDeviceMemory m;
        CK(vkAllocateMemory(dev, &ai, NULL, &m));
        CK(vkBindImageMemory(dev, img[i], m, 0));
    }
    VkBuffer buf;
    VkBufferCreateInfo bi = { VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO, .size = DW * DH * 4, .usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT };
    CK(vkCreateBuffer(dev, &bi, NULL, &buf));
    VkMemoryRequirements br;
    vkGetBufferMemoryRequirements(dev, buf, &br);
    VkMemoryAllocateInfo bai = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO, .allocationSize = br.size,
        .memoryTypeIndex = memtype(br.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) };
    VkDeviceMemory bm;
    CK(vkAllocateMemory(dev, &bai, NULL, &bm));
    CK(vkBindBufferMemory(dev, buf, bm, 0));
    uint32_t *px;
    CK(vkMapMemory(dev, bm, 0, VK_WHOLE_SIZE, 0, (void **)&px));

    /* the render pass and the triangle pipeline */
    VkImageViewCreateInfo vi = { VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO, .image = img[0], .viewType = VK_IMAGE_VIEW_TYPE_2D,
        .format = VK_FORMAT_R8G8B8A8_UNORM, .subresourceRange = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 } };
    VkImageView view;
    CK(vkCreateImageView(dev, &vi, NULL, &view));
    VkAttachmentDescription ad = { .format = VK_FORMAT_R8G8B8A8_UNORM, .samples = VK_SAMPLE_COUNT_1_BIT,
        .loadOp = VK_ATTACHMENT_LOAD_OP_CLEAR, .storeOp = VK_ATTACHMENT_STORE_OP_STORE,
        .stencilLoadOp = VK_ATTACHMENT_LOAD_OP_DONT_CARE, .stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
        .initialLayout = VK_IMAGE_LAYOUT_UNDEFINED, .finalLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL };
    VkAttachmentReference ar = { 0, VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL };
    VkSubpassDescription sd = { .pipelineBindPoint = VK_PIPELINE_BIND_POINT_GRAPHICS, .colorAttachmentCount = 1, .pColorAttachments = &ar };
    VkSubpassDependency dep = { 0, VK_SUBPASS_EXTERNAL, VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT,
        VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT, 0 };
    VkRenderPassCreateInfo rpi = { VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO, .attachmentCount = 1, .pAttachments = &ad,
        .subpassCount = 1, .pSubpasses = &sd, .dependencyCount = 1, .pDependencies = &dep };
    VkRenderPass rp;
    CK(vkCreateRenderPass(dev, &rpi, NULL, &rp));
    VkFramebufferCreateInfo fi = { VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO, .renderPass = rp, .attachmentCount = 1,
        .pAttachments = &view, .width = SW, .height = SH, .layers = 1 };
    VkFramebuffer fb;
    CK(vkCreateFramebuffer(dev, &fi, NULL, &fb));

    t0 = now();
    VkShaderModule sm[2];
    VkShaderModuleCreateInfo smi = { VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO, .codeSize = sizeof tri_vert, .pCode = tri_vert };
    CK(vkCreateShaderModule(dev, &smi, NULL, &sm[0]));
    smi.codeSize = sizeof tri_frag; smi.pCode = tri_frag;
    CK(vkCreateShaderModule(dev, &smi, NULL, &sm[1]));
    VkPipelineShaderStageCreateInfo st[2] = {
        { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, .stage = VK_SHADER_STAGE_VERTEX_BIT, .module = sm[0], .pName = "main" },
        { VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO, .stage = VK_SHADER_STAGE_FRAGMENT_BIT, .module = sm[1], .pName = "main" } };
    VkPipelineVertexInputStateCreateInfo vin = { VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO };
    VkPipelineInputAssemblyStateCreateInfo ia = { VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO, .topology = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST };
    VkViewport vp = { 0, 0, SW, SH, 0, 1 };
    VkRect2D sc = { { 0, 0 }, { SW, SH } };
    VkPipelineViewportStateCreateInfo vps = { VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO, .viewportCount = 1, .pViewports = &vp, .scissorCount = 1, .pScissors = &sc };
    VkPipelineRasterizationStateCreateInfo rs = { VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO, .polygonMode = VK_POLYGON_MODE_FILL,
        .cullMode = VK_CULL_MODE_NONE, .lineWidth = 1 };
    VkPipelineMultisampleStateCreateInfo ms = { VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO, .rasterizationSamples = VK_SAMPLE_COUNT_1_BIT };
    VkPipelineColorBlendAttachmentState cba = { .colorWriteMask = 0xf };
    VkPipelineColorBlendStateCreateInfo cb = { VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO, .attachmentCount = 1, .pAttachments = &cba };
    VkPipelineLayoutCreateInfo pli = { VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO };
    VkPipelineLayout pl;
    CK(vkCreatePipelineLayout(dev, &pli, NULL, &pl));
    VkGraphicsPipelineCreateInfo gpi = { VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO, .stageCount = 2, .pStages = st,
        .pVertexInputState = &vin, .pInputAssemblyState = &ia, .pViewportState = &vps, .pRasterizationState = &rs,
        .pMultisampleState = &ms, .pColorBlendState = &cb, .layout = pl, .renderPass = rp };
    VkPipeline pipe;
    CK(vkCreateGraphicsPipelines(dev, VK_NULL_HANDLE, 1, &gpi, NULL, &pipe));
    printf("pipeline compiled (%.0f ms)\n", (now() - t0) * 1000);

    /* one frame: draw at 1440x2560, blit down to 720x1280, read back */
    VkCommandPoolCreateInfo cpi = { VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO, .queueFamilyIndex = qfi };
    VkCommandPool pool;
    CK(vkCreateCommandPool(dev, &cpi, NULL, &pool));
    VkCommandBufferAllocateInfo cai = { VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO, .commandPool = pool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY, .commandBufferCount = 1 };
    VkCommandBuffer cmd;
    CK(vkAllocateCommandBuffers(dev, &cai, &cmd));
    VkCommandBufferBeginInfo cbi = { VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
    CK(vkBeginCommandBuffer(cmd, &cbi));
    VkClearValue clr = { .color = { .float32 = { 0, 0, 1, 1 } } };
    VkRenderPassBeginInfo rbi = { VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO, .renderPass = rp, .framebuffer = fb,
        .renderArea = { { 0, 0 }, { SW, SH } }, .clearValueCount = 1, .pClearValues = &clr };
    vkCmdBeginRenderPass(cmd, &rbi, VK_SUBPASS_CONTENTS_INLINE);
    vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_GRAPHICS, pipe);
    vkCmdDraw(cmd, 3, 1, 0, 0);
    vkCmdEndRenderPass(cmd);
    VkImageMemoryBarrier b1 = { VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER, .srcAccessMask = 0, .dstAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT,
        .oldLayout = VK_IMAGE_LAYOUT_UNDEFINED, .newLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
        .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED, .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .image = img[1], .subresourceRange = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 } };
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, NULL, 0, NULL, 1, &b1);
    VkImageBlit blit = { { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, { { 0, 0, 0 }, { SW, SH, 1 } },
                         { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, { { 0, 0, 0 }, { DW, DH, 1 } } };
    vkCmdBlitImage(cmd, img[0], VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, img[1], VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &blit, VK_FILTER_LINEAR);
    VkImageMemoryBarrier b2 = b1;
    b2.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT; b2.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    b2.oldLayout = VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL; b2.newLayout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, NULL, 0, NULL, 1, &b2);
    VkBufferImageCopy bic = { .imageSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, .imageExtent = { DW, DH, 1 } };
    vkCmdCopyImageToBuffer(cmd, img[1], VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, buf, 1, &bic);
    VkBufferMemoryBarrier b3 = { VK_STRUCTURE_TYPE_BUFFER_MEMORY_BARRIER, .srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT,
        .dstAccessMask = VK_ACCESS_HOST_READ_BIT, .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED, .buffer = buf, .size = VK_WHOLE_SIZE };
    vkCmdPipelineBarrier(cmd, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_HOST_BIT, 0, 0, NULL, 1, &b3, 0, NULL);
    CK(vkEndCommandBuffer(cmd));

    VkFenceCreateInfo fci = { VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
    VkFence fence;
    CK(vkCreateFence(dev, &fci, NULL, &fence));
    VkSubmitInfo si = { VK_STRUCTURE_TYPE_SUBMIT_INFO, .commandBufferCount = 1, .pCommandBuffers = &cmd };
    memset(px, 0x55, DW * DH * 4);
    t0 = now();
    CK(vkQueueSubmit(q, 1, &si, fence));
    CK(vkWaitForFences(dev, 1, &fence, VK_TRUE, 5000000000ull));
    printf("first frame: %.2f ms\n", (now() - t0) * 1000);

    uint32_t center = px[(DH / 2) * DW + DW / 2], corner = px[5 * DW + 5];
    printf("pixel center 0x%08x (want ff0000ff, red), corner 0x%08x (want ffff0000, blue)\n", center, corner);
    int ok = center == 0xff0000ff && corner == 0xffff0000;

    double best = 1e9, sum = 0;
    for (int i = 0; i < 100; i++) {
        CK(vkResetFences(dev, 1, &fence));
        t0 = now();
        CK(vkQueueSubmit(q, 1, &si, fence));
        CK(vkWaitForFences(dev, 1, &fence, VK_TRUE, 5000000000ull));
        double d = (now() - t0) * 1000;
        sum += d;
        if (d < best) best = d;
    }
    printf("100 frames (draw 1440x2560 + blit to 720x1280 + readback 3.5 MB): best %.2f ms, mean %.2f ms\n", best, sum / 100);
    vkDeviceWaitIdle(dev);
    printf(ok ? "OK: Vulkan renders on the Adreno 650 in the recovery\n" : "FAIL: wrong pixels\n");
    return !ok;
}
