/*
 * gpu-present: the Windows frame onto the panel with the Adreno 650 (Vulkan, Mesa turnip over kgsl).
 *
 * w10m-phone copies the guest's 720x1280 framebuffer (XRGB8888 in the guest RAM file) into a staging buffer
 * of GPU memory; the GPU then
 *   1. copies it into an image,
 *   2. scales it with a linear filter to the rectangle the picture has on the panel,
 *   3. writes the result straight into the DRM dumb buffer that is flipped next (imported as a dma-buf).
 * The key bar and the keyboard stay CPU-drawn in the same dumb buffers (outside the rectangle).
 * The ICD is opened with dlopen (no Vulkan loader on the phone); any failure leaves the CPU path in place.
 */
#include <dlfcn.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <drm/drm.h>
#define VK_NO_PROTOTYPES
#include <vulkan/vulkan.h>

#include "gpu-present.h"

extern void say(const char *fmt, ...);

static PFN_vkGetInstanceProcAddr gipa;
static VkInstance inst;
static VkPhysicalDevice pd;
static VkDevice dev;
static VkQueue q;
static VkPhysicalDeviceMemoryProperties mp;
static VkCommandPool pool;
static VkCommandBuffer cmd[2];
static VkFence fence;
static VkBuffer stage, dumb[2];
static VkDeviceMemory stage_mem, dumb_mem[2], src_mem, mid_mem;
static VkImage src, mid;
static int gw, gh, P, PH, rx, ry, rw, rh;
static void *stage_map;

#define F(n) static PFN_##n n
F(vkDestroyImage); F(vkFreeMemory); F(vkCreateImage); F(vkGetImageMemoryRequirements); F(vkAllocateMemory);
F(vkBindImageMemory); F(vkCreateBuffer); F(vkGetBufferMemoryRequirements); F(vkBindBufferMemory); F(vkMapMemory);
F(vkBeginCommandBuffer); F(vkEndCommandBuffer); F(vkResetCommandBuffer); F(vkCmdPipelineBarrier);
F(vkCmdBlitImage); F(vkCmdCopyBufferToImage); F(vkCmdCopyImageToBuffer); F(vkQueueSubmit);
F(vkWaitForFences); F(vkResetFences); F(vkDeviceWaitIdle); F(vkGetMemoryFdPropertiesKHR);
#undef F

#define CK(x) do { VkResult r_ = (x); if (r_ != VK_SUCCESS) { say("GPU: %s failed (%d)", #x, r_); return -1; } } while (0)

static int memtype(uint32_t bits, VkMemoryPropertyFlags want, VkMemoryPropertyFlags nice)
{
    for (int pass = 0; pass < 2; pass++)
        for (uint32_t i = 0; i < mp.memoryTypeCount; i++) {
            VkMemoryPropertyFlags f = mp.memoryTypes[i].propertyFlags;
            if ((bits & (1u << i)) && (f & want) == want && (pass || (f & nice) == nice))
                return (int)i;
        }
    return -1;
}

static int image(VkImage *img, VkDeviceMemory *mem, int w, int h)
{
    VkImageCreateInfo ii = { VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO, .imageType = VK_IMAGE_TYPE_2D,
        .format = VK_FORMAT_B8G8R8A8_UNORM, .extent = { w, h, 1 }, .mipLevels = 1, .arrayLayers = 1,
        .samples = VK_SAMPLE_COUNT_1_BIT, .tiling = VK_IMAGE_TILING_OPTIMAL,
        .usage = VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT };
    CK(vkCreateImage(dev, &ii, NULL, img));
    VkMemoryRequirements mr;
    vkGetImageMemoryRequirements(dev, *img, &mr);
    VkMemoryAllocateInfo ai = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO, .allocationSize = mr.size,
        .memoryTypeIndex = memtype(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, 0) };
    CK(vkAllocateMemory(dev, &ai, NULL, mem));
    CK(vkBindImageMemory(dev, *img, *mem, 0));
    return 0;
}

static void barrier(VkCommandBuffer c, VkImage img, VkImageLayout from, VkImageLayout to, VkAccessFlags sa, VkAccessFlags da)
{
    VkImageMemoryBarrier b = { VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER, .srcAccessMask = sa, .dstAccessMask = da,
        .oldLayout = from, .newLayout = to, .srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED,
        .dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED, .image = img,
        .subresourceRange = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 } };
    vkCmdPipelineBarrier(c, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 0, NULL, 0, NULL, 1, &b);
}

/* the two command buffers (one per dumb buffer) for the current rectangle */
static int record(void)
{
    for (int b = 0; b < 2; b++) {
        VkCommandBuffer c = cmd[b];
        CK(vkResetCommandBuffer(c, 0));
        VkCommandBufferBeginInfo bi = { VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
        CK(vkBeginCommandBuffer(c, &bi));
        barrier(c, src, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT);
        VkBufferImageCopy in = { .imageSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, .imageExtent = { gw, gh, 1 } };
        vkCmdCopyBufferToImage(c, stage, src, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &in);
        barrier(c, src, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT);
        barrier(c, mid, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT);
        VkImageBlit bl = { { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, { { 0, 0, 0 }, { gw, gh, 1 } },
                           { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, { { 0, 0, 0 }, { rw, rh, 1 } } };
        vkCmdBlitImage(c, src, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, mid, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &bl,
                       VK_FILTER_LINEAR);
        barrier(c, mid, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT);
        VkBufferImageCopy out = { .bufferOffset = (VkDeviceSize)ry * P + (VkDeviceSize)rx * 4, .bufferRowLength = P / 4,
            .imageSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 }, .imageExtent = { rw, rh, 1 } };
        vkCmdCopyImageToBuffer(c, mid, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, dumb[b], 1, &out);
        CK(vkEndCommandBuffer(c));
    }
    return 0;
}

int gp_init(const char *icd, int drm_fd, const uint32_t handle[2], int pitch, int panel_h, int w, int h)
{
    void *lib = dlopen(icd, RTLD_NOW | RTLD_LOCAL);
    if (!lib) { say("GPU: no Vulkan driver (%s)", dlerror()); return -1; }
    VkResult (*neg)(uint32_t *) = (VkResult (*)(uint32_t *))dlsym(lib, "vk_icdNegotiateLoaderICDInterfaceVersion");
    gipa = (PFN_vkGetInstanceProcAddr)dlsym(lib, "vk_icdGetInstanceProcAddr");
    if (!gipa) { say("GPU: %s is not a Vulkan driver", icd); return -1; }
    uint32_t ver = 5;
    if (neg) neg(&ver);
    gw = w, gh = h, P = pitch, PH = panel_h;

    PFN_vkCreateInstance vkCreateInstance = (PFN_vkCreateInstance)gipa(NULL, "vkCreateInstance");
    VkApplicationInfo app = { VK_STRUCTURE_TYPE_APPLICATION_INFO, .pApplicationName = "w10m-phone", .apiVersion = VK_API_VERSION_1_1 };
    VkInstanceCreateInfo ici = { VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO, .pApplicationInfo = &app };
    CK(vkCreateInstance(&ici, NULL, &inst));
#define I(n) PFN_##n n = (PFN_##n)gipa(inst, #n)
    I(vkEnumeratePhysicalDevices); I(vkGetPhysicalDeviceProperties); I(vkGetPhysicalDeviceMemoryProperties);
    I(vkGetPhysicalDeviceQueueFamilyProperties); I(vkCreateDevice); I(vkGetDeviceProcAddr);
#undef I
    uint32_t n = 1;
    CK(vkEnumeratePhysicalDevices(inst, &n, &pd));
    VkPhysicalDeviceProperties pp;
    vkGetPhysicalDeviceProperties(pd, &pp);
    vkGetPhysicalDeviceMemoryProperties(pd, &mp);
    VkQueueFamilyProperties qf[8];
    uint32_t nq = 8, qfi = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(pd, &nq, qf);
    while (qfi < nq && !(qf[qfi].queueFlags & VK_QUEUE_GRAPHICS_BIT)) qfi++;
    float prio = 1;
    const char *ext[] = { "VK_KHR_external_memory_fd", "VK_EXT_external_memory_dma_buf" };
    VkDeviceQueueCreateInfo qci = { VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO, .queueFamilyIndex = qfi, .queueCount = 1, .pQueuePriorities = &prio };
    VkDeviceCreateInfo dci = { VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO, .queueCreateInfoCount = 1, .pQueueCreateInfos = &qci,
        .enabledExtensionCount = 2, .ppEnabledExtensionNames = ext };
    CK(vkCreateDevice(pd, &dci, NULL, &dev));
#define D(n) n = (PFN_##n)vkGetDeviceProcAddr(dev, #n)
    D(vkDestroyImage); D(vkFreeMemory); D(vkCreateImage); D(vkGetImageMemoryRequirements); D(vkAllocateMemory);
    D(vkBindImageMemory); D(vkCreateBuffer); D(vkGetBufferMemoryRequirements); D(vkBindBufferMemory); D(vkMapMemory);
    D(vkBeginCommandBuffer); D(vkEndCommandBuffer); D(vkResetCommandBuffer); D(vkCmdPipelineBarrier);
    D(vkCmdBlitImage); D(vkCmdCopyBufferToImage); D(vkCmdCopyImageToBuffer); D(vkQueueSubmit);
    D(vkWaitForFences); D(vkResetFences); D(vkDeviceWaitIdle); D(vkGetMemoryFdPropertiesKHR);
    PFN_vkGetDeviceQueue vkGetDeviceQueue; D(vkGetDeviceQueue);
    PFN_vkCreateCommandPool vkCreateCommandPool; D(vkCreateCommandPool);
    PFN_vkAllocateCommandBuffers vkAllocateCommandBuffers; D(vkAllocateCommandBuffers);
    PFN_vkCreateFence vkCreateFence; D(vkCreateFence);
#undef D
    vkGetDeviceQueue(dev, qfi, 0, &q);

    /* the staging buffer the frame is copied into (cached host memory when there is any: CPU writes stream) */
    VkBufferCreateInfo bi = { VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO, .size = (VkDeviceSize)w * h * 4,
        .usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT };
    CK(vkCreateBuffer(dev, &bi, NULL, &stage));
    VkMemoryRequirements mr;
    vkGetBufferMemoryRequirements(dev, stage, &mr);
    int t = memtype(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                    VK_MEMORY_PROPERTY_HOST_CACHED_BIT);
    if (t < 0) { say("GPU: no host-visible memory"); return -1; }
    VkMemoryAllocateInfo ai = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO, .allocationSize = mr.size, .memoryTypeIndex = t };
    CK(vkAllocateMemory(dev, &ai, NULL, &stage_mem));
    CK(vkBindBufferMemory(dev, stage, stage_mem, 0));
    CK(vkMapMemory(dev, stage_mem, 0, VK_WHOLE_SIZE, 0, &stage_map));

    /* the panel's dumb buffers, as dma-bufs */
    for (int b = 0; b < 2; b++) {
        struct drm_prime_handle ph = { .handle = handle[b], .flags = DRM_CLOEXEC | DRM_RDWR };
        if (ioctl(drm_fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph)) {
            ph.flags = DRM_CLOEXEC;
            if (ioctl(drm_fd, DRM_IOCTL_PRIME_HANDLE_TO_FD, &ph)) { say("GPU: exporting dumb buffer %d failed", b); return -1; }
        }
        VkExternalMemoryBufferCreateInfo eb = { VK_STRUCTURE_TYPE_EXTERNAL_MEMORY_BUFFER_CREATE_INFO,
            .handleTypes = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT };
        VkBufferCreateInfo di = { VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO, .pNext = &eb, .size = (VkDeviceSize)pitch * panel_h,
            .usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT };
        CK(vkCreateBuffer(dev, &di, NULL, &dumb[b]));
        VkMemoryFdPropertiesKHR fp = { VK_STRUCTURE_TYPE_MEMORY_FD_PROPERTIES_KHR };
        CK(vkGetMemoryFdPropertiesKHR(dev, VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT, ph.fd, &fp));
        vkGetBufferMemoryRequirements(dev, dumb[b], &mr);
        int dt = memtype(mr.memoryTypeBits & (fp.memoryTypeBits ? fp.memoryTypeBits : ~0u), 0, 0);
        VkImportMemoryFdInfoKHR imp = { VK_STRUCTURE_TYPE_IMPORT_MEMORY_FD_INFO_KHR,
            .handleType = VK_EXTERNAL_MEMORY_HANDLE_TYPE_DMA_BUF_BIT_EXT, .fd = ph.fd };
        VkMemoryAllocateInfo da = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO, .pNext = &imp, .allocationSize = mr.size,
            .memoryTypeIndex = dt };
        VkResult r = vkAllocateMemory(dev, &da, NULL, &dumb_mem[b]);
        if (r != VK_SUCCESS) { close(ph.fd); say("GPU: importing dumb buffer %d failed (%d)", b, r); return -1; }
        CK(vkBindBufferMemory(dev, dumb[b], dumb_mem[b], 0));
    }

    if (image(&src, &src_mem, w, h))
        return -1;
    VkCommandPoolCreateInfo cpi = { VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
        .flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT, .queueFamilyIndex = qfi };
    CK(vkCreateCommandPool(dev, &cpi, NULL, &pool));
    VkCommandBufferAllocateInfo cai = { VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO, .commandPool = pool,
        .level = VK_COMMAND_BUFFER_LEVEL_PRIMARY, .commandBufferCount = 2 };
    CK(vkAllocateCommandBuffers(dev, &cai, cmd));
    VkFenceCreateInfo fci = { VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
    CK(vkCreateFence(dev, &fci, NULL, &fence));
    say("GPU: %s, frames %dx%d scaled on the GPU into the panel's buffers", pp.deviceName, w, h);
    return 0;
}

void *gp_staging(void)
{
    return stage_map;
}

int gp_layout(int x, int y, int w, int h)
{
    if (x < 0 || y < 0 || w <= 0 || h <= 0 || (long)(x + w) * 4 > P || y + h > PH)
        return -1;
    vkDeviceWaitIdle(dev);
    if (mid) {
        vkDestroyImage(dev, mid, NULL);
        vkFreeMemory(dev, mid_mem, NULL);
        mid = VK_NULL_HANDLE;
    }
    rx = x, ry = y, rw = w, rh = h;
    if (image(&mid, &mid_mem, w, h))
        return -1;
    return record();
}

int gp_present(int b)
{
    VkSubmitInfo si = { VK_STRUCTURE_TYPE_SUBMIT_INFO, .commandBufferCount = 1, .pCommandBuffers = &cmd[b] };
    CK(vkResetFences(dev, 1, &fence));
    CK(vkQueueSubmit(q, 1, &si, fence));
    CK(vkWaitForFences(dev, 1, &fence, VK_TRUE, 1000000000ull));
    return 0;
}
