/*
 * w10m-phone: the phone side of the W10M LiveBoot (runs as root under the TWRP kernel, next to QEMU).
 *  - screen: QMP screendump of the emulated phone, scaled onto the Poco F3 panel (DRM dumb buffers,
 *    or fbdev when there is no DRM), with the three W10M navigation keys drawn under it
 *  - touch: the panel's touch screen (fts_ts) -> absolute pointer of usb-touchscreen; taps on the
 *    drawn keys -> Back / Start / Search of usb-phone-buttons
 *  - keys: power, volume up/down -> usb-phone-buttons (when the emulated screen is dark, power goes
 *    through a hot-plugged USB keyboard, as tools/phone.py does: the buttons device cannot wake it)
 * Usage: w10m-phone <qmp unix socket> [work dir for the frames, default /tmp]
 *                   [<guest RAM file> <framebuffer hex> <width>x<height> [<frame fifo>]]
 *                   [<guest RAM file> <framebuffer guest-physical address, hex> <width>x<height>]
 *   with the RAM file (QEMU memory-backend-file, guest RAM from 0x40000000) the frames are read from it
 * Build: aarch64-linux-gnu-gcc -O2 -static -o w10m-phone w10m-phone.c
 */
#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <poll.h>
#include <sched.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <unistd.h>
#include <drm/drm.h>
#include <drm/drm_mode.h>
#include "font.h"

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

static void say(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fprintf(stderr, "w10m-phone: ");
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
}

static double now(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

/* ---- QMP ---------------------------------------------------------------------------------- */
static int qmp_fd = -1, qmp_id;

static int qmp_wait(int id)
{
    /* read until the reply that carries this id (events and other replies are skipped) */
    static char buf[65536];
    static size_t have;
    char tag[32];
    double end = now() + 10;
    snprintf(tag, sizeof tag, "\"id\": %d}", id);
    for (;;) {
        char *nl;
        while ((nl = memchr(buf, '\n', have))) {
            int hit = id < 0 ? strstr(buf, "\"QMP\"") != NULL : (*nl = 0, strstr(buf, tag) != NULL);
            size_t n = nl + 1 - buf;
            memmove(buf, nl + 1, have - n);
            have -= n;
            if (hit)
                return 0;
        }
        if (have == sizeof buf - 1)
            have = 0;
        struct pollfd p = { qmp_fd, POLLIN, 0 };
        int left = (int)((end - now()) * 1000);
        if (left <= 0 || poll(&p, 1, left) <= 0)
            return -1;
        ssize_t r = read(qmp_fd, buf + have, sizeof buf - 1 - have);
        if (r <= 0)
            return -1;
        have += r;
        buf[have] = 0;
    }
}

static int qmp(int wait, const char *fmt, ...)
{
    char cmd[2048], out[2200];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cmd, sizeof cmd, fmt, ap);
    va_end(ap);
    int id = ++qmp_id;
    /* cmd is {"execute": ..., ...} without the closing brace */
    int n = snprintf(out, sizeof out, "%s, \"id\": %d}\n", cmd, id);
    if (write(qmp_fd, out, n) != n)
        return -1;
    return wait ? qmp_wait(id) : 0;
}

static int qmp_open(const char *path)
{
    for (int i = 0; i < 600; i++) {
        int fd = socket(AF_UNIX, SOCK_STREAM, 0);
        struct sockaddr_un a = { .sun_family = AF_UNIX };
        snprintf(a.sun_path, sizeof a.sun_path, "%s", path);
        if (connect(fd, (struct sockaddr *)&a, sizeof a) == 0) {
            qmp_fd = fd;
            if (qmp_wait(-1) == 0 && qmp(1, "{\"execute\": \"qmp_capabilities\"") == 0)
                return 0;
            close(fd);
        } else {
            close(fd);
        }
        usleep(500000);
    }
    return -1;
}

static void key_event(const char *qcode, int down)
{
    qmp(0, "{\"execute\": \"input-send-event\", \"arguments\": {\"events\": [{\"type\": \"key\", \"data\": "
           "{\"down\": %s, \"key\": {\"type\": \"qcode\", \"data\": \"%s\"}}}]}", down ? "true" : "false", qcode);
}

static void pointer(int x, int y, int button)
{
    /* x, y in 0..32767; button: -1 none, 0 up, 1 down */
    char btn[160] = "";
    if (button >= 0)
        snprintf(btn, sizeof btn, ", {\"type\": \"btn\", \"data\": {\"down\": %s, \"button\": \"left\"}}",
                 button ? "true" : "false");
    qmp(0, "{\"execute\": \"input-send-event\", \"arguments\": {\"events\": ["
           "{\"type\": \"abs\", \"data\": {\"axis\": \"x\", \"value\": %d}}, "
           "{\"type\": \"abs\", \"data\": {\"axis\": \"y\", \"value\": %d}}%s]}", x, y, btn);
}

/* ---- the panel ------------------------------------------------------------------------------ */
static int W, H, pitch;           /* panel size, bytes per line */
static uint32_t *fb[2];           /* XRGB8888 */
static int cur;                   /* buffer being shown */
static int drm_fd = -1, fb_fd = -1;
static uint32_t drm_fb[2], drm_crtc, drm_conn;
static struct drm_mode_modeinfo drm_mode;
static int flip_ok = 1;
static struct fb_var_screeninfo vinfo;

static int drm_open(void)
{
    int fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);
    if (fd < 0)
        return -1;
    ioctl(fd, DRM_IOCTL_SET_MASTER, 0);
    struct drm_mode_card_res res = { 0 };
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res) || !res.count_connectors || !res.count_crtcs)
        goto fail;
    uint32_t conns[16], crtcs[16], encs[16];
    res.count_connectors = res.count_connectors > 16 ? 16 : res.count_connectors;
    res.count_crtcs = res.count_crtcs > 16 ? 16 : res.count_crtcs;
    res.count_encoders = res.count_encoders > 16 ? 16 : res.count_encoders;
    res.count_fbs = 0;
    res.connector_id_ptr = (uintptr_t)conns;
    res.crtc_id_ptr = (uintptr_t)crtcs;
    res.encoder_id_ptr = (uintptr_t)encs;
    if (ioctl(fd, DRM_IOCTL_MODE_GETRESOURCES, &res))
        goto fail;
    for (unsigned i = 0; i < res.count_connectors; i++) {
        struct drm_mode_get_connector c = { .connector_id = conns[i] };
        struct drm_mode_modeinfo modes[32];
        uint32_t cencs[8];
        if (ioctl(fd, DRM_IOCTL_MODE_GETCONNECTOR, &c) || c.connection != 1 || !c.count_modes)
            continue;
        c.count_modes = c.count_modes > 32 ? 32 : c.count_modes;
        c.count_encoders = c.count_encoders > 8 ? 8 : c.count_encoders;
        c.count_props = 0;
        c.modes_ptr = (uintptr_t)modes;
        c.encoders_ptr = (uintptr_t)cencs;
        if (ioctl(fd, DRM_IOCTL_MODE_GETCONNECTOR, &c))
            continue;
        drm_mode = modes[0];
        drm_conn = c.connector_id;
        uint32_t enc = c.encoder_id ? c.encoder_id : (c.count_encoders ? cencs[0] : 0);
        struct drm_mode_get_encoder e = { .encoder_id = enc };
        if (enc && !ioctl(fd, DRM_IOCTL_MODE_GETENCODER, &e) && e.crtc_id) {
            drm_crtc = e.crtc_id;
        } else {
            for (unsigned k = 0; k < res.count_crtcs; k++)
                if (e.possible_crtcs & (1u << k)) {
                    drm_crtc = crtcs[k];
                    break;
                }
        }
        break;
    }
    if (!drm_conn || !drm_crtc)
        goto fail;
    W = drm_mode.hdisplay;
    H = drm_mode.vdisplay;
    for (int b = 0; b < 2; b++) {
        struct drm_mode_create_dumb cd = { .width = W, .height = H, .bpp = 32 };
        if (ioctl(fd, DRM_IOCTL_MODE_CREATE_DUMB, &cd))
            goto fail;
        pitch = cd.pitch;
        struct drm_mode_fb_cmd f = { .width = W, .height = H, .pitch = cd.pitch, .bpp = 32, .depth = 24,
                                     .handle = cd.handle };
        if (ioctl(fd, DRM_IOCTL_MODE_ADDFB, &f))
            goto fail;
        drm_fb[b] = f.fb_id;
        struct drm_mode_map_dumb md = { .handle = cd.handle };
        if (ioctl(fd, DRM_IOCTL_MODE_MAP_DUMB, &md))
            goto fail;
        fb[b] = mmap(0, cd.size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, md.offset);
        if (fb[b] == MAP_FAILED)
            goto fail;
        memset(fb[b], 0, cd.size);
    }
    struct drm_mode_crtc sc = { .crtc_id = drm_crtc, .fb_id = drm_fb[0], .set_connectors_ptr = (uintptr_t)&drm_conn,
                                .count_connectors = 1, .mode = drm_mode, .mode_valid = 1 };
    if (ioctl(fd, DRM_IOCTL_MODE_SETCRTC, &sc)) {
        say("DRM: setting the mode failed (%s): is TWRP's screen still running?", strerror(errno));
        goto fail;
    }
    drm_fd = fd;
    say("DRM: %dx%d %s, connector %u, crtc %u", W, H, drm_mode.name, drm_conn, drm_crtc);
    return 0;
fail:
    close(fd);
    return -1;
}

static int fbdev_open(void)
{
    const char *names[] = { "/dev/graphics/fb0", "/dev/fb0" };
    for (int i = 0; i < 2; i++) {
        int fd = open(names[i], O_RDWR | O_CLOEXEC);
        struct fb_fix_screeninfo fix;
        if (fd < 0)
            continue;
        if (ioctl(fd, FBIOGET_VSCREENINFO, &vinfo) || ioctl(fd, FBIOGET_FSCREENINFO, &fix) ||
            vinfo.bits_per_pixel != 32) {
            close(fd);
            continue;
        }
        W = vinfo.xres;
        H = vinfo.yres;
        pitch = fix.line_length;
        uint8_t *m = mmap(0, fix.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
        if (m == MAP_FAILED) {
            close(fd);
            continue;
        }
        fb[0] = (uint32_t *)m;
        fb[1] = vinfo.yres_virtual >= 2 * vinfo.yres ? (uint32_t *)(m + (size_t)pitch * H) : fb[0];
        fb_fd = fd;
        say("fbdev %s: %dx%d, red at bit %d, %s", names[i], W, H, vinfo.red.offset,
            fb[1] != fb[0] ? "two pages" : "one page");
        return 0;
    }
    return -1;
}

static uint32_t rgb(int r, int g, int b)
{
    if (fb_fd >= 0 && vinfo.red.offset == 0)
        return (uint32_t)b << 16 | (uint32_t)g << 8 | (uint32_t)r;
    return (uint32_t)r << 16 | (uint32_t)g << 8 | (uint32_t)b;
}

static void show(int b)
{
    if (drm_fd >= 0) {
        if (flip_ok) {
            struct drm_mode_crtc_page_flip pf = { .crtc_id = drm_crtc, .fb_id = drm_fb[b],
                                                  .flags = DRM_MODE_PAGE_FLIP_EVENT };
            if (ioctl(drm_fd, DRM_IOCTL_MODE_PAGE_FLIP, &pf) == 0) {
                struct pollfd p = { drm_fd, POLLIN, 0 };
                char ev[1024];
                if (poll(&p, 1, 200) > 0 && read(drm_fd, ev, sizeof ev) < 0)
                    say("DRM: no flip event (%s)", strerror(errno));
                cur = b;
                return;
            }
            say("DRM: page flip failed (%s): setting the crtc each frame instead", strerror(errno));
            flip_ok = 0;
        }
        struct drm_mode_crtc sc = { .crtc_id = drm_crtc, .fb_id = drm_fb[b], .set_connectors_ptr = (uintptr_t)&drm_conn,
                                    .count_connectors = 1, .mode = drm_mode, .mode_valid = 1 };
        ioctl(drm_fd, DRM_IOCTL_MODE_SETCRTC, &sc);
        struct drm_mode_fb_dirty_cmd d = { .fb_id = drm_fb[b] };
        ioctl(drm_fd, DRM_IOCTL_MODE_DIRTYFB, &d);
    } else if (fb[1] != fb[0]) {
        vinfo.yoffset = b ? H : 0;
        ioctl(fb_fd, FBIOPAN_DISPLAY, &vinfo);
    } else {
        ioctl(fb_fd, FBIOPAN_DISPLAY, &vinfo);
    }
    cur = b;
}

/* ---- layout: the emulated screen at the top, the navigation keys under it -------------------- */
static int gw, gh;                 /* emulated screen */
static int ix, iy, iw, ih;         /* its rectangle on the panel */
static int navy, navh;             /* the key bar */
static int kby, kbh;               /* the on-screen keyboard (kbh 0: closed) */
static int kbby, kbbh;             /* the keyboard button under the key bar */
static int kb_open;
static int *xmap, *ymap;

static void fill(uint32_t *p, int x0, int y0, int w, int h, uint32_t c)
{
    for (int y = y0; y < y0 + h; y++)
        if (y >= 0 && y < H)
            for (int x = x0; x < x0 + w; x++)
                if (x >= 0 && x < W)
                    p[(size_t)y * (pitch / 4) + x] = c;
}

static void ring(uint32_t *p, int cx, int cy, int r, int t, uint32_t c)
{
    for (int y = -r; y <= r; y++)
        for (int x = -r; x <= r; x++) {
            int d = x * x + y * y;
            if (d <= r * r && d >= (r - t) * (r - t))
                fill(p, cx + x, cy + y, 1, 1, c);
        }
}

static void line(uint32_t *p, int x0, int y0, int x1, int y1, int t, uint32_t c)
{
    int n = abs(x1 - x0) > abs(y1 - y0) ? abs(x1 - x0) : abs(y1 - y0);
    for (int i = 0; i <= n; i++) {
        int x = x0 + (x1 - x0) * i / (n ? n : 1), y = y0 + (y1 - y0) * i / (n ? n : 1);
        fill(p, x - t / 2, y - t / 2, t, t, c);
    }
}

static void disc(uint32_t *p, int cx, int cy, int r, uint32_t c)
{
    for (int y = -r; y <= r; y++) {
        int w = 0;
        while ((w + 1) * (w + 1) + y * y <= r * r)
            w++;
        fill(p, cx - w, cy + y, 2 * w + 1, 1, c);
    }
}

static int pressed_key = -1;       /* 0 back, 1 start, 2 search, 3 keyboard button: drawn highlighted */
static int pressed_kb = -1;        /* the keyboard key under the finger */
static int kb_shift;

static uint32_t blend(uint32_t bg, uint32_t fg, int a)
{
    uint32_t r = 0;
    for (int sh = 0; sh <= 16; sh += 8) {
        int b = (bg >> sh) & 255, f = (fg >> sh) & 255;
        r |= (uint32_t)(b + (f - b) * a / 255) << sh;
    }
    return r;
}

static int text_w(const char *t)
{
    int w = 0;
    for (; *t; t++)
        w += (*t >= 32 && *t < 127) ? font_w[*t - 32] : 0;
    return w;
}

/* t centered on (cx, cy) */
static void text(uint32_t *p, int cx, int cy, const char *t, uint32_t fg, uint32_t bg)
{
    int x = cx - text_w(t) / 2, y0 = cy - FONT_H / 2;
    for (; *t; t++) {
        if (*t < 32 || *t >= 127)
            continue;
        int g = *t - 32, w = font_w[g];
        const unsigned char *px = font_px + font_off[g];
        for (int y = 0; y < FONT_H; y++)
            for (int i = 0; i < w; i++)
                if (px[y * w + i] && x + i >= 0 && x + i < W && y0 + y >= 0 && y0 + y < H)
                    p[(size_t)(y0 + y) * (pitch / 4) + x + i] = blend(bg, fg, px[y * w + i]);
        x += w;
    }
}

/* the keyboard: rows of keys; a key is {label, qcode, width in tenths of a row} */
typedef struct Key { const char *label, *code; int w; } Key;
static const Key kb_rows[5][11] = {
    { {"1","1",10},{"2","2",10},{"3","3",10},{"4","4",10},{"5","5",10},{"6","6",10},{"7","7",10},{"8","8",10},{"9","9",10},{"0","0",10} },
    { {"q","q",10},{"w","w",10},{"e","e",10},{"r","r",10},{"t","t",10},{"y","y",10},{"u","u",10},{"i","i",10},{"o","o",10},{"p","p",10} },
    { {"a","a",10},{"s","s",10},{"d","d",10},{"f","f",10},{"g","g",10},{"h","h",10},{"j","j",10},{"k","k",10},{"l","l",10} },
    { {"^","shift",15},{"z","z",10},{"x","x",10},{"c","c",10},{"v","v",10},{"b","b",10},{"n","n",10},{"m","m",10},{"<x","backspace",15} },
    { {"?123","sym",15},{"/","slash",10},{",","comma",10},{" ","spc",35},{".","dot",10},{"OK","ret",20} },
};
/* the symbols page ("?123"); a code starting with '+' is typed with shift */
static const Key kb_sym_rows[5][11] = {
    { {"1","1",10},{"2","2",10},{"3","3",10},{"4","4",10},{"5","5",10},{"6","6",10},{"7","7",10},{"8","8",10},{"9","9",10},{"0","0",10} },
    { {"@","+2",10},{"#","+3",10},{"$","+4",10},{"%","+5",10},{"&","+7",10},{"*","+8",10},{"(","+9",10},{")","+0",10},{"-","minus",10},{"+","+equal",10} },
    { {"!","+1",10},{"\"","+apostrophe",10},{"'","apostrophe",10},{":","+semicolon",10},{";","semicolon",10},{"/","slash",10},{"?","+slash",10},{"=","equal",10},{"_","+minus",10} },
    { {"<","+comma",10},{">","+dot",10},{"[","bracket_left",10},{"]","bracket_right",10},{"\\","backslash",10},{"|","+backslash",10},{"~","+grave_accent",10},{"<x","backspace",15} },
    { {"abc","sym",15},{"/","slash",10},{",","comma",10},{" ","spc",35},{".","dot",10},{"OK","ret",20} },
};
static int kb_sym;
#define KB_ROWS (kb_sym ? kb_sym_rows : kb_rows)

static int kb_key_at(int px, int py, int *rx0, int *ry0, int *rw, int *rh)
{
    int rowh = kbh / 5;
    int r = (py - kby) / rowh;
    if (r < 0 || r > 4)
        return -1;
    int total = 0;
    for (int k = 0; k < 11 && KB_ROWS[r][k].label; k++)
        total += KB_ROWS[r][k].w;
    int x = (W - total * W / 100) / 2;
    for (int k = 0; k < 11 && KB_ROWS[r][k].label; k++) {
        int w = KB_ROWS[r][k].w * W / 100;
        if (px >= x && px < x + w) {
            if (rx0) {
                *rx0 = x, *ry0 = kby + r * rowh, *rw = w, *rh = rowh;
            }
            return r * 16 + k;
        }
        x += w;
    }
    return -1;
}

static void draw_keyboard(uint32_t *p)
{
    uint32_t bg = rgb(0, 0, 0), key = rgb(38, 38, 38), hl = rgb(90, 90, 90), fg = rgb(240, 240, 240);
    fill(p, 0, kby, W, kbh, bg);
    int rowh = kbh / 5;
    for (int r = 0; r < 5; r++) {
        int total = 0;
        for (int k = 0; k < 11 && KB_ROWS[r][k].label; k++)
            total += KB_ROWS[r][k].w;
        int x = (W - total * W / 100) / 2;
        for (int k = 0; k < 11 && KB_ROWS[r][k].label; k++) {
            const Key *q = &KB_ROWS[r][k];
            int w = q->w * W / 100, y = kby + r * rowh;
            uint32_t c = (r * 16 + k == pressed_kb || (kb_shift && !strcmp(q->code, "shift"))) ? hl : key;
            fill(p, x + 4, y + 4, w - 8, rowh - 8, c);
            char lab[8];
            snprintf(lab, sizeof lab, "%s", q->label);
            if (kb_shift && lab[0] >= 'a' && lab[0] <= 'z' && !lab[1])
                lab[0] -= 32;
            text(p, x + w / 2, y + rowh / 2, lab, fg, c);
            x += w;
        }
    }
}

static void draw_bar(uint32_t *p, int clear)
{
    uint32_t bar = rgb(0, 0, 0), fg = rgb(235, 235, 235), hl = rgb(48, 48, 48);   /* black: OLED */
    if (clear)
        fill(p, 0, 0, W, H, rgb(0, 0, 0));
    fill(p, 0, navy, W, navh, bar);
    fill(p, 0, kbby, W, kbbh, bar);
    int cy = navy + navh / 2, u = navh * 2 / 9, t = navh / 30 + 2;
    for (int k = 0; k < 3; k++)
        if (k == pressed_key)
            disc(p, (2 * k + 1) * W / 6, cy, navh * 2 / 5, hl);
    /* back: an arrow */
    int bx = W / 6;
    line(p, bx - u, cy, bx + u, cy, t, fg);
    line(p, bx - u, cy, bx - u / 3, cy - 2 * u / 3, t, fg);
    line(p, bx - u, cy, bx - u / 3, cy + 2 * u / 3, t, fg);
    /* start: the four panes */
    int sx = W / 2, g = t, s2 = u - g / 2;
    fill(p, sx - s2 - g / 2, cy - s2 - g / 2, s2, s2, fg);
    fill(p, sx + g / 2, cy - s2 - g / 2, s2, s2, fg);
    fill(p, sx - s2 - g / 2, cy + g / 2, s2, s2, fg);
    fill(p, sx + g / 2, cy + g / 2, s2, s2, fg);
    /* search: a magnifier */
    int mx = 5 * W / 6 - u / 4, my = cy - u / 4, r = u * 2 / 3;
    ring(p, mx, my, r, t, fg);
    line(p, mx + r * 7 / 10, my + r * 7 / 10, mx + r * 7 / 10 + u / 2, my + r * 7 / 10 + u / 2, t + 1, fg);
    /* the keyboard button: a keyboard outline (filled while the keyboard is open) */
    int kx = W / 2, ky = kbby + kbbh / 2, kw = kbbh * 7 / 10, kh = kbbh * 4 / 10;
    if (pressed_key == 3)
        disc(p, kx, ky, kbbh * 2 / 5, hl);
    uint32_t kc = kb_open ? rgb(120, 170, 255) : fg;
    fill(p, kx - kw / 2, ky - kh / 2, kw, t, kc);
    fill(p, kx - kw / 2, ky + kh / 2 - t, kw, t, kc);
    fill(p, kx - kw / 2, ky - kh / 2, t, kh, kc);
    fill(p, kx + kw / 2 - t, ky - kh / 2, t, kh, kc);
    for (int i = 0; i < 4; i++)
        fill(p, kx - kw / 2 + kw * (2 * i + 1) / 9, ky - kh / 5, kw / 10, kh / 6, kc);
    fill(p, kx - kw / 4, ky + kh / 8, kw / 2, kh / 6, kc);
    if (kb_open)
        draw_keyboard(p);
}

static void redraw_bar(void)
{
    draw_bar(fb[0], 0);
    if (fb[1] != fb[0])
        draw_bar(fb[1], 0);
}

static void layout(void)
{
    /*
     * from the top: the emulated screen (as wide as the panel), [the keyboard], the key bar, the keyboard
     * button; with the keyboard open the screen shrinks so that all of it stays visible
     */
    navh = H / 16;
    kbbh = H / 16;
    kbh = kb_open ? H / 4 : 0;
    int top = kb_open ? 0 : H / 26, avail = H - top - navh - kbbh - kbh;
    double s = (double)W / gw;
    if (gh * s > avail)
        s = (double)avail / gh;
    iw = (int)(gw * s);
    ih = (int)(gh * s);
    ix = (W - iw) / 2;
    iy = top;
    kby = iy + ih;
    navy = kby + kbh;
    kbby = navy + navh;
    free(xmap);
    free(ymap);
    xmap = malloc(sizeof(int) * iw);
    ymap = malloc(sizeof(int) * ih);
    for (int x = 0; x < iw; x++)
        xmap[x] = (int)((long)x * gw / iw);
    for (int y = 0; y < ih; y++)
        ymap[y] = (int)((long)y * gh / ih);
    draw_bar(fb[0], 1);
    if (fb[1] != fb[0])
        draw_bar(fb[1], 1);
    say("emulated screen %dx%d -> %dx%d at (%d,%d); keyboard %d; keys at y %d", gw, gh, iw, ih, ix, iy, kbh, navy);
}

/* ---- frames --------------------------------------------------------------------------------- */
static uint8_t *frame, *prev, *cand;  /* being shown, shown, last read */
static int last_g0, last_g1;
static int frame_fifo = -1;
/* W10M_NET_LATE=1: the USB Ethernet card is plugged in only once Windows has drawn its UI (with the network
 * there during the boot the shell hangs on "Loading...") */
static int net_late, net_plugged;
static double ui_seen_at;        /* QEMU writes a byte here after each whole frame (NATRUN_PRESENT) */      /* rows changed by the previous update: the other buffer lacks them */
static size_t frame_len;
static int dark;
static int ui_seen;                /* Windows has drawn a real screen (not just boot text or dots) */
/* -r: the guest's RAM file (memory-backend-file), the framebuffer read from it directly (XRGB8888) instead
 * of QMP screendump, which stops the emulated CPUs while QEMU writes the file */
static const uint8_t *ram_fb;
static int bpp = 3;

static int grab_frame(const char *path)
{
    if (ram_fb) {
        memcpy(frame, ram_fb, frame_len);
        return 0;
    }
    char cmd[512];
    snprintf(cmd, sizeof cmd, "{\"execute\": \"screendump\", \"arguments\": {\"filename\": \"%s\", \"format\": \"ppm\"}", path);
    if (qmp(1, "%s", cmd))
        return -1;
    FILE *f = fopen(path, "rb");
    if (!f)
        return -1;
    int w, h, mx;
    if (fscanf(f, "P6 %d %d %d", &w, &h, &mx) != 3 || w <= 0 || h <= 0) {
        fclose(f);
        return -1;
    }
    fgetc(f);
    size_t len = (size_t)w * h * 3;
    if (w != gw || h != gh) {
        gw = w;
        gh = h;
        free(frame);
        free(prev);
        frame = malloc(len);
        prev = calloc(1, len);
        frame_len = len;
        layout();
        last_g0 = 0;
        last_g1 = gh;
    }
    size_t got = fread(frame, 1, len, f);
    fclose(f);
    return got == len ? 0 : -1;
}

static void blit(int g0, int g1)
{
    int b = fb[1] != fb[0] ? !cur : cur;
    uint32_t *p = fb[b];
    long lum = 0;
    int u0 = g0, u1 = g1;
    if (fb[1] != fb[0]) {
        u0 = MIN(g0, last_g0);
        u1 = MAX(g1, last_g1);
    }
    last_g0 = g0;
    last_g1 = g1;
    for (int y = 0; y < ih; y++) {
        if (ymap[y] < u0 || ymap[y] >= u1)
            continue;
        const uint8_t *src = frame + (size_t)ymap[y] * gw * bpp;
        uint32_t *dst = p + (size_t)(iy + y) * (pitch / 4) + ix;
        if (bpp == 4 && !(fb_fd >= 0 && vinfo.red.offset == 0)) {
            const uint32_t *s32 = (const uint32_t *)src;
            for (int x = 0; x < iw; x++)
                dst[x] = s32[xmap[x]];
        } else if (bpp == 4) {
            for (int x = 0; x < iw; x++) {
                const uint8_t *s = src + xmap[x] * 4;
                dst[x] = rgb(s[2], s[1], s[0]);
            }
        } else {
            for (int x = 0; x < iw; x++) {
                const uint8_t *s = src + xmap[x] * 3;
                dst[x] = rgb(s[0], s[1], s[2]);
            }
        }
        if ((y & 63) == 0)
            for (int x = 0; x < gw; x += 16)
                lum += src[x * bpp] + src[x * bpp + 1] + src[x * bpp + 2];
    }
    /* dark = the display is off: Windows zeroes the whole framebuffer (a black screen with a little text,
     * such as "Loading...", is not dark) */
    (void)lum;
    dark = 1;
    for (size_t i = 0; i < frame_len; i += 64)
        if (frame[i] | frame[i + 1] | frame[i + 2]) {
            dark = 0;
            break;
        }
    if (!dark && !ui_seen) {
        size_t lit = 0, n = 0;
        for (size_t i = 0; i + 2 < frame_len; i += 256, n++)
            lit += (frame[i] | frame[i + 1] | frame[i + 2]) != 0;
        ui_seen = lit * 4 > n;                     /* a quarter of the screen drawn */
        if (ui_seen)
            ui_seen_at = now();
    }
    if (dark)
        for (size_t i = 0; i < frame_len; i++)
            if (frame[i] && (bpp != 4 || (i & 3) != 3)) {
                dark = 0;
                break;
            }
    show(b);
}

/* TWRP's screen timeout turns the panel's backlight off (brightness 0): keep it on */
static void backlight_on(void)
{
    static const char *dir = "/sys/class/backlight/panel0-backlight";
    char path[128], buf[32] = "";
    snprintf(path, sizeof path, "%s/brightness", dir);
    FILE *f = fopen(path, "r");
    if (!f)
        return;
    int cur_b = fgets(buf, sizeof buf, f) ? atoi(buf) : 0;
    fclose(f);
    if (cur_b > 0)
        return;
    snprintf(path, sizeof path, "%s/max_brightness", dir);
    int max_b = 2047;
    if ((f = fopen(path, "r"))) {
        if (fgets(buf, sizeof buf, f))
            max_b = atoi(buf);
        fclose(f);
    }
    snprintf(path, sizeof path, "%s/brightness", dir);
    if ((f = fopen(path, "w"))) {
        fprintf(f, "%d\n", max_b * 3 / 4);
        fclose(f);
        say("backlight was off: on again (%d)", max_b * 3 / 4);
    }
}

/* ---- input ---------------------------------------------------------------------------------- */
#define MAXIN 16
static struct pollfd pf[MAXIN + 1];
static int nin, touch_fd = -1;
static struct input_absinfo ax, ay;

static int has_bit(const unsigned long *bits, int n)
{
    return (bits[n / (8 * sizeof(long))] >> (n % (8 * sizeof(long)))) & 1;
}

static void open_inputs(void)
{
    DIR *d = opendir("/dev/input");
    struct dirent *e;
    while (d && (e = readdir(d)) && nin < MAXIN) {
        if (strncmp(e->d_name, "event", 5))
            continue;
        char path[300], name[128] = "";
        snprintf(path, sizeof path, "/dev/input/%s", e->d_name);
        int fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
        if (fd < 0)
            continue;
        unsigned long absb[(ABS_MAX + 64) / 64] = { 0 }, keyb[(KEY_MAX + 64) / 64] = { 0 };
        ioctl(fd, EVIOCGNAME(sizeof name), name);
        ioctl(fd, EVIOCGBIT(EV_ABS, sizeof absb), absb);
        ioctl(fd, EVIOCGBIT(EV_KEY, sizeof keyb), keyb);
        int touch = has_bit(absb, ABS_MT_POSITION_X) && touch_fd < 0 && !strstr(name, "xiaomi");
        int keys = has_bit(keyb, KEY_POWER) || has_bit(keyb, KEY_VOLUMEUP) || has_bit(keyb, KEY_VOLUMEDOWN);
        if (!touch && !keys) {
            close(fd);
            continue;
        }
        if (touch) {
            ioctl(fd, EVIOCGABS(ABS_MT_POSITION_X), &ax);
            ioctl(fd, EVIOCGABS(ABS_MT_POSITION_Y), &ay);
            touch_fd = fd;
        }
        ioctl(fd, EVIOCGRAB, 1);
        say("%s \"%s\": %s%s", path, name, touch ? "touch screen " : "", keys ? "keys" : "");
        if (touch)
            say("  x %d..%d, y %d..%d", ax.minimum, ax.maximum, ay.minimum, ay.maximum);
        pf[nin].fd = fd;
        pf[nin].events = POLLIN;
        nin++;
    }
    if (d)
        closedir(d);
}

/* the hot-plugged keyboard for power while the emulated screen is dark */
static double kbd_at;              /* the hot-plugged keyboard attached at (0: none) */

static double kbd_used;            /* the last key sent through it */
static char kbd_q[32][96];         /* key lists waiting until Windows has taken the keyboard */
static int kbd_qn;

static void kbd_send(const char *keys)
{
    if (!kbd_at) {
        qmp(0, "{\"execute\": \"device_add\", \"arguments\": {\"driver\": \"usb-kbd\", \"bus\": \"inxhci.0\", \"id\": \"simkbd\"}");
        kbd_at = now();
    }
    kbd_used = now();
    if (!*keys)
        return;                                    /* only attach it */
    if (now() - kbd_at < 6) {                      /* Windows needs a few seconds to take the keyboard */
        if (kbd_qn < 32)
            snprintf(kbd_q[kbd_qn++], sizeof kbd_q[0], "%s", keys);
        return;
    }
    qmp(0, "{\"execute\": \"send-key\", \"arguments\": {\"keys\": [%s]}", keys);
}

static void power_key(int down)
{
    if (!dark && !kbd_at) {
        key_event("power", down);
        return;
    }
    if (down) {
        if (dark)
            say("the screen is dark: power through a hot-plugged keyboard");
        kbd_send("{\"type\": \"qcode\", \"data\": \"power\"}");
    }
}

static void kbd_tick(void)
{
    if (!kbd_at)
        return;
    double t = now();
    if (kbd_qn && t - kbd_at >= 6) {
        for (int i = 0; i < kbd_qn; i++)
            qmp(0, "{\"execute\": \"send-key\", \"arguments\": {\"keys\": [%s]}", kbd_q[i]);
        kbd_qn = 0;
        kbd_used = t;
    }
    if (!kb_open && !kbd_qn && t - kbd_used > 20) {
        qmp(0, "{\"execute\": \"device_del\", \"arguments\": {\"id\": \"simkbd\"}");
        kbd_at = 0;
    }
}

static void relayout(void)
{
    layout();
    memset(prev, 0xff, frame_len);                 /* the whole emulated screen again, at its new place */
    last_g0 = 0;
    last_g1 = gh;
    show(cur);
}

static int tx = -1, ty = -1, tdown, tnav, tsent;
static int user_acted;

static void touch_sync(int down)
{
    if (tx < 0 || ty < 0)
        return;
    int px = (int)((long)(tx - ax.minimum) * W / (ax.maximum - ax.minimum + 1));
    int py = (int)((long)(ty - ay.minimum) * H / (ay.maximum - ay.minimum + 1));
    if (down && !tdown) {
        user_acted = 1;
        tnav = py >= navy ? 1 : (kb_open && py >= kby) ? 2 : 0;
        tsent = 0;
    }
    if (tnav == 2) {
        int k = kb_key_at(px, py, NULL, NULL, NULL, NULL);
        if (down && k != pressed_kb) {
            pressed_kb = k;
            redraw_bar();
            show(cur);
        }
        if (!down && tdown) {
            if (pressed_kb >= 0) {
                const Key *q = &KB_ROWS[pressed_kb / 16][pressed_kb % 16];
                char keys[96];
                if (!strcmp(q->code, "shift")) {
                    kb_shift = !kb_shift;
                } else if (!strcmp(q->code, "sym")) {
                    kb_sym = !kb_sym;
                    kb_shift = 0;
                } else if (q->code[0] == '+') {
                    snprintf(keys, sizeof keys, "{\"type\": \"qcode\", \"data\": \"shift\"}, "
                             "{\"type\": \"qcode\", \"data\": \"%s\"}", q->code + 1);
                    kbd_send(keys);
                } else {
                    if (kb_shift && q->code[1] == 0 && q->code[0] >= 'a' && q->code[0] <= 'z') {
                        snprintf(keys, sizeof keys, "{\"type\": \"qcode\", \"data\": \"shift\"}, "
                                 "{\"type\": \"qcode\", \"data\": \"%s\"}", q->code);
                        kb_shift = 0;
                    } else {
                        snprintf(keys, sizeof keys, "{\"type\": \"qcode\", \"data\": \"%s\"}", q->code);
                    }
                    kbd_send(keys);
                }
            }
            pressed_kb = -1;
            redraw_bar();
            show(cur);
        }
    } else if (tnav && py >= kbby) {
        if (down && pressed_key != 3) {
            pressed_key = 3;
            redraw_bar();
            show(cur);
        }
        if (!down && tdown) {
            pressed_key = -1;
            kb_open = !kb_open;
            if (kb_open)
                kbd_send("");                      /* attach the keyboard now: it is ready when typing starts */
            relayout();
        }
    } else if (tnav) {
        int key = px < W / 3 ? 0 : px < 2 * W / 3 ? 1 : 2;
        if (down && pressed_key != key) {
            pressed_key = key;
            redraw_bar();
            show(cur);
        }
        if (!down && tdown) {
            static const char *const codes[3] = { "ac_back", "meta_l", "find" };
            key_event(codes[key], 1);
            key_event(codes[key], 0);
            pressed_key = -1;
            redraw_bar();
            show(cur);
        }
    } else {
        int gx = (px - ix) * 32767 / (iw - 1), gy = (py - iy) * 32767 / (ih - 1);
        gx = gx < 0 ? 0 : gx > 32767 ? 32767 : gx;
        gy = gy < 0 ? 0 : gy > 32767 ? 32767 : gy;
        if (down && !tdown)
            pointer(gx, gy, 1), tsent = 1;
        else if (down)
            pointer(gx, gy, -1);
        else if (tsent)
            pointer(gx, gy, 0);
    }
    tdown = down;
}

static int pending_down = -1;

static void read_input(int fd)
{
    struct input_event ev[64];
    ssize_t r;
    while ((r = read(fd, ev, sizeof ev)) > 0) {
        for (int i = 0; i < (int)(r / sizeof ev[0]); i++) {
            struct input_event *e = &ev[i];
            if (fd == touch_fd) {
                if (e->type == EV_ABS && e->code == ABS_MT_POSITION_X)
                    tx = e->value;
                else if (e->type == EV_ABS && e->code == ABS_MT_POSITION_Y)
                    ty = e->value;
                else if (e->type == EV_ABS && e->code == ABS_MT_TRACKING_ID)
                    pending_down = e->value >= 0;
                else if (e->type == EV_KEY && e->code == BTN_TOUCH)
                    pending_down = e->value != 0;
                else if (e->type == EV_SYN && e->code == SYN_REPORT) {
                    int down = pending_down >= 0 ? pending_down : tdown;
                    pending_down = -1;
                    touch_sync(down);
                }
            } else if (e->type == EV_KEY && e->value != 2) {
                user_acted = 1;
                if (e->code == KEY_POWER)
                    power_key(e->value);
                else if (e->code == KEY_VOLUMEUP)
                    key_event("volumeup", e->value);
                else if (e->code == KEY_VOLUMEDOWN)
                    key_event("volumedown", e->value);
            }
        }
    }
}

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "usage: w10m-phone <qmp socket> [work dir]\n");
        return 2;
    }
    char shot[300];
    snprintf(shot, sizeof shot, "%s/w10m-frame.ppm", argc > 2 ? argv[2] : "/tmp");
    /* the emulated CPUs run on the big cores (liveboot.sh): this process stays on the little ones */
    cpu_set_t cs;
    CPU_ZERO(&cs);
    for (int c = 0; c < 4; c++)
        CPU_SET(c, &cs);
    sched_setaffinity(0, sizeof cs, &cs);
    net_late = getenv("W10M_NET_LATE") && !strcmp(getenv("W10M_NET_LATE"), "1");
    if (argc > 5) {
        int fd = open(argv[3], O_RDONLY | O_CLOEXEC);
        unsigned long long pa = strtoull(argv[4], NULL, 16);
        if (fd < 0 || sscanf(argv[5], "%dx%d", &gw, &gh) != 2 || pa < 0x40000000ULL) {
            say("bad framebuffer arguments %s %s %s", argv[3], argv[4], argv[5]);
            return 2;
        }
        bpp = 4;
        frame_len = (size_t)gw * gh * 4;
        long pg = sysconf(_SC_PAGESIZE);
        off_t off = (off_t)(pa - 0x40000000ULL);
        const uint8_t *m = mmap(0, frame_len + (off % pg), PROT_READ, MAP_SHARED, fd, off - off % pg);
        if (m == MAP_FAILED) {
            say("mapping the guest RAM failed: %s", strerror(errno));
            return 1;
        }
        ram_fb = m + off % pg;
        frame = malloc(frame_len);
        prev = malloc(frame_len);
        memset(prev, 0xff, frame_len);         /* the first frame always differs: shown, and dark known */
        cand = calloc(1, frame_len);
        if (argc > 6) {
            frame_fifo = open(argv[6], O_RDONLY | O_NONBLOCK | O_CLOEXEC);
            if (frame_fifo < 0)
                say("no frame fifo %s: %s", argv[6], strerror(errno));
        }
        say("frames straight from guest RAM at %s + %#llx, %dx%d XRGB8888", argv[3], (unsigned long long)off, gw, gh);
    }
    if (drm_open() && fbdev_open()) {
        say("no display: neither DRM (/dev/dri/card0) nor fbdev");
        return 1;
    }
    open_inputs();
    if (qmp_open(argv[1])) {
        say("no QMP at %s", argv[1]);
        return 1;
    }
    say("QMP connected");
    if (ram_fb) {
        layout();
        show(cur);                         /* the bar now: the first frame may be a dark (unchanged) one */
    }
    double last_change = 0, dark_since = 0, last_wake = 0, changing_since = 0, rate_at = now();
    int shown = 0, signalled = 0;
    for (;;) {
        double t = now();
        if (grab_frame(shot) == 0) {
            /*
             * Windows copies a frame into the framebuffer row by row (slowly: kernel code in TCG). Show it
             * when two reads agree, i.e. the copy is over; a picture that never holds still (an animation)
             * is shown at least every 50 ms anyway.
             */
            /* frames signalled by QEMU are whole: no need to wait for the copy to settle */
            int same = frame_fifo >= 0 || (cand && !memcmp(frame, cand, frame_len));
            if (cand && !same) {
                memcpy(cand, frame, frame_len);
                if (!changing_since)
                    changing_since = t;
                last_change = t;
            }
            if ((same || !cand || t - changing_since > 0.05) && memcmp(frame, prev, frame_len)) {
                int row = gw * bpp, g0 = 0, g1 = gh;
                while (g0 < gh && !memcmp(frame + (size_t)g0 * row, prev + (size_t)g0 * row, row))
                    g0++;
                while (g1 > g0 && !memcmp(frame + (size_t)(g1 - 1) * row, prev + (size_t)(g1 - 1) * row, row))
                    g1--;
                blit(g0, g1);
                shown++;
                memcpy(prev, frame, frame_len);
                last_change = t;
                changing_since = 0;
            }
        }
        if (qmp_fd >= 0) {
            /* QEMU gone? Also drop the replies to the input events (nobody waits for them) */
            char junk[4096];
            ssize_t r;
            while ((r = recv(qmp_fd, junk, sizeof junk, MSG_DONTWAIT)) > 0)
                ;
            if (r == 0) {
                say("QEMU closed QMP: done");
                return 0;
            }
        }
        kbd_tick();
        if (net_late && !net_plugged && ui_seen && t - ui_seen_at > 15) {
            qmp(0, "{\"execute\": \"device_add\", \"arguments\": {\"driver\": \"usb-ax88772\", \"bus\": \"inxhci.0\", "
                   "\"netdev\": \"n0\", \"id\": \"net0\"}");
            net_plugged = 1;
            say("Windows is up: the network cable plugged in");
        }
        if (t - rate_at >= 5) {
            if (shown || signalled)
                say("frames: %.1f/s shown, %.1f/s signalled by QEMU", shown / (t - rate_at), signalled / (t - rate_at));
            shown = signalled = 0;
            rate_at = t;
        }
        static double bl_check;
        if (t - bl_check > 2) {
            backlight_on();
            bl_check = t;
        }
        /* Windows turns the display off when it has booted (and later): wake it until the user takes over */
        if (!dark)
            dark_since = 0;
        else if (!dark_since)
            dark_since = t;
        if (dark && ui_seen && !user_acted && !kbd_at && t - dark_since > 15 && t - last_wake > 90) {
            say("dark for %.0f s and nobody has touched the phone: power", t - dark_since);
            power_key(1);
            power_key(0);
            last_wake = t;
        }
        /* 30 (20 with screendump) frames a second while the picture changes, fewer when it stands still */
        /* with the fifo: the next frame wakes us at once; still a look every 100 ms (boot, display off) */
        int wait = (frame_fifo >= 0 ? 100 :
                    ram_fb ? (changing_since ? 8 : t - last_change < 2 ? 16 : 100) : (t - last_change < 2 ? 50 : 250)) -
                   (int)((now() - t) * 1000);
        double until = now() + (wait > 0 ? wait : 0) / 1000.0;
        int nfd = nin;
        if (frame_fifo >= 0) {
            pf[nfd].fd = frame_fifo;
            pf[nfd].events = POLLIN;
            nfd++;
        }
        int got_frame = 0;
        do {
            int left = (int)((until - now()) * 1000);
            if (poll(pf, nfd, left > 0 ? left : 0) > 0) {
                for (int i = 0; i < nin; i++)
                    if (pf[i].revents & POLLIN)
                        read_input(pf[i].fd);
                if (nfd > nin && (pf[nin].revents & POLLIN)) {
                    char drain[256];
                    while (read(frame_fifo, drain, sizeof drain) > 0)
                        ;
                    got_frame = 1;
                    signalled++;
                }
            }
        } while (!got_frame && now() < until);
    }
}
