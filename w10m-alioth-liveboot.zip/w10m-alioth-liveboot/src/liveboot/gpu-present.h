/* gpu-present.c: the Windows frame scaled onto the panel by the Adreno 650 (Vulkan) */
#pragma once
#include <stdint.h>

/* icd: libvulkan_freedreno.so; the panel's two dumb buffers (GEM handles on drm_fd), their pitch and height;
 * the guest frame's size. 0 when the GPU path is ready. */
int gp_init(const char *icd, int drm_fd, const uint32_t handle[2], int pitch, int panel_h, int w, int h);
/* where the next frame is copied (XRGB8888, w*h*4 bytes) */
void *gp_staging(void);
/* the picture's rectangle on the panel (re-recorded on every layout change) */
int gp_layout(int x, int y, int w, int h);
/* the staged frame into dumb buffer b (waits for the GPU) */
int gp_present(int b);
