#!/usr/bin/env bash
# w10m-phone for the phone: dynamic (glibc from the QEMU package's lib/), it dlopens the GPU's Vulkan driver.
# Vulkan headers from the Mesa tree (src/gpu/build-turnip-aarch64.sh). Run: wsl -e bash .../build-phone-agent.sh
set -e
S=/mnt/c/win10mobile/src/liveboot
aarch64-linux-gnu-gcc -O2 -Wall -s -I "$HOME/mesa/mesa-26.2.7/include" -o /mnt/c/win10mobile/work/qemu-a64/w10m-phone \
    "$S/w10m-phone.c" "$S/gpu-present.c" -ldl
aarch64-linux-gnu-readelf -d /mnt/c/win10mobile/work/qemu-a64/w10m-phone | grep NEEDED
